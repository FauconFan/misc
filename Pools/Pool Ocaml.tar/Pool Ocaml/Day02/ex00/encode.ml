(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   encode.ml                                          :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 15:14:15 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 16:01:09 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let encode entry =
	let rec build_entry entry res cand number =	match entry with
	| [] -> res @ [(number, cand)]
	| head::tail -> if cand = head
					then build_entry tail res cand (number + 1)
					else build_entry tail (res @ [(number, cand)]) head 1
	in match entry with
	| [] -> []
	| head::tail -> build_entry tail [] head 1

let rec print_input f li = match li with
	| [] -> print_newline ()
	| head::tail -> f head; print_char ' '; print_input f tail

let rec print_output f li = match li with
	| [] -> print_newline ()
	| (i, c)::tail -> print_int i;
				print_char '-';
				f c;
				print_char ' ';
				print_output f tail

let main () =
	let nu = [2; 2; 2; 4; 1; 1] in
	let nu_treat = encode nu in
	let ch = ['a'; 'a'; 'b'; 'b'; 'b'; 'b'; 'b'; 'd'; 'd'] in
	let ch_treat = encode ch in
	print_input print_int nu;
	print_output print_int nu_treat;
	print_newline ();
	print_input print_char ch;
	print_output print_char ch_treat

let () = main ()
