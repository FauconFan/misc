(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   ribosome.ml                                        :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 22:01:52 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 23:09:08 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

(* Nucleotides.ml *)

type phosphate = string

type deoxyribose = string

type nucleobase = A
				| T
				| U
				| C
				| G
				| None

type nucleotide = {
	pho: phosphate;
	deo: deoxyribose;
	nuc: nucleobase
}

let build_nucleotide pho deo nuc =
	{pho = pho; deo = deo; nuc = nuc}

let build_simple_nucleotide nuc = build_nucleotide "phosphate" "deoxyribose" nuc

let generate_nucleotide c =
	let nuc = match c with
	| 'a' | 'A' -> A
	| 't' | 'T' -> T
	| 'c' | 'C' -> C
	| 'g' | 'G' -> G
	| _ -> None
	in
	build_simple_nucleotide nuc

let nucleobase_to_string nuc = match nuc with
	| A -> "A"
	| T -> "T"
	| U -> "U"
	| C -> "C"
	| G -> "G"
	| None -> " "

let nucleotide_to_string n = match n.nuc with
	| U -> " "
	| _ -> nucleobase_to_string n.nuc

(* helix.ml *)

let _ = Random.self_init ();

type helix = nucleotide list

let gen_assoc r = match r with
	| 0 -> generate_nucleotide 'a'
	| 1 -> generate_nucleotide 't'
	| 2 -> generate_nucleotide 'c'
	| _ -> generate_nucleotide 'g'

let complementary_nucleobase ?isrna:(rna = false) nu = match nu with
	| A -> if rna then U else T
	| T -> A
	| C -> G
	| G -> C
	| U -> A
	| None -> None

let rec generate_helix n =
	if n <= 0 then []
	else (gen_assoc (Random.int 4)) :: (generate_helix (n - 1))

let rec helix_to_string h = match h with
	| [] -> ""
	| head :: tail -> (nucleotide_to_string head) ^ (helix_to_string tail)

let rec complementary_helix h = match h with
	| [] -> []
	| head :: tail ->
		(build_simple_nucleotide
			(complementary_nucleobase
				(head.nuc)))
					:: (complementary_helix tail)

(* rna.ml *)

type rna = nucleobase list

let rec generate_rna h = match h with
	| [] -> []
	| head :: tail -> (complementary_nucleobase ~isrna:true head.nuc) ::
							generate_rna tail

let rec rna_to_string rna = match rna with
	| [] -> ""
	| head :: tail -> (nucleobase_to_string head) ^ (rna_to_string tail)

(* ribosome.ml *)

type aminoacid = STOP
				| Ala
				| Arg
				| Asn
				| Asp
				| Cys
				| Gln
				| Glu
				| Gly
				| His
				| Ile
				| Leu
				| Lys
				| Met
				| Phe
				| Pro
				| Ser
				| Thr
				| Trp
				| Tyr
				| Val
				| None

let string_of_aminoacid am = match am with
	| STOP -> "End of translation"
	| Ala -> "Alanine"
	| Arg -> "Arginine"
	| Asn -> "Asparagine"
	| Asp -> "Aspartine"
	| Cys -> "Cysteine"
	| Gln -> "Glutanine"
	| Glu -> "Glutamique"
	| Gly -> "Glycine"
	| His -> "Histidine"
	| Ile -> "Isoleucine"
	| Leu -> "Leucine"
	| Lys -> "Lysine"
	| Met -> "Methionine"
	| Phe -> "Phenylalaline"
	| Pro -> "Proline"
	| Ser -> "Serine"
	| Thr -> "Threonine"
	| Trp -> "Tryptophane"
	| Tyr -> "Tyrosine"
	| Val -> "Valine"
	| None -> ""

let build_aminocid tuple_nucleobase = match tuple_nucleobase with
	| [U,A,A] | [U,A,G] | [U,G,A] -> STOP
	| [G,C,A] | [G,C,C] | [G,C,G] | [G,C,U] -> Ala
	| [A,G,A] | [A,G,G] | [C,G,A] | [C,G,C] | [C,G,G] | [C,G,U] -> Arg
	| [A,A,C] | [A,A,U] -> Asn
	| [G,A,C] | [G,A,U] -> Asp
	| [U,G,C] | [U,G,U] -> Cys
	| [C,A,A] | [C,A,G] -> Gln
	| [G,A,A] | [G,A,G] -> Glu
	| [G,G,A] | [G,G,C] | [G,G,G] | [G,G,U] -> Gly
	| [C,A,C] | [C,A,U] -> His
	| [A,U,A] | [A,U,C] | [A,U,U] -> Ile
	| [C,U,A] | [C,U,C] | [C,U,G] | [C,U,U] | [U,U,A] | [U,U,G] -> Leu
	| [A,A,A] | [A,A,G] -> Lys
	| [A,U,G] -> Met
	| [U,U,C] | [U,U,U] -> Phe
	| [C,C,C] | [C,C,A] | [C,C,G] | [C,C,U] -> Pro
	| [U,C,A] | [U,C,C] | [U,C,G] | [U,C,U] | [A,G,U] | [A,G,C] -> Ser
	| [A,C,A] | [A,C,C] | [A,C,G] | [A,C,U] -> Thr
	| [U,G,G] -> Trp
	| [U,A,C] | [U,A,U] -> Tyr
	| [G,U,A] | [G,U,C] | [G,U,G] | [G,U,U] -> Val
	| _ -> None

type protein = aminoacid list

let rec generate_bases_triplets rna = match rna with
	| n1 :: n2 :: n3 :: tail -> ([n1, n2, n3]) :: generate_bases_triplets tail
	| _ -> []

let rec decode_rna tripl_nucleo_list = match tripl_nucleo_list with
	| [] -> []
	| head :: tail -> let head_new = (build_aminocid head) in
						match head_new with
						| None | STOP -> []
						| _ -> head_new :: (decode_rna tail)


let string_of_protein prot = match prot with
	| [] -> "No aminoacid"
	| head :: tail ->
		let rec builder prot res = match prot with
		| [] | STOP :: _ | None :: _ -> res
		| head2 :: tail2 -> builder tail2 (res ^ " - " ^ (string_of_aminoacid head2))
		in (string_of_aminoacid head) ^ (builder tail "")

(* Main ribosome *)

let main () =
let rec loop i ma =
	if i <= ma
	then
		let h = generate_helix 18 in
		let h_rna = generate_rna h in
		let amino_list = generate_bases_triplets h_rna in
		let prot = decode_rna amino_list in
		let s_prot = string_of_protein prot in

		print_endline s_prot;
		loop (i + 1) ma
in
loop 0 10

let () = main ()
