(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   crossover.ml                                       :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 16:02:24 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 16:10:09 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let rec crossover la lb =
	let rec is_in li elem = match li with
	| [] -> false
	| head::tail -> if elem = head then true
	 				else is_in tail elem
	in match la with
	| [] -> []
	| head::tail -> if is_in lb head then head :: (crossover tail lb)
					else crossover tail lb

let main () =
	let a = [1; 3; 5; 7] in
	let b = [1; 2; 3; 4] in
	let comm = crossover a b in
	let rec print_list f li = match li with
		| [] -> print_newline ()
		| head::tail -> f head; print_char ' '; print_list f tail
	in
	print_list print_int comm

let () = main ()
