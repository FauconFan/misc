(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   nucleotides.ml                                     :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 18:08:08 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 20:57:43 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

(* Nucleotides.ml *)

type phosphate = string

type deoxyribose = string

type nucleobase = A
				| T
				| U
				| C
				| G
				| None

type nucleotide = {
	pho: phosphate;
	deo: deoxyribose;
	nuc: nucleobase
}

let build_nucleotide pho deo nuc =
	{pho = pho; deo = deo; nuc = nuc}

let build_simple_nucleotide nuc = build_nucleotide "phosphate" "deoxyribose" nuc

let generate_nucleotide c =
	let nuc = match c with
	| 'a' | 'A' -> A
	| 't' | 'T' -> T
	| 'c' | 'C' -> C
	| 'g' | 'G' -> G
	| _ -> None
	in
	build_simple_nucleotide nuc

let nucleobase_to_string nuc = match nuc with
	| A -> "A"
	| T -> "T"
	| U -> "U"
	| C -> "C"
	| G -> "G"
	| None -> " "

let nucleotide_to_string n = match n.nuc with
	| U -> " "
	| _ -> nucleobase_to_string n.nuc

(* Main nucleotides.ml *)

let main () =
	let a = generate_nucleotide 'a' in
	let t = generate_nucleotide 't' in
	let c = generate_nucleotide 'c' in
	let g = generate_nucleotide 'g' in
	print_string (nucleotide_to_string a);
	print_newline ();
	print_string (nucleotide_to_string t);
	print_newline ();
	print_string (nucleotide_to_string c);
	print_newline ();
	print_string (nucleotide_to_string g);
	print_newline ()

let () = main ()
