(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   helix.ml                                           :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 18:21:04 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 21:05:45 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

(* Nucleotides.ml *)

type phosphate = string

type deoxyribose = string

type nucleobase = A
				| T
				| U
				| C
				| G
				| None

type nucleotide = {
	pho: phosphate;
	deo: deoxyribose;
	nuc: nucleobase
}

let build_nucleotide pho deo nuc =
	{pho = pho; deo = deo; nuc = nuc}

let build_simple_nucleotide nuc = build_nucleotide "phosphate" "deoxyribose" nuc

let generate_nucleotide c =
	let nuc = match c with
	| 'a' | 'A' -> A
	| 't' | 'T' -> T
	| 'c' | 'C' -> C
	| 'g' | 'G' -> G
	| _ -> None
	in
	build_simple_nucleotide nuc

let nucleobase_to_string nuc = match nuc with
	| A -> "A"
	| T -> "T"
	| U -> "U"
	| C -> "C"
	| G -> "G"
	| None -> " "

let nucleotide_to_string n = match n.nuc with
	| U -> " "
	| _ -> nucleobase_to_string n.nuc

(* helix.ml *)

let _ = Random.self_init ();

type helix = nucleotide list

let gen_assoc r = match r with
	| 0 -> generate_nucleotide 'a'
	| 1 -> generate_nucleotide 't'
	| 2 -> generate_nucleotide 'c'
	| _ -> generate_nucleotide 'g'

let complementary_nucleobase ?isrna:(rna=false) nu = match nu with
	| A -> if rna then U else T
	| T -> A
	| C -> G
	| G -> C
	| U -> A
	| None -> None

let rec generate_helix n =
	if n <= 0 then []
	else (gen_assoc (Random.int 4)) :: (generate_helix (n - 1))

let rec helix_to_string h = match h with
	| [] -> ""
	| head :: tail -> (nucleotide_to_string head) ^ (helix_to_string tail)

let rec complementary_helix h = match h with
	| [] -> []
	| head :: tail ->
		(build_simple_nucleotide
			(complementary_nucleobase
				(head.nuc)))
					:: (complementary_helix tail)

(* Main helix.ml *)

let main () =
	let rec loop i ma =
		if i <= ma
		then
			let h = generate_helix 8 in
			let h_str = helix_to_string h in
			let h_comp = complementary_helix h in
			let h_comp_str = helix_to_string h_comp in

			print_string "Helix h str : ";
			print_string h_str;
			print_newline ();
			print_string "Helix h comp str : ";
			print_string h_comp_str;
			print_newline ();
			print_newline ();
			loop (i + 1) ma
	in
	loop 0 10

let () = main ()
