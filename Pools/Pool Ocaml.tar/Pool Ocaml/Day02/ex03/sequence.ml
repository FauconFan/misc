(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   sequence.ml                                        :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 16:28:26 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 18:04:13 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let encode entry =
	let rec build_entry entry res cand number =	match entry with
	| [] -> res @ [(number, cand)]
	| head::tail -> if cand = head
					then build_entry tail res cand (number + 1)
					else build_entry tail (res @ [(number, cand)]) head 1
	in match entry with
	| [] -> []
	| head::tail -> build_entry tail [] head 1

let rec sequence n =
	if n <= 0 then ""
	else if n = 1 then "1"
	else
		begin
			let rec res_seq n =
			if n = 1 then ["1"]
			else
				let prev = res_seq (n - 1) in
				let encoded = encode prev in
				let rec transform en = match en with
					| [] -> []
					| (i, c) :: tail -> (string_of_int i) :: c :: (transform tail)
				in
				transform encoded
				in
			let seq = res_seq n in
			let rec concac_string li = match li with
			| [] -> ""
			| head :: tail -> head ^ (concac_string tail)
			in
			concac_string seq
		end


let main () =
	let rec loop i ma =
		if i <= ma
		then let seq = sequence i in
				print_endline seq;
				loop (i + 1) ma
	in loop 0 15

let () = main ()
