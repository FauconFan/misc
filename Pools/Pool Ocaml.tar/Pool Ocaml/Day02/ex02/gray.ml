(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   gray.ml                                            :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 16:17:49 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 16:27:11 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let rec concat la lb = match la with
	| [] -> lb
	| head::tail -> head :: (concat tail lb)

let build_new_elem str = [str ^ "0"; str ^ "1"]

let rec gray n =
	if n <= 1 then ["0"; "1"]
	else let prev = gray (n - 1) in
		let rec build_gray li res = match li with
			| [] -> res
			| head :: tail -> build_gray tail (concat res (build_new_elem head))
		in build_gray prev []

let main () =
	let rec print_list li = match li with
		| [] -> print_newline ()
		| head :: tail -> print_string head; print_char ' '; print_list tail
	in
	let gray1 = gray 1 in
	let gray2 = gray 2 in
	let gray3 = gray 3 in
	let gray4 = gray 4 in

	print_list gray1;
	print_list gray2;
	print_list gray3;
	print_list gray4

let () = main ()
