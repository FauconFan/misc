(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   ex03.ml                                            :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/22 14:04:05 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/23 00:37:15 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

module type FIXED = sig
	type t
	val of_float	: float -> t
	val of_int		: int -> t
	val to_float	: t -> float
	val to_int		: t -> int
	val to_string	: t -> string
	val zero		: t
	val one			: t
	val succ		: t -> t
	val pred		: t -> t
	val min			: t -> t -> t
	val max			: t -> t -> t
	val gth			: t -> t -> bool
	val lth			: t -> t -> bool
	val gte			: t -> t -> bool
	val lte			: t -> t -> bool
	val eqp			: t -> t -> bool (** physical equity *)
	val eqs			: t -> t -> bool (** structural equity *)

	val add			: t -> t -> t
	val sub			: t -> t -> t
	val mul			: t -> t -> t
	val div			: t -> t -> t

	val foreach		: t -> t -> (t -> unit) -> unit
end

module type FRACTIONNAL_BITS = sig val bits : int end

module type MAKE = functor (Fractionnal_bits : FRACTIONNAL_BITS) -> FIXED

module Make : MAKE =
	functor (Fractionnal_bits : FRACTIONNAL_BITS) ->
	struct
		type t = int

		let of_float (f:float) =
			let pad = 1. /. (2. ** (float_of_int Fractionnal_bits.bits)) in
			int_of_float (f /. pad)
		let of_int (i:int) = i lsl Fractionnal_bits.bits
		let to_float (t:t) =
			let pad = 1. /. (2. ** (float_of_int Fractionnal_bits.bits)) in
			(float_of_int t) *. pad
		let to_int (t:t) = t lsr Fractionnal_bits.bits
		let to_string (t:t) = string_of_float (to_float t)
		let zero = of_int 0
		let one = of_int 1
		let succ (t:t) = succ t
		let pred (t:t) = pred t
		let min (t1:t) (t2:t) = if t1 < t2 then t1 else t2
		let max (t1:t) (t2:t) = if t1 > t2 then t1 else t2
		let gth (t1:t) (t2:t) = t1 > t2
		let lth (t1:t) (t2:t) = t1 < t2
		let gte (t1:t) (t2:t) = t1 >= t2
		let lte (t1:t) (t2:t) = t1 <= t2
		let eqp (t1:t) (t2:t) = t1 == t2
		let eqs (t1:t) (t2:t) = t1 = t2

		let add (t1:t) (t2:t) = t1 + t2
		let sub (t1:t) (t2:t) = t1 - t2
		let mul (t1:t) (t2:t) = (t1 * t2) lsr Fractionnal_bits.bits
		let div (t1:t) (t2:t) = of_float ((to_float t1) /. (to_float t2))

		let foreach (t1:t) (t2:t) f =
			if t1 == t2 then f t1
			else
				begin
					let next = if t1 < t2 then succ else pred in
					let rec rec_for t1 t2 f next =
						if t1 == t2 then f t1
						else
							begin
								f t1;
								rec_for (next t1) t2 f next
							end
					in
					rec_for t1 t2 f next
				end
	end

module Fixed4 = Make (struct let bits = 4 end)
module Fixed8 = Make (struct let bits = 8 end)

let () =
	let x = Fixed8.of_float 5.2315 in
	let x = Fixed8.succ x in
	let y = Fixed8.of_int 7 in

	print_endline (Fixed8.to_string x);
	print_newline ();
	Fixed4.foreach Fixed4.one Fixed4.zero (fun e -> print_endline (Fixed4.to_string e));
	print_newline ();
	print_endline ("x : " ^ (Fixed8.to_string x));
	print_endline ("y : " ^ (Fixed8.to_string y));
	print_endline ("min x y : " ^ (Fixed8.to_string (Fixed8.min x y)));
	print_endline ("max x y : " ^ (Fixed8.to_string (Fixed8.max x y)));
	print_endline ("gth x y : " ^ (string_of_bool (Fixed8.gth x y)));
	print_endline ("lth x y : " ^ (string_of_bool (Fixed8.lth x y)));
	print_endline ("eqp x y : " ^ (string_of_bool (Fixed8.eqp x y)));
	print_endline ("eqs x y : " ^ (string_of_bool (Fixed8.eqs x y)));
	print_endline ("eqp x x : " ^ (string_of_bool (Fixed8.eqp x x)));
	print_endline ("eqs x x : " ^ (string_of_bool (Fixed8.eqs x x)));
	print_newline ();
	print_endline ("succ " ^ (Fixed8.to_string y) ^ " => " ^ (Fixed8.to_string (Fixed8.succ y)));
	print_endline ("pred " ^ (Fixed8.to_string y) ^ " => " ^ (Fixed8.to_string (Fixed8.pred y)));
	print_newline ();
	print_endline ("add x y : " ^ (Fixed8.to_string (Fixed8.add x y)));
	print_endline ("sub x y : " ^ (Fixed8.to_string (Fixed8.sub x y)));
	print_endline ("mul x y : " ^ (Fixed8.to_string (Fixed8.mul x y)));
	print_endline ("div x y : " ^ (Fixed8.to_string (Fixed8.div x y)));
