(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   ex01.ml                                            :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/22 11:35:46 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/22 14:00:10 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

module StringWithHash = struct
	type t = string

	let equal (i:t) (j:t) = i == j

	let hash (str:t) =
		let res = ref 5381 in
		let rec hash_i i =
			if (i >= 0) then
				begin
					res := (!res * 33) lxor (int_of_char (String.get str i));
					hash_i (i - 1)
				end
		in
		hash_i ((String.length str) - 1);
		!res
end

module StringHashtbl = Hashtbl.Make(StringWithHash)

let () =
	let ht = StringHashtbl.create 5 in
	let values = [ "Hello"; "world"; "42"; "Ocaml"; "H" ] in
	let pairs = List.map (fun s -> (s, String.length s)) values in

	List.iter (fun (k,v) -> StringHashtbl.add ht k v) pairs;
	StringHashtbl.iter (fun k v -> Printf.printf "k = \"%s\", v = %d\n" k v) ht
