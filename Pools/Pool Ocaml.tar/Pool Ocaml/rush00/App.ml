(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   App.ml                                             :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/21 17:59:52 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/21 19:39:31 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

module IO = struct

	let q_askForOName = "Quelle est le nom du premier joueur (O) ?"
	let q_askForXName = "Quelle est le nom du second joueur (X) ?"

	let askQuestion question =
		print_endline question;
		read_line ()

	let rec askCoords () =
		let str = read_line () in
		let sp = String.split_on_char ' ' str in

		if List.length sp <> 2 then
			begin
				print_endline "Wrong format";
				askCoords ()
			end
		else
			begin
				let int_opt_list = List.map int_of_string_opt sp in
				let rec are_all_int li = match li with
					| []				-> true
					| head :: tail		-> match head with
						| None	-> false
						| _		-> are_all_int tail
				in
				if are_all_int int_opt_list = false then
					begin
						print_endline "Wrong format";
						askCoords ()
					end
				else
					match int_opt_list with
						| [Some a; Some b]	-> (a, b)
						| _					-> failwith "Something went wrong"
			end
end

type t = {
	o_player	: Player.t;
	x_player	: Player.t;
	size_grid	: int
}

let init () =
	(* let o_name = IO.askQuestion IO.q_askForOName in
	let x_name = IO.askQuestion IO.q_askForXName in *)
	let default_size = 3 in

	print_endline ("Default Grid size : " ^ (string_of_int default_size));
		{
			o_player 	= Player.O "oui";
			x_player 	= Player.X "xylophone";
			size_grid	= default_size
		}

let rec game_loop app gr p =
	let rec get_correct_coords gr =
		let coords = IO.askCoords () in
		let row = ((fst coords) - 1) in
		let col = ((snd coords) - 1) in
		let err = Grid.has_access gr row col in

		match err with
			| None	-> (row, col)
			| _		->
				begin
					print_endline (ErrorInput.string_of_error_input err);
					get_correct_coords gr
				end
	in
	let go_next gr coords p =
		let gr_next = Grid.change_case gr (fst coords) (snd coords) p in
		let next_player p = match p with
			| Player.O _		-> app.x_player
			| Player.X _		-> app.o_player
			| _					-> failwith "should never happened"
		in
		game_loop app gr_next (next_player p)
	in
	Grid.print_grid gr;
	print_endline ((Player.string_of_player p) ^ "'s turn to play.");
	go_next gr (get_correct_coords gr) p

let run app =
	let gr = Grid.build_grid app.size_grid in

	game_loop app gr app.o_player
