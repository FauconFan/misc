(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   Grid.ml                                            :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/19 23:30:39 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/21 19:42:46 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

type t = int * (Player.t * Player.t list list) list

let build_grid n =
	let rec build_row_empty n =
		if n <= 0 then []
		else Player.No_Player :: (build_row_empty (n - 1))
	and build_subgrid_empty size n =
		if n <= 0 then []
		else (build_row_empty size) :: (build_subgrid_empty size (n - 1))
	and build_empty_full_grid size n =
		if n <= 0 then []
		else (Player.No_Player, (build_subgrid_empty size size)) ::
				build_empty_full_grid size (n - 1) in
	((n, (build_empty_full_grid n (n * n))):t)

let get_id_subgrid size row col = ((row / size) * size) + (col / size)

let is_in_grid (gr:t) row col =
	let _size = fst gr in
	let size = _size * _size in
	(row >= 0 && col >= 0 && row < size && col < size)

let get_case (gr:t) row col =
	let size = fst gr in
	let id = get_id_subgrid size row col in
	let get_in_subgrid sg row col =
		let owned_by = fst sg in
		if owned_by <> Player.No_Player then owned_by
		else
			let li_sub = snd sg in
			List.nth (List.nth li_sub (row mod size)) (col mod size)
	in
	get_in_subgrid (List.nth (snd gr) id) row col


let has_access (gr:t) row col =
	let good_format gr row col =
		if is_in_grid gr row col then ErrorInput.None
		else ErrorInput.Format
	in
	let good_move gr row col =
		let c = get_case gr row col in
		match c with
		| Player.No_Player		-> ErrorInput.None
		| _						-> ErrorInput.Illegal_move
	in
	let g_f = good_format gr row col in
	match g_f with
	| ErrorInput.None		-> good_move gr row col
	| _			-> g_f

let update_sub_grid sg size p =
	let own = fst sg in
	let li_li = snd sg in
	if own <> Player.No_Player then failwith "Should never happened"
	else
		let check_lines sg_rows f = List.exists (List.for_all f) sg_rows in
		let check_cols sg_rows f size =
			let rec loop sg_rows f inc ma =
				if inc >= ma then false
				else (List.for_all (fun l -> f (List.nth l inc)) sg_rows) ||
						(loop sg_rows f (inc + 1) ma)
			in
			loop sg_rows f 0 size
		in
		let check_diag sg_rows f size =
			let for_all_i li p =
				let rec _f li p i = match li with
					| []			-> true
					| head :: tail	-> p head i && _f tail p (i + 1)
				in
				_f li p 0
			in
			for_all_i sg_rows (fun l i -> f (List.nth l i)) ||
			for_all_i sg_rows (fun l i -> f (List.nth l (size - 1 - i)))
		in
		let id = Player.equals p in

		if (check_lines li_li id)
			|| (check_cols li_li id size)
			|| (check_diag li_li id size) then (p, [])
		else sg

let change_case (gr:t) row col _type =
	if is_in_grid gr row col = false then gr
	else
		let size_gr = fst gr in
		let id = get_id_subgrid size_gr row col in
		let row_mod = row mod size_gr in
		let col_mod = col mod size_gr in
		let rec modify_line cols i elem = match cols with
			| []			-> failwith "Impossible"
			| head :: tail	-> if i == 0 then elem :: tail
							else head :: modify_line tail (i - 1) elem
		in
		let rec modify_rows rows i col_mod elem = match rows with
			| []			-> failwith "Impossible"
			| head :: tail	-> if i == 0 then modify_line head col_mod elem :: tail
							else head :: modify_rows tail (i - 1) col_mod elem
		in
		let rec modify_sub_grid sgs n row_mod col_mod elem size_gr = match sgs with
			| []			-> failwith "Impossible"
			| head :: tail	-> if n == 0 then
								let _new_subgrid = ((fst head), modify_rows (snd head) row_mod col_mod elem) in
								let new_subgrid = update_sub_grid _new_subgrid size_gr elem in
								new_subgrid :: tail
							else head :: modify_sub_grid tail (n - 1) row_mod col_mod elem size_gr
		in
		(size_gr, modify_sub_grid (snd gr) id row_mod col_mod _type size_gr)


let print_grid (gr:t) =
	let size_gr = fst gr in
	let sg = snd gr in
	let print_inter_row n =
		let rec print_line c n =
			if n <= 0 then print_newline ()
			else
				begin
					print_char c;
					print_line c (n - 1)
				end
		in
		print_line '-' (2 * n * (n + 1) - 3)
	in
	let rec print_n_rows sub_grids row_i size =
		let rec get_next sub_grids i =
			if i == 0 then sub_grids
			else match sub_grids with
			| []		-> failwith "Impossible"
			| _ :: tail	-> get_next tail (i - 1)
		in
		let rec print_rows sub_grids row_i size real_size =
			let print_real_rows sub_grids row_i =
				let row = List.nth (snd (List.nth sub_grids 0)) row_i in
				let rec print_row row = match row with
					| []			-> failwith "Impossible"
					| [head]		-> print_char (Player.char_of_player head)
					| head :: tail	->
						begin
							print_char (Player.char_of_player head);
							print_char ' ';
							print_row tail
						end in
				print_row row
			in
			let print_player_name size p =
				let name = Player.string_of_player p in
				let real_size = 2 * size - 1 in
				let size_name = String.length name in

				if size_name > real_size then
					print_string (String.sub name 0 real_size)
				else
					print_string (name ^ String.make (real_size - size_name) ' ')
			in
			if size > 0 then
				begin
					let p = (fst (List.nth sub_grids 0)) in
					let has_defined_player = p <> Player.No_Player in

					if has_defined_player then print_player_name real_size p
					else print_real_rows sub_grids row_i;
					if size <> 1 then
						begin
							print_string " | ";
							print_rows (get_next sub_grids 1) row_i (size - 1) real_size
						end
				end
		in
		if row_i == size then get_next sub_grids size
		else
			begin
				print_rows sub_grids row_i size size;
				print_newline ();
				print_n_rows sub_grids (row_i + 1) size
			end
	in
	let rec loop_print sub_grids size = match sub_grids with
		| []				-> ignore ()
		| _					-> print_inter_row size;
								loop_print (print_n_rows sub_grids 0 size) size
	in
	loop_print (print_n_rows sg 0 size_gr) size_gr
