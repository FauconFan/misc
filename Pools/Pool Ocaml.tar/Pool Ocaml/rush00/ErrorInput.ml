(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   ErrorInput.ml                                      :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/21 17:55:46 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/21 19:06:02 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

type t = None
		| Illegal_move
		| Format

let string_of_error_input e_s = match e_s with
	| None				-> ""
	| Illegal_move		-> "Illegal move."
	| Format			-> "Incorrect format."
