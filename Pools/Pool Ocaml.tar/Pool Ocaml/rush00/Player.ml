(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   Player.ml                                          :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/21 16:10:56 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/21 17:12:27 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

type t = No_Player
		| O of string
		| X of string

let equals p1 p2 = match p1, p2 with
	| O s1, O s2	-> s1 == s2
	| X s1, X s2	-> s1 == s2
	| _, _			-> false

let string_of_player c = match c with
	| No_Player		-> failwith "Should never called string_of_player on No P"
	| O s			-> s
	| X s			-> s

let char_of_player c = match c with
	| No_Player 	-> '-'
	| O _			-> 'O'
	| X _			-> 'X'

let isO c = match c with
	| O _			-> true
	| _				-> false

let isX c = match c with
	| X _			-> true
	| _				-> false
