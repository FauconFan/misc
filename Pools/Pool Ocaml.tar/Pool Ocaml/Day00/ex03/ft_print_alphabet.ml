(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   ft_print_alphabet.ml                               :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/17 23:14:52 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/17 23:23:12 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let ft_print_alphabet () =
	begin
		let rec loop char_int =
			if char_int <= int_of_char 'z'
			then
				begin
					print_char (char_of_int char_int);
					loop (char_int + 1)
				end
		in loop (int_of_char 'a');
		print_char '\n'
	end

let main () =
	ft_print_alphabet ()

let () = main ()
