(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   ft_is_palindrome.ml                                :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 00:36:10 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 00:42:52 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let ft_is_palindrome str =
	let rec loop str i =
		if i >= ((String.length str) / 2) then true
		else
			begin
				if (String.get str i) <>
					(String.get str ((String.length str) - 1 - i))
				then false
				else loop str (i + 1)
			end
	in loop str 0

let main () =
	print_endline (string_of_bool (ft_is_palindrome "couuoc"));
	print_endline (string_of_bool (ft_is_palindrome "kayak"));
	print_endline (string_of_bool (ft_is_palindrome "coucou"));
	print_endline (string_of_bool (ft_is_palindrome "kayyak"))

let () = main ()
