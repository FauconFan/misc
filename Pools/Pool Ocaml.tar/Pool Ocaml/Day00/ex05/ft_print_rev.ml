(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   ft_print_rev.ml                                    :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 00:17:46 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 00:24:22 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let ft_print_rev s =
	let rec loop s i =
		if (i >= 0)
		then
			begin
				print_char (String.get s i);
				loop s (i - 1)
			end
	in loop s ((String.length s) - 1)

let main () =
	ft_print_rev "\nHello !";
	ft_print_rev "\nWorld";
	ft_print_rev "\n! dlroW olleH"


let () = main ()
