(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   ft_power.ml                                        :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/17 22:51:11 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/17 23:11:19 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let ft_power x n =
  if x = 0 && n = 0
  then 1
  else
    if x = 0
    then 0
    else
      let rec power_recu x n =
        if n = 0
        then 1
        else
          if n = 1
          then x
          else
            if (n mod 2 = 0)
            then let res = power_recu x (n / 2) in res * res
            else let res = power_recu x (n / 2) in res * res * x
	  in power_recu x n

let main() =
  print_string "power 0 100: ";
  print_int (ft_power 0 100);
  print_endline "";
  print_string "power 2 4: ";
  print_int (ft_power 2 4);
  print_endline "";
  print_string "power 2 7: ";
  print_int (ft_power 2 7);
  print_endline "";
  print_string "power 3 10: ";
  print_int (ft_power 3 10);
  print_endline ""

let () = main ()
