(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   ft_print_comb2.ml                                  :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 01:03:21 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 01:08:57 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let ft_print_comb2 () =
	let rec print_comb2 n m isFirst =
	if n < 100
	then
		let a = (n / 10) in
		let b = (n mod 10) in
		let c = (m / 10) in
		let d = (m mod 10) in
		begin
			if n < m
			then
				begin
					if not isFirst
					then begin print_char ','; print_char ' ' end;
					print_int a;
					print_int b;
					print_char ' ';
					print_int c;
					print_int d
				end;
			if m = 99
			then print_comb2 (n + 1) (n + 1) false
			else print_comb2 n (m + 1) false
		end
	in print_comb2 0 1 true;
	print_char '\n'

let main () =
	ft_print_comb2 ()

let () = main ()
