(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   ft_countdown.ml                                    :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/17 18:57:31 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/17 19:07:52 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let ft_countdown i =
  if i >= 0
  then
    let rec print_recu m =
      if m >= 0
      then
        begin
          print_endline (string_of_int m);
          print_recu (m - 1)
        end
    in print_recu i
  else
    print_endline "0"

let main () =
  begin
    ft_countdown 5;
    print_endline "";
    ft_countdown 2;
    print_endline "";
    ft_countdown 0;
    print_endline "";
    ft_countdown (-2)
  end

let () = main ()
