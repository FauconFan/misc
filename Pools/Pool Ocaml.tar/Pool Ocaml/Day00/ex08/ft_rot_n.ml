(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   ft_rot_n.ml                                        :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 00:44:20 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 00:56:00 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let ft_rot_n n str =
	let ft_rot_char_n n c =
		if c >= 'a' && c <= 'z'
		then char_of_int (((int_of_char c) + n - (int_of_char 'a')) mod 26 + int_of_char 'a')
		else
			begin
				if c >= 'A' && c <= 'Z'
				then char_of_int (((int_of_char c) + n - (int_of_char 'A')) mod 26 + int_of_char 'A')
				else c
			end
	in String.map (ft_rot_char_n n) str

let main () =
	print_endline (ft_rot_n 5 "Zabcdef");
	print_endline (ft_rot_n 5 "0123456789");
	print_endline (ft_rot_n 5 "abcdefghijklmnopqrstuvwxyz");

let () = main ()
