(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   ft_string_all.ml                                   :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 00:26:05 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 00:34:47 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let ft_string_all f s =
	let rec loop f s i =
		if i >= (String.length s)
		then true
		else
			if (f (String.get s i)) = false
			then false
			else loop f s (i + 1)
	in loop f s 0

let main () =
	let is_digit c = c >= '0' && c <= '9' in
	let is_alpha c = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') in
	print_endline (string_of_bool (ft_string_all is_digit "56789"));
	print_endline (string_of_bool (ft_string_all is_alpha "djazjkdja"));
	print_endline (string_of_bool (ft_string_all is_digit "5dsd6789"));
	print_endline (string_of_bool (ft_string_all is_alpha "djazj67kdja"))

let () = main ()
