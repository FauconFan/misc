(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   ft_print_comb.ml                                   :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/17 23:26:28 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 00:17:02 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let ft_print_comb () =
	let rec print_comb n isFirst =
		if n < 1000
		then
			let a = (n / 100) in
			let b = ((n / 10) mod 10) in
			let c = (n mod 10) in
			begin
				if a < b && b < c
				then
					begin
						if not isFirst
						then print_string ", ";
						print_int a;
						print_int b;
						print_int c
					end;
				print_comb (n + 1) false
			end
	in print_comb 12 true;
	print_string "\n"

let main () =
	ft_print_comb ()

let () = main ()
