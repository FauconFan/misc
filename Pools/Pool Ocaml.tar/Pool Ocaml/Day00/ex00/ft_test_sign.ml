(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   ft_test_sign.ml                                    :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/17 18:35:35 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/17 18:55:51 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let ft_test_sign i =
  let str =
    if i >= 0
    then "positive"
    else "negative"
  in print_endline str

let main () =
  begin
    ft_test_sign 1;
    ft_test_sign 0;
    ft_test_sign (-1)
  end

let () = main ()
