(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   ft_graphics.ml                                     :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/19 15:34:56 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/19 17:12:51 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

type 'a tree = Nil | Node of 'a * 'a tree * 'a tree

let draw_square x y size =
	let s = if size > 0 then size else size * (-1) in
	if s <> 0 then
		begin
			Graphics.moveto (x - s / 2) (y - s / 2);
			Graphics.lineto (x - s / 2) (y + s / 2);
			Graphics.lineto (x + s / 2) (y + s / 2);
			Graphics.lineto (x + s / 2) (y - s / 2);
			Graphics.lineto (x - s / 2) (y - s / 2);
		end

let ft_draw_node x y size str =
	draw_square x y size;
	Graphics.moveto (x - 8) (y - 4);
	Graphics.draw_string str

let draw_tree_node node =
	let size_node = 50 in
	let width_l = 80 in
	let height_l = 40 in
	let rec draw node x y = match node with
	| Nil -> ft_draw_node x y size_node "Nil"
	| Node (v, l, r) ->
		begin
			let r_node = x + size_node / 2 in
			let l_n_node = r_node + width_l in
			let u_n_node = y + height_l in
			let d_n_node = y - height_l in

			ft_draw_node x y size_node v;
			Graphics.moveto r_node   y;
			Graphics.lineto l_n_node u_n_node;
			Graphics.moveto r_node   y;
			Graphics.lineto l_n_node d_n_node;

			draw l (l_n_node + size_node / 2) u_n_node;
			draw r (l_n_node + size_node / 2) d_n_node
		end
	in
	draw node 40 (Graphics.size_y () / 2)

let () =
	(* let empty_tree = Nil in *)
	let simple_tree = Node ("0", Nil, Node ("1", Nil, Node ("2", Nil, Nil))) in
	Graphics.open_graph " 800x800";
	draw_tree_node simple_tree;
	ignore (Graphics.read_key ())
