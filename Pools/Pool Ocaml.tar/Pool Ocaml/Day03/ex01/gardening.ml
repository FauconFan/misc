(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   gardening.ml                                       :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/19 15:34:56 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/19 17:44:28 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

type 'a tree = Nil | Node of 'a * 'a tree * 'a tree

let rec size tree = match tree with
	| Nil -> 0
	| Node (_, l, r) -> 1 + size l + size r

let rec height tree = match tree with
	| Nil -> 0
	| Node (_, l, r) -> 1 + (max (height l) (height r))

let rec pow x n = match n with
	| n when n <= 0 	-> 1
	| 1 				-> x
	| n 				-> let n = pow x (n / 2) in
							if (n mod 2) = 0 then n * n
							else n * n * x

let pow2 n = pow 2 n

let draw_square x y size =
	let s = if size > 0 then size else size * (-1) in
	if s <> 0 then
		begin
			Graphics.moveto (x - s / 2) (y - s / 2);
			Graphics.lineto (x - s / 2) (y + s / 2);
			Graphics.lineto (x + s / 2) (y + s / 2);
			Graphics.lineto (x + s / 2) (y - s / 2);
			Graphics.lineto (x - s / 2) (y - s / 2);
		end

let ft_draw_node x y size str =
	draw_square x y size;
	Graphics.moveto (x - 8) (y - 4);
	Graphics.draw_string str

let draw_tree tree =
	let size_node = 50 in
	let width_l = 80 in
	let height_l = 40 in
	let rec draw tree x y depth = match tree with
	| Nil 				-> ft_draw_node x y size_node "Nil"
	| Node (v, l, r) 	->
		begin
			let r_node = x + size_node / 2 in
			let l_n_node = r_node + width_l in
			let u_n_node = y + (height_l * depth) in
			let d_n_node = y - (height_l * depth) in

			ft_draw_node x y size_node v;
			Graphics.moveto r_node   y;
			Graphics.lineto l_n_node u_n_node;
			Graphics.moveto r_node   y;
			Graphics.lineto l_n_node d_n_node;

			draw l (l_n_node + size_node / 2) u_n_node (depth / 2);
			draw r (l_n_node + size_node / 2) d_n_node (depth / 2)
		end
	in
	draw tree 40 (Graphics.size_y () / 2) (pow2 (height tree))

let () =
	let l_tree =
		Node ("Left", Node ("L_l", Nil, Nil), Node ("L_r", Nil, Nil)) in
	let r_tree =
		Node ("Right", Nil, Node ("R_r", Nil, Nil)) in
	let simple_tree = Node ("Root", l_tree, r_tree) in
	Graphics.open_graph " 800x800";
	draw_tree simple_tree;
	ignore (Graphics.read_key ())
