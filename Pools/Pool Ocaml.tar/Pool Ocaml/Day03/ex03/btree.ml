(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   btree.ml                                           :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/19 19:48:04 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/19 22:16:26 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

type 'a tree = Nil | Node of 'a * 'a tree * 'a tree

type 'a option = None | Some of 'a

let rec height tree = match tree with
	| Nil -> 0
	| Node (_, l, r) -> 1 + (max (height l) (height r))

let rec equity t1 t2 = match (t1, t2) with
	| (Nil, Nil)		-> true
	| (_, Nil)			-> false
	| (Nil, _)			-> false
	| (Node (v1, l1, r1), Node (v2, l2, r2))
						-> (v1 == v2) && (equity l1 l2) && (equity r1 r2)

let is_bst ?perfect_test:(pt = false) tree =
	let rec rec_is_bst head mi ma =
		match head with
		| Nil 				-> true
		| Node (v, l, r) 	->
			let validate_min v mi = match mi with
				| None 		-> true
				| Some i	-> i <= v
			in
			let validate_max v ma = match ma with
				| None		-> true
				| Some i	-> v <= i
			in
			let is_perfect_test v l r pt =
				if not pt then true
				else match (l, r) with
				| (Nil, Nil) 							-> true
				| (Node (v1, _, _), Node (v2, _, _))	-> (v - v1) == (v2 - v)
				| _										-> false
			in
			(validate_min v mi) && (validate_max v ma) &&
			(is_perfect_test v l r pt) &&
				(rec_is_bst l mi (Some v)) &&
				(rec_is_bst r (Some v) ma)
	in rec_is_bst tree None None

let is_perfect tree = is_bst ~perfect_test:true tree

let rec is_balanced tree = match tree with
	| Nil 				-> true
	| Node (v, l, r) 	->
		let l_height = height l in
		let r_height = height r in
		let diff = abs (l_height - r_height) in

		(diff <= 1) && is_balanced l && is_balanced r

let rec search_bst v tree = match tree with
	| Nil 				-> false
	| Node (head, l, r)	->
		if head == v then true
		else if head > v then search_bst v l
		else search_bst v r

let rec add_bst v tree = match tree with
	| Nil 				-> Node (v, Nil, Nil)
	| Node (head, l, r) ->
		if head >= v then Node (head, (add_bst v l), r)
		else Node (head, l, (add_bst v r))

let rec delete_bst ?delete_more:(dm = false) v tree =
	match tree with
	| Nil 				-> Nil
	| Node (head, l, r)	->
		if head > v then Node (head, (delete_bst ~delete_more:dm v l), r)
		else if head < v then Node (head, l, (delete_bst ~delete_more:dm v r))
		else
			let rec minValueNode tree cand = match tree with
				| Nil | Node (_, Nil, _)	-> cand
				| Node (h, l, _)			-> minValueNode l h
			in
			match (l, r) with
			| (Nil, Nil)			-> Nil
			| (Nil, _)				-> if dm then delete_bst ~delete_more:false v r else r
			| (_, Nil)				-> if dm then delete_bst ~delete_more:false v l else l
			| (_, Node (h, _, _))	->
				let minRight = minValueNode r h in
				let newRoot = Node (minRight, l, (delete_bst ~delete_more:false minRight r)) in

				if dm then (delete_bst ~delete_more:dm v newRoot)
				else newRoot

(* let rec pow x n = match n with
	| n when n <= 0 	-> 1
	| 1 				-> x
	| n 				-> let n = pow x (n / 2) in
							if (n mod 2) = 0 then n * n
							else n * n * x

let pow2 n = pow 2 n

let draw_square x y size =
	let s = if size > 0 then size else size * (-1) in
	if s <> 0 then
		begin
			Graphics.moveto (x - s / 2) (y - s / 2);
			Graphics.lineto (x - s / 2) (y + s / 2);
			Graphics.lineto (x + s / 2) (y + s / 2);
			Graphics.lineto (x + s / 2) (y - s / 2);
			Graphics.lineto (x - s / 2) (y - s / 2);
		end

let ft_draw_node x y size str =
	draw_square x y size;
	Graphics.moveto (x - 8) (y - 4);
	Graphics.draw_string (string_of_int str)

let draw_tree tree =
	let size_node = 50 in
	let width_l = 80 in
	let height_l = 40 in
	let rec draw tree x y depth = match tree with
	| Nil 				-> ft_draw_node x y size_node (-1)
	| Node (v, l, r) 	->
		begin
			let r_node = x + size_node / 2 in
			let l_n_node = r_node + width_l in
			let u_n_node = y + (height_l * depth) in
			let d_n_node = y - (height_l * depth) in

			ft_draw_node x y size_node v;
			Graphics.moveto r_node   y;
			Graphics.lineto l_n_node u_n_node;
			Graphics.moveto r_node   y;
			Graphics.lineto l_n_node d_n_node;

			draw l (l_n_node + size_node / 2) u_n_node (depth / 2);
			draw r (l_n_node + size_node / 2) d_n_node (depth / 2)
		end
	in
	draw tree 40 (Graphics.size_y () / 2) (pow2 (height tree)) *)

let () =
	let t1 = Node (3,
				Node (2,
					Node (1, Nil, Nil),
					Nil),
				Node (4, Nil, Nil)) in
	let t2 = Node (4,
				Node (2,
					Node (1, Nil, Nil),
					Node (3, Nil, Nil)),
				Node (6, Nil, Nil)) in
	let t3 = Node (3, Node (1, Nil, Node (4, Nil, Nil)), Nil) in
	let t4 = Node (3, Nil, Node (4, Node (1, Nil, Nil), Nil)) in
	let t5 = Node (3, Nil, Node (5, Nil, Node (4, Nil, Nil))) in
	let t1_5 = add_bst 5 (add_bst 5 t1) in
	let t2_5 = add_bst 5 t2 in
	let t1_n5 = delete_bst 5 t1_5 in
	let t2_n5 = delete_bst 5 t2_5 in
	let t1_nn5 = delete_bst ~delete_more:true 5 t1_5 in
	let pprint b1 b2 =
		print_string ("\tMust be " ^ (string_of_bool b1) ^ ":\t");
		print_endline (if b1 = b2 then "OK" else "KO")
	in

	print_endline "----- is_bst -----";
	pprint true  (is_bst t1);
	pprint true  (is_bst t2);
	pprint false (is_bst t3);
	pprint false (is_bst t4);
	pprint false (is_bst t5);
	print_endline "----- is_prefect_bst -----";
	pprint false (is_perfect t1);
	pprint true  (is_perfect t2);
	pprint false (is_perfect t3);
	pprint false (is_perfect t4);
	pprint false (is_perfect t5);
	print_endline "----- is_balanced -----";
	pprint true  (is_balanced t1);
	pprint true  (is_balanced t2);
	pprint false (is_balanced t3);
	pprint false (is_balanced t4);
	pprint false (is_balanced t5);
	print_endline "----- search_bst 5 -----";
	pprint false (search_bst 5 t1);
	pprint false (search_bst 5 t2);
	pprint false (search_bst 5 t3);
	pprint false (search_bst 5 t4);
	pprint true  (search_bst 5 t5);
	print_endline "----- search_bst 5 after added -----";
	pprint true (search_bst 5 t1_5);
	pprint true (search_bst 5 t2_5);
	print_endline "----- is_bst after added -----";
	pprint true  (is_bst t1_5);
	pprint true  (is_bst t2_5);
	print_endline "----- search_bst 5 after added after delete once -----";
	pprint true  (search_bst 5 t1_n5);
	pprint false (search_bst 5 t2_n5);
	print_endline "----- is_bst after added after delete once -----";
	pprint true  (is_bst t1_n5);
	pprint true  (is_bst t2_n5);
	print_endline "----- search_bst 5 after added after delete all -----";
	pprint false  (search_bst 5 t1_nn5);
	print_endline "----- is_bst after added after delete all -----";
	pprint true  (is_bst t1_nn5)

	(* Graphics.open_graph " 800x800";
	draw_tree t1_n5;
	ignore (Graphics.read_key ()) *)
