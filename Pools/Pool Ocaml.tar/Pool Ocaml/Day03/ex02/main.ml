(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   main.ml                                            :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/19 18:12:29 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/19 19:22:06 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let default_method str = str

let apply f n str = f str n

let assoc_key_method str = match str with
	| "rot42" 		-> (Cipher.rot42, Uncipher.unrot42)
	| "caesar 7"	-> ((apply Cipher.caesar 7), (apply Uncipher.uncaesar 7))
	| "caesar 16"	-> ((apply Cipher.caesar 16), (apply Uncipher.uncaesar 16))
	| "xor 42"		-> ((apply Cipher.xor 42), (apply Uncipher.unxor 42))
	| "xor 108"		-> ((apply Cipher.xor 108), (apply Uncipher.unxor 108))
	| "ft_crypt C7; X78; Rot 42"
					-> (
							(apply Cipher.ft_crypt
								[(apply Cipher.caesar 7);
									(apply Cipher.xor 78);
									Cipher.rot42]),
							(apply Uncipher.ft_uncrypt
								[(apply Uncipher.uncaesar 7);
									(apply Uncipher.unxor 78);
									Uncipher.unrot42])
						)
	| "ft_crypt X 121; C13; X1"
					-> let list_func = [
						(apply Cipher.xor 121);
						(apply Cipher.caesar 13);
						(apply Cipher.xor 1)]
							in ((apply Cipher.ft_crypt list_func),
								(apply Uncipher.ft_uncrypt list_func))
	| _ 			-> (default_method, default_method)

let bench_test_func () =
	"rot42" :: "caesar 7" :: "caesar 16" :: "xor 42" :: "xor 108" ::
	"ft_crypt C7; X78; Rot 42" :: "ft_crypt X 121; C13; X1" :: []

let bench_test_str () =
	["hello world !"; "Light of the Moon"; "221b Baker Street"; "123456789"]

let () =
	let rec loop_func li_func = match li_func with
		| [] 			-> print_newline ()
		| head :: tail 	->
			begin
				let rec loop_func_str func_str li_str = match li_str with
					| [] -> print_newline ()
					| head :: tail ->
						begin
							let encrypt = fst (assoc_key_method func_str) in
							let decrypt = snd (assoc_key_method func_str) in
							let encrypted = encrypt head in
							let decrypted = decrypt encrypted
							in
							print_endline ("----- " ^ head ^ " -----");
							print_endline ("\tciphered   : " ^ encrypted);
							print_endline ("\tunciphered : " ^ decrypted);
							print_newline ();
							loop_func_str func_str tail
						end
				in
				print_endline ("===== (un)" ^ head ^ " =====");
				print_newline ();
				loop_func_str head (bench_test_str ());
				loop_func tail
			end
	in
	loop_func (bench_test_func ())
