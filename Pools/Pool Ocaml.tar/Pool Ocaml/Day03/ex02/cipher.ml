(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   cipher.ml                                          :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/19 17:57:03 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/19 19:02:52 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let rot_char_n n c =
	let cipher n i =
		let rec _cipher i =
			if i < 0 then _cipher (i + 26)
			else if i >= 26 then _cipher (i mod 26)
			else i
		in
		_cipher (n + i)
	in
	let rotate base n c =
		char_of_int (base + (cipher n ((int_of_char c) - base)))
	in
	match c with
	| 'a' .. 'z' -> rotate (int_of_char 'a') n c
	| 'A' .. 'Z' -> rotate (int_of_char 'A') n c
	| _ -> c

let rot42 str = String.map (rot_char_n 42) str

let caesar str key = String.map (rot_char_n key) str

let xor str key =
	let xor_char key c =
		char_of_int (key lxor (int_of_char c))
	in
	String.map (xor_char key) str

let rec ft_crypt str li_func = match li_func with
	| [] 			-> str
	| head :: tail 	-> ft_crypt (head str) tail
