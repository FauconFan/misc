(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   uncipher.ml                                        :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/19 17:57:09 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/19 19:18:32 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let unrot42 str = String.map (Cipher.rot_char_n (-42)) str

let uncaesar str key = String.map (Cipher.rot_char_n (-key)) str

let unxor str key = Cipher.xor str key

let rec ft_uncrypt str li_func = match li_func with
	| [] 			-> str
	| head :: tail 	-> head (ft_uncrypt str tail)
