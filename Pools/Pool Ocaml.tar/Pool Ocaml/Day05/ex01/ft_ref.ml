(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   ft_ref.ml                                          :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/21 20:53:28 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/21 21:07:42 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

type 'a ft_ref = {mutable value : 'a}

let return x = {value = x}

let get r = r.value

let set r x = r.value <- x

let bind r f = let a = f (get r) in return (get a)
