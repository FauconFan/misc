(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   jokes.ml                                           :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/21 21:12:31 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/21 22:25:19 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let data =
	[|
		"Il y a 10 types de personnes : Ceux qui connaissent le binaire, les autres, et ceux qui ne s'attendaient pas à une blague en base 3.";
		"Logarithme et Exponentielle sont dans un bar. Qui paie l'addition ?";
		"Why is Peter Pan always flying ? He neverlands. (This joke never gets old.)";
		"p pair et q pair.";
		"Tu connais la blague de la patate ? Purée, j'ai oublié...";
		"C'est l'histoire d'un pingouin qui respire par les fesses. Un jour il s’assoit et il meurt.";
		"Comment s'appelle le cul de la Schtroumpfette ? Le blu-ray";
		"Quel est le point commun entre les math et le sexe ? Plus il y a d’inconnues, plus c’est chaud.";
		"Quel est le pays le plus cool du monde? Le Yémen."
	|]

let _ = Random.self_init ()

let () =
	let rand = Random.int (Array.length data) in
	print_string (Array.get data rand);
	print_char '\n';
