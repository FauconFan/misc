(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   micronap.ml                                        :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/21 20:40:46 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/21 20:51:40 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let my_sleep () = Unix.sleep 1

let rec sleeping i =
	if i == 0 then print_endline "AWAKE !!"
	else
		begin
			print_endline ("Sleeping for " ^ (string_of_int i) ^ "... Zzzzz");
			my_sleep ();
			sleeping (i - 1)
		end

let () =
	let argv = Sys.argv in

	if Array.length argv == 2 then
		begin
			let s = Array.get argv 1 in
			let i = int_of_string_opt s in
			match i with
				| None		-> print_endline "Invalid argument"
				| Some i	-> if i <= 0 then print_endline "Already awaken"
								else sleeping i
		end
