(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   jokes.ml                                           :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/21 22:28:24 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/22 00:01:46 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let _ = Random.self_init ()

let print_random data =
	let rand = Random.int (Array.length data) in
	print_string (Array.get data rand);
	print_char '\n'

let main path_file =
	let array_data = ref [|"No jokes"|] in
		begin try
			let channel = open_in path_file in
			let data = really_input_string channel (in_channel_length channel) in
			let li_data = String.split_on_char '\n' data in
			let li_data = List.filter (fun s -> s <> "") li_data in

			array_data := Array.of_list li_data;
			close_in channel;
		with
		| Sys_error err -> print_endline "File Name is wrong" ; ignore(exit 1)
	end;
	print_random !array_data

let () =
	let av = Sys.argv in
	let ac = Array.length Sys.argv in

	if ac <> 2 then print_endline "single argument required..."
	else main (Array.get av 1)
