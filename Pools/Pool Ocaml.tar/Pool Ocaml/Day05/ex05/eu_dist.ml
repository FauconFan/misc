(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   eu_dist.ml                                         :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/22 00:50:27 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/22 01:00:42 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let eu_dist a b =
	if Array.length a <> Array.length b then (-1.0)
	else
		begin
			let res = ref 0.0 in
			let data = Array.init (Array.length a)
					(fun i -> (Array.get a i, Array.get b i)) in
			let pow2 x = x *. x in
			let sum elem = res := !res +. (pow2 ((fst elem) -. (snd elem))) in

			Array.iter sum data;
			sqrt !res
		end


let () =
	let a = [|2.0; 3.0; 4.2; 5.7; 7.8|] in
	let b = [|1.0; 3.0; 5.8; 4.2; 2.1|] in
	let c = [|0.0; 0.0|] in
	let d = [|1.0; 1.0|] in
	let f = eu_dist a b in
	let g = eu_dist c d in

	print_endline (string_of_float f);
	print_endline (string_of_float g)
