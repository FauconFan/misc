(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   examples_of_files.ml                               :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/22 01:19:58 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/22 01:49:59 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let examples_of_files path =
	let data = ref [] in

	begin try
			let ic = open_in path in
			let rec get_lines ic =
				begin try
					let line = input_line ic in
					let build_line line =
						let sp = String.split_on_char ',' line in
						let size = List.length sp in

						if size == 0 then ([||], "")
						else
							let last = List.nth sp (size - 1) in
							let not_last =
								List.rev (List.tl (List.rev sp)) in
							let not_last = List.map float_of_string not_last in
							let not_last = Array.of_list not_last in
							(not_last, last)
					in
					data := (build_line line) :: !data;
					get_lines ic
					with
					| End_of_file -> close_in ic
				end
			in
			get_lines ic
		with
		| Sys_error str		-> print_endline str
	end;
	List.rev !data
