(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   main.ml                                            :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/20 15:50:43 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/20 16:05:38 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let () =
	let s4 = Card.newCard T4 Spade in
	let c10 = Card.newCard T10 Club in
	let dj = Card.newCard Jack Diamond in
	let h6 = Card.newCard T6 Heart in
	let d6 = Card.newCard T6 Diamond in
	let allActu = [s4;c10;dj;h6] in

	print_endline (Card.toStringVerbose s4);
	print_endline (Card.toStringVerbose c10);
	print_endline (Card.toStringVerbose dj);
	print_endline (Card.toStringVerbose h6);
	print_newline ();
	print_endline ("best list : " ^ (Card.toStringVerbose (Card.best allActu)));
	print_endline ("best Spades : " ^
			(Card.toStringVerbose (Card.best (Card.allSpades))));
	print_endline ("best Clubs : " ^
			(Card.toStringVerbose (Card.best (Card.allClubs))));
	print_endline ("compare C10 S4 : " ^ (string_of_int (Card.compare c10 s4)));
	print_endline ("compare S4 C10 : " ^ (string_of_int (Card.compare s4 c10)));
	print_endline ("compare S4 S4 : " ^ (string_of_int (Card.compare s4 s4)));
	print_endline ("isSpade S4 : " ^ (string_of_bool (Card.isSpade s4)));
	print_endline ("isSpade C10 : " ^ (string_of_bool (Card.isSpade c10)));
	print_endline ("min H6 D6 : " ^ (Card.toString (Card.min h6 d6)));
	print_endline ("min H6 C10 : " ^ (Card.toString (Card.min h6 c10)));
	print_endline ("max H6 D6 : " ^ (Card.toString (Card.max h6 d6)));
	print_endline ("max H6 C10 : " ^ (Card.toString (Card.max h6 c10)))
