(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   main.ml                                            :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/20 14:54:26 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/20 14:58:14 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let () =
	let rec pprint_color_li li_colors = match li_colors with
	| []			-> ignore ()
	| head :: tail	->
		print_endline (
			(Color.toString head) ^ " : " ^ (Color.toStringVerbose head));
		pprint_color_li tail
	in pprint_color_li Color.all
