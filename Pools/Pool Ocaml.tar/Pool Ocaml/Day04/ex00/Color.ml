(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   Color.ml                                           :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/20 14:51:01 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/20 14:54:01 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

type t = Spade | Heart | Diamond | Club

let all = [Spade; Heart; Diamond; Club]

let toString t = match t with
	| Spade		-> "S"
	| Heart		-> "H"
	| Diamond	-> "D"
	| Club		-> "C"

let toStringVerbose t = match t with
	| Spade		-> "Spade"
	| Heart		-> "Heart"
	| Diamond	-> "Diamond"
	| Club		-> "Club"
