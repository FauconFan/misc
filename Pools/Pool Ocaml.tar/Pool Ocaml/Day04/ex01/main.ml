(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   main.ml                                            :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/20 15:08:52 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/20 15:20:39 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let () =
	let pprint_val v = (Value.toString v) ^ " : " ^ (Value.toStringVerbose v) in
	let rec pprint li = match li with
		| []				-> ignore ()
		| head :: tail		->
			begin
				print_endline ("===== " ^ (Value.toStringVerbose head)
							^ " =====");
				print_endline ("\t" ^ (pprint_val head));
				print_endline ("\ttoInt\t-> " ^ (string_of_int (Value.toInt head)));
				if head <> T2 then
				print_endline ("\tprev\t-> " ^ (pprint_val (Value.previous head)));
				if head <> As then
				print_endline ("\tnext\t-> " ^ (pprint_val (Value.next head)));
				print_newline ();
				pprint tail
			end
	in
	pprint Value.all
