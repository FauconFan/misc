(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   main.ml                                            :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/20 16:22:48 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/20 16:54:46 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let () =
	let rec list_apply f li = match li with
			| []				-> ignore ()
			| head :: tail		-> f head; list_apply f tail in
	let print_s_card s = print_string s; print_char ' ' in
	let d = Deck.newDeck () in
	let d_ = Deck.newDeck () in
	let t = Deck.drawCard d in
	let d2 = snd t in
	let c = fst t in

	print_endline ("size default : " ^ (string_of_int (Deck.size d)));
	print_endline ("drawn card : " ^ (Deck.Card.toStringVerbose c));
	print_endline ("new size : " ^ (string_of_int (Deck.size d2)));
	list_apply print_s_card (Deck.toStringList d); print_newline ();
	list_apply print_s_card (Deck.toStringList d_); print_newline ()
