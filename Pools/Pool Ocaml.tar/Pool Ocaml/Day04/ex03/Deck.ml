(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   Deck.ml                                            :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/20 15:22:13 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/20 16:54:50 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

module Card = struct

	module Color = struct

		type t = Spade | Heart | Diamond | Club

		let all = [Spade; Heart; Diamond; Club]

		let toString t = match t with
			| Spade		-> "S"
			| Heart		-> "H"
			| Diamond	-> "D"
			| Club		-> "C"

		let toStringVerbose t = match t with
			| Spade		-> "Spade"
			| Heart		-> "Heart"
			| Diamond	-> "Diamond"
			| Club		-> "Club"

	end

	module Value = struct

		type t = T2
				| T3
				| T4
				| T5
				| T6
				| T7
				| T8
				| T9
				| T10
				| Jack
				| Queen
				| King
				| As

		let all = [T2; T3; T4; T5; T6; T7; T8; T9; T10; Jack; Queen; King; As]

		let toInt t = match t with
			| T2		-> 1
			| T3		-> 2
			| T4		-> 3
			| T5		-> 4
			| T6		-> 5
			| T7		-> 6
			| T8		-> 7
			| T9		-> 8
			| T10		-> 9
			| Jack		-> 10
			| Queen		-> 11
			| King		-> 12
			| As		-> 13

		let toString t = match t with
			| T2		-> "2"
			| T3		-> "3"
			| T4		-> "4"
			| T5		-> "5"
			| T6		-> "6"
			| T7		-> "7"
			| T8		-> "8"
			| T9		-> "9"
			| T10		-> "10"
			| Jack		-> "J"
			| Queen		-> "Q"
			| King		-> "K"
			| As		-> "A"

		let toStringVerbose t = match t with
			| T2		-> "2"
			| T3		-> "3"
			| T4		-> "4"
			| T5		-> "5"
			| T6		-> "6"
			| T7		-> "7"
			| T8		-> "8"
			| T9		-> "9"
			| T10		-> "10"
			| Jack		-> "Jack"
			| Queen		-> "Queen"
			| King		-> "King"
			| As		-> "As"

		let next t = match t with
			| T2		-> T3
			| T3		-> T4
			| T4		-> T5
			| T5		-> T6
			| T6		-> T7
			| T7		-> T8
			| T8		-> T9
			| T9		-> T10
			| T10		-> Jack
			| Jack		-> Queen
			| Queen		-> King
			| King		-> As
			| As		-> invalid_arg "Cannot get next on As"

		let previous t = match t with
			| T2		-> invalid_arg "Cannot get previous on T2"
			| T3		-> T2
			| T4		-> T3
			| T5		-> T4
			| T6		-> T5
			| T7		-> T6
			| T8		-> T7
			| T9		-> T8
			| T10		-> T9
			| Jack		-> T10
			| Queen		-> Jack
			| King		-> Queen
			| As		-> King

	end

	type t = Value.t * Color.t

	let newCard (v:Value.t) (c:Color.t) = ((v, c):t)

	let allSpades = let rev_newCard v c = newCard c v in
			List.map (rev_newCard Spade) Value.all

	let allHearts = let rev_newCard v c = newCard c v in
			List.map (rev_newCard Heart) Value.all

	let allDiamonds = let rev_newCard v c = newCard c v in
			List.map (rev_newCard Diamond) Value.all

	let allClubs = let rev_newCard v c = newCard c v in
			List.map (rev_newCard Club) Value.all

	let all = allSpades @ allHearts @ allDiamonds @ allClubs

	let getValue (t:t) = fst t

	let getColor (t:t) = snd t

	let toString (t:t) = (Value.toString (getValue t)) ^
							(Color.toString (getColor t))

	let toStringVerbose (t:t) = "Card(" ^ (Value.toStringVerbose (getValue t))
								^ ", " ^ (Color.toStringVerbose (getColor t)) ^ ")"

	let compare (t1:t) (t2:t) =
			let n1 = Value.toInt (getValue t1) in
			let n2 = Value.toInt (getValue t2) in

			if n1 = n2 then 0
			else if n1 < n2 then (-1)
			else 1

	let max (t1:t) (t2:t) =
			let n1 = Value.toInt (getValue t1) in
			let n2 = Value.toInt (getValue t2) in

			if n1 < n2 then t2
			else t1

	let min (t1:t) (t2:t) =
			let n1 = Value.toInt (getValue t1) in
			let n2 = Value.toInt (getValue t2) in

			if n1 > n2 then t2
			else t1

	let best t_li = match t_li with
		| []				-> invalid_arg "Can't call best on empty list"
		| head :: tail		-> List.fold_left max head tail

	let isOf t c = c == (getColor t)

	let isSpade t = isOf t Spade

	let isHeart t = isOf t Heart

	let isDiamond t = isOf t Diamond

	let isClub t = isOf t Club

end

type t = Card.t list

let _ = Random.self_init ()

let newDeck () =
	let sortedDeck = Card.all in
	let rec addInList li elem n = match li with
				| []			-> [elem]
				| head :: tail	-> if n <= 0 then elem :: li
								else head :: (addInList tail elem (n - 1)) in
	let randomAddInList li elem =
				addInList li elem (Random.int ((List.length li) + 1)) in
	let rec unsort old res = match old with
				| []			-> res
				| head :: tail	-> unsort tail (randomAddInList res head) in
	match sortedDeck with
	| []				-> failwith "Impossible : sortedDeck can't be empty."
	| head :: tail		-> unsort tail [head]

let rec toStringList (t:t) = match t with
	| []			-> []
	| head :: tail	-> (Card.toString head) :: toStringList tail

let rec toStringVerboseList (t:t) = match t with
	| []			-> []
	| head :: tail	-> (Card.toStringVerbose head) :: toStringVerboseList tail

let drawCard (t:t) = match t with
	| []			-> failwith "Can't draw card on empty card"
	| head :: tail	-> (head, tail)

let size (t:t) = List.length t
