Bullshit day
