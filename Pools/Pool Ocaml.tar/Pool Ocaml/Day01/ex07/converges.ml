(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   converges.ml                                       :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 10:53:10 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 11:04:09 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let converges f x limit =
	if limit <= 0 then false
	else
		let rec con_rec f limit cand old =
			if limit >= 0 && cand == old then true
			else if limit < 0 then false
			else con_rec f (limit - 1) (f cand) cand
		in con_rec f (limit) (f x) x

let main () =
	print_endline (string_of_bool (converges (( * ) 2) 2 3));
	print_endline (string_of_bool (converges (fun x -> x / 2) 2 1));
	print_endline (string_of_bool (converges (fun x -> x / 2) 2 2));
	print_endline (string_of_bool (converges (fun x -> x / 2) 2 3));
	print_endline (string_of_bool (converges (fun x -> x) 1 0));
	print_endline (string_of_bool (converges (fun x -> x) 1 1))

let () = main ()
