(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   leibniz_pi.ml                                      :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 11:15:06 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 11:45:50 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let leibniz_pi ?debug:(d = false) delta =
	let _ref = (4. *. (atan 1.0)) in
	let _abs fl = if fl > 0. then fl else fl *. -1. in
	let _diff fl = _abs (fl -. _ref) in
	let _compute i =
		let fi = float_of_int i in
		let num = if (i mod 2) == 0 then 4. else -4. in
		let den = 2. *. fi +. 1. in
		num /. den in
	let rec loop delta pi_actu res =
		if _diff (pi_actu) < delta
		then
			if d then
				begin
					print_endline ("Debug pi : " ^ string_of_float pi_actu); res
				end
			else res
		else
			loop delta (pi_actu +. (_compute res)) (res + 1)
	in loop delta 0. 0

let main () =
	let pprint ?debug:(d = false) app =
		let res = leibniz_pi ~debug:d app in
		print_string "leibniz_pi ";
		print_float app;
		print_string " iter => ";
		print_int res;
		print_newline ()
	in
	begin
		pprint (1.);
		pprint (0.1);
		pprint (0.01);
		pprint ~debug:true (0.001);
		pprint ~debug:true (0.0001);
		pprint ~debug:true (0.00001);
		pprint ~debug:true (1e-7)
	end

let () = main ()
