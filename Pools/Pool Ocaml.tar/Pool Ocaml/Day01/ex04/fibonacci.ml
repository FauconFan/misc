(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   fibonacci.ml                                       :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 10:34:15 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 10:40:39 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let fibonacci n =
	if n < 0 then -1
	else
		let rec fib_rec n a b =
			if n == 0 then a
			else if n == 1 then b
			else fib_rec (n - 1) b (a + b)
		in fib_rec n 0 1

let main () =
	let rec loop n ma =
		begin
			print_string "fib ";
			print_int n;
			print_string " => ";
			print_endline (string_of_int (fibonacci n));
			if n < ma then loop (n + 1) ma
		end
	in loop (-3) 10

let () = main ()
