(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   iter.ml                                            :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 10:48:12 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 10:58:25 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let iter f x n =
	if n < 0 then -1
	else
		let rec iter_rec f n res =
			if n == 0 then res
			else iter_rec f (n - 1) (f res)
		in iter_rec f n x

let main () =
	print_endline (string_of_int (iter (fun x -> x * x) 2 4));
	print_endline (string_of_int (iter (fun x -> x * 2) 2 4))

let () = main ()
