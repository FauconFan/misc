(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   repeat_x.ml                                        :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 10:06:32 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 10:08:59 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let repeat_x i =
	if (i < 0) then "Error"
	else
		let rec rep i s =
			if i == 0 then s
			else rep (i - 1) (s ^ "x")
		in rep i ""

let main() =
	print_endline (repeat_x (-2));
	print_endline (repeat_x 0);
	print_endline (repeat_x 2);
	print_endline (repeat_x 5);
	print_endline (repeat_x 10)

let () = main ()
