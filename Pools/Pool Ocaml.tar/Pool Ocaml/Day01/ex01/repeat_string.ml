(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   repeat_string.ml                                   :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 10:10:35 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 10:18:08 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let repeat_string ?str:(s="x") n =
	if (n < 0) then "Error"
	else
		let rec rep i res =
			if i == 0 then res
			else rep (i - 1) (res ^ s)
		in rep n ""

let main() =
	print_endline (repeat_string (-2));
	print_endline (repeat_string 0);
	print_endline (repeat_string 2);
	print_endline (repeat_string 5);
	print_endline (repeat_string 10);
	print_endline (repeat_string ~str:"cou" 2);
	print_endline (repeat_string ~str:"cou" 0);
	print_endline (repeat_string ~str:"cou" 3);
	print_endline (repeat_string ~str:"kaya" 2)

let () = main ()
