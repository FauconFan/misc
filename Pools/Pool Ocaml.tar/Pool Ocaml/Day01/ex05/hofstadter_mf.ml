(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   hofstadter_mf.ml                                   :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 10:41:22 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 10:46:13 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let rec hfs_f n =
	if n < 0 then -1
	else if n == 0 then 1
	else n - hfs_m (hfs_f (n - 1))

and hfs_m n =
	if n < 0 then -1
	else if n == 0 then 0
	else n - hfs_f (hfs_m (n - 1))

let main () =
	let rec loop ini ma =
		print_string "hfs_m ";
		print_int ini;
		print_string " => ";
		print_endline (string_of_int (hfs_m ini));
		print_string "hfs_f ";
		print_int ini;
		print_string " => ";
		print_endline (string_of_int (hfs_f ini));
		if ini < ma then loop (ini + 1) ma
	in loop (-1) 5

let () = main ()
