(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   ackerman.ml                                        :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 10:22:43 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 10:28:59 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let ackerman m n =
	if m < 0 || n < 0 then -1
	else
		let rec real_ackerman m n =
			if m = 0 then n + 1
			else if n = 0 then real_ackerman (m - 1) 1
			else real_ackerman (m - 1) (real_ackerman m (n - 1))
		in real_ackerman m n

let main () =
	print_endline (string_of_int (ackerman (-1) (-1)));
	print_endline (string_of_int (ackerman 0 0));
	print_endline (string_of_int (ackerman 1 0));
	print_endline (string_of_int (ackerman 0 1));
	print_endline (string_of_int (ackerman 1 2));
	print_endline (string_of_int (ackerman 4 1));
	print_endline (string_of_int (ackerman 3 3));
	print_endline (string_of_int (ackerman 3 4))

let () = main ()
