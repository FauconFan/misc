(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   ft_sum.ml                                          :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/18 11:06:14 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/18 11:11:47 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let ft_sum f mi ma =
	if mi > ma then nan
	else
		let rec rec_sum f mi ma res =
			if mi > ma then res
			else rec_sum f (mi + 1) ma (res +. (f (float_of_int mi)))
		in rec_sum f mi ma 0.

let main () =
	print_endline (string_of_float (ft_sum (fun x -> x *. x) 0 10));
	print_endline (string_of_float (ft_sum (fun x -> x *. x) 1 10));
	print_endline (string_of_float (ft_sum (fun x -> x *. x) 10 10));
	print_endline (string_of_float (ft_sum (fun x -> x *. x) 11 10))

let () = main ()
