(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   main.ml                                            :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/24 14:16:07 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/24 14:35:12 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let print_proj (p:App.App.project) = match p with
	| (name, status, grade) ->
		begin
			let out = "Project \'" ^ name ^ "\' " in
			let out = out ^ "has grade : " ^ (string_of_int grade) in
			let pp suff () = print_endline (out ^ suff) in

			if status = "succeed" then pp " and has succeed" ()
			else if status = "failed" then pp " and has failed" ()
			else pp "" ()
		end

let () =
	let z = App.App.zero in
	let p1 = (("Nairobi", "", 42)) in
	let p1s = App.App.success p1 in
	let p1f = App.App.fail p1 in
	let p2 = (("FailedByNature", "failed", 0)) in

	print_proj z;
	print_proj p1;
	print_proj p1s;
	print_proj p1f;
	print_proj p2;
	print_proj (App.App.combine p1 p2)
