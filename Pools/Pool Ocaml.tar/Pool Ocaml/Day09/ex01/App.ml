(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   App.ml                                             :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/24 14:19:04 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/24 14:25:28 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

module App = struct
	type project = string * string * int

	let zero = (("", "", 0):project)

	let combine (p1:project) (p2:project) = match p1 with
		| (name1, _, grade1) ->
			begin
				match p2 with
				| (name2, _, grade2) ->
					begin
						let avg = (grade1 + grade2) / 2 in
						let status = if avg > 80 then "succeed" else "failed" in
						((name1 ^ name2, status, avg):project)
					end
			end

	let fail (p:project) = match p with
		| (name, _, _) -> ((name, "failed", 0):project)

	let success (p:project) = match p with
		| (name, _, _) -> ((name, "succeed", 80):project)
end
