(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   Try.ml                                             :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/24 15:18:25 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/24 16:51:41 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

module Try = struct
	type 'a t = Success of 'a | Failure of exn

	let return (x:'a) = Success x

	let bind a f = match a with
		| Success x		-> f x
		| _				-> a

	let ( >>= ) = bind

	let recover a f = match a with
		| Failure x		-> (f x)
		| _				-> a

	exception FILTER
	exception FLATTEN

	let filter a f = match a with
		| Success x		-> if f x then Success x else Failure FILTER
		| _				-> a

	let flatten a = match a with
		| Failure _		-> Failure FLATTEN
		| Success x		-> x

end
