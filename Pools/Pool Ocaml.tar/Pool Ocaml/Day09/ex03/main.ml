(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   main.ml                                            :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/24 15:22:25 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/24 17:03:39 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let print_try p x = match x with
	| Try.Try.Success a		-> print_string "Success => "; p a; print_newline ()
	| Try.Try.Failure ex	-> print_string ("Failure => " ^ (Printexc.to_string ex) ^ "\n")

let is_uppercase_ascii (str:string) =
	let up = String.uppercase_ascii str in

	if up = str then Try.Try.Success str
	else Try.Try.Failure (Failure "not uppercase")

let is_lowercase_ascii (str:string) =
	let down = String.lowercase_ascii str in

	if down = str then Try.Try.Success str
	else Try.Try.Failure (Failure "not lowercase")

let is_odd (i:int) =
	if i mod 2 = 1 then Try.Try.Success i
	else Try.Try.Failure (Failure "not odd")

let is_even (i:int) =
	if i mod 2 = 0 then Try.Try.Success i
	else Try.Try.Failure (Failure "not even")

let is_multiple (base:int) (i:int) =
	if i mod base = 0 then Try.Try.Success i
	else Try.Try.Failure (Failure ("not multiple of " ^ (string_of_int base)))

let ex_to_string ex = Try.Try.Success (Printexc.to_string ex)

let ( >>= ) = Try.Try.( >>= )

let () =
	let x1 = Try.Try.return "OUI" in
	let x2 = Try.Try.return "non" in
	let i1 = Try.Try.return 2 in
	let i2 = Try.Try.return 3 in
	let i3 = Try.Try.return 5 in
	let ex1 = Try.Try.Failure (Failure "Ex1") in
	let ex2 = Try.Try.Failure Division_by_zero in
	let pprint_int i = print_string "--- "; print_int i; print_endline " ---" in

	print_try print_string (x1 >>= is_uppercase_ascii);
	print_try print_string (x2 >>= is_uppercase_ascii);
	print_try print_string (x1 >>= is_lowercase_ascii);
	print_try print_string (x2 >>= is_lowercase_ascii);

	print_newline ();

	pprint_int 2;
	print_try print_int (i1 >>= is_even);
	print_try print_int (i1 >>= is_odd);

	pprint_int 3;
	print_try print_int (i2 >>= is_even);
	print_try print_int (i2 >>= is_odd);

	pprint_int 5;
	print_try print_int (i3 >>= is_even);
	print_try print_int (i3 >>= is_odd);
	print_try print_int (i3 >>= is_odd >>= (is_multiple 3));
	print_try print_int (i3 >>= is_odd >>= (is_multiple 5));
	print_try print_int (i3 >>= is_odd >>= (is_multiple 3) >>= (is_multiple 1));

	print_newline ();

	print_try print_string (Try.Try.recover ex1 ex_to_string);
	print_try print_string (Try.Try.recover ex2 ex_to_string);
	print_try print_string (Try.Try.recover x1 ex_to_string);
	print_try print_string (Try.Try.recover x2 ex_to_string);

	print_newline ();

	print_try print_int (Try.Try.filter i1 (fun x -> x mod 2 = 0));
	print_try print_int (Try.Try.filter i2 (fun x -> x mod 2 = 0));
	print_try print_int (Try.Try.filter i1 (fun x -> x mod 2 = 1));
	print_try print_int (Try.Try.filter i2 (fun x -> x mod 2 = 1));

	print_newline ();

	print_try print_string (Try.Try.flatten (Try.Try.return x1));
	print_try print_string (Try.Try.flatten (Try.Try.return ex1));
	print_try print_string (Try.Try.flatten ex1);
