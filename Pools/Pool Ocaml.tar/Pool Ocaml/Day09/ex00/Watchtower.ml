(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   Watchtower.ml                                      :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/24 14:05:13 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/24 14:12:07 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

module Watchtower = struct
	type hour = int

	let zero = (0:hour)
	let add (a:hour) (b:hour) = (((a + b) mod 12):hour)
	let sub (a:hour) (b:hour) = (((a - b + 12) mod 12):hour)
end
