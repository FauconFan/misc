(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   main.ml                                            :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/24 14:04:50 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/24 14:13:44 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

let () =
	let x = (6:Watchtower.Watchtower.hour) in
	let y = (7:Watchtower.Watchtower.hour) in
	let add = Watchtower.Watchtower.add in
	let sub = Watchtower.Watchtower.sub in

	print_endline ("add 6 7 := " ^ (string_of_int (add x y)));
	print_endline ("sub 6 7 := " ^ (string_of_int (sub x y)))
