(* ************************************************************************** *)
(*                                                                            *)
(*                                                        :::      ::::::::   *)
(*   Functoids.ml                                       :+:      :+:    :+:   *)
(*                                                    +:+ +:+         +:+     *)
(*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        *)
(*                                                +#+#+#+#+#+   +#+           *)
(*   Created: 2018/07/24 14:42:19 by jpriou            #+#    #+#             *)
(*   Updated: 2018/07/24 15:15:23 by jpriou           ###   ########.fr       *)
(*                                                                            *)
(* ************************************************************************** *)

module type MONOID =
sig
	type element
	val zero1 : element
	val zero2 : element
	val add : element -> element -> element
	val sub : element -> element -> element
	val mul : element -> element -> element
	val div : element -> element -> element
end

module INT =
	struct
		type element = int

		let zero1 = 0
		let zero2 = 1
		let add = ( + )
		let sub = ( - )
		let mul = ( * )
		let div = ( / )
	end

module FLOAT =
struct
	type element = float

	let zero1 = 0.
	let zero2 = 1.
	let add = ( +. )
	let sub = ( -. )
	let mul = ( *. )
	let div = ( /. )
end

module Calc =
	functor (M : MONOID) ->
		struct
			let add = M.add
			let sub = M.sub
			let mul = M.mul
			let div = M.div

			let rec power (m : M.element) i =
				if i < 0 then M.div M.zero2 (power m (-i))
				else if i == 0 then M.zero2
				else if i == 1 then m
				else let next = M.mul m m in
						if i mod 2 == 0 then next
						else M.mul next m

			let rec fact (m : M.element) =
				if m <= M.zero2 then M.zero2
				else M.mul m (fact (M.sub m M.zero2))
		end

module Calc_int = Calc(INT)
module Calc_float = Calc(FLOAT)

let () =
	print_endline (string_of_int (Calc_int.power 3 3));
	print_endline (string_of_float (Calc_float.power 3.0 3));
	print_endline (string_of_int (Calc_int.mul (Calc_int.add 20 1) 2));
	print_endline (string_of_float (Calc_float.mul (Calc_float.add 20.0 1.0) 2.0))
