/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   PowerFist.hpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/01 12:30:11 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/08 08:12:49 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef POWER_FIST_HPP
#define POWER_FIST_HPP

#include "AWeapon.hpp"

class PowerFist : public AWeapon {
    public:
        PowerFist ();
        virtual ~PowerFist ();

        void attack() const;

    private:
        PowerFist (PowerFist const &);
        PowerFist &operator=(PowerFist const &);
};

#endif // ifndef POWER_FIST_HPP
