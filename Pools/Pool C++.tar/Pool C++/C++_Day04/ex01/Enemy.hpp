/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Enemy.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/02 11:00:40 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/08 08:11:18 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ENEMY_HPP
#define ENEMY_HPP

#include <string>

class Enemy {
    public:
        Enemy (int, std::string const &);
        Enemy (Enemy const &);
        virtual ~Enemy ();

        Enemy &operator=(Enemy const &);

        std::string const getType() const;
        int getHP() const;

        virtual void takeDamage(int);
    private:
        int _hp;
        std::string _type;

        void setHP(int);
        Enemy();
};

#endif // ifndef ENEMY_HPP
