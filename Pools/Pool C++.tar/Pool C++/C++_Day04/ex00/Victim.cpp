/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Victim.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/30 19:58:05 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/30 20:06:19 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <string>
#include "Victim.hpp"

Victim::Victim(std::string name) : _name(name) {
    std::cout << "Some random victim called "
              << name << " just popped !" << '\n';
}

Victim::Victim(Victim const & copy) {
    *this = copy;
    std::cout << "Some random victim called "
              << this->_name << " just cloned..." << '\n';
}

Victim::~Victim() {
    std::cout << "Victim " << this->_name
              << " just died for no apparent reason !" << '\n';
}

Victim &Victim::operator=(Victim const & copy) {
    this->_name = copy._name;
    return *this;
}

std::string Victim::getName() const {
    return this->_name;
}

void Victim::getPolymorphed() const {
    std::cout << this->_name
              << " has been turned into a cute little sheep !" << std::endl;
}

std::ostream &operator<<(std::ostream &os, Victim const &v) {
    return os << "I'm " << v.getName() << " and I like otters !" << std::endl;
}
