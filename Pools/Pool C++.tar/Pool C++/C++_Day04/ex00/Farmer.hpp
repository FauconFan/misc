/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Farmer.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/30 20:11:00 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/08 08:09:47 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FARMER_HPP
#define FARMER_HPP

#include <string>
#include "Victim.hpp"

class Farmer : public Victim {
    public:
        Farmer (std::string name);
        Farmer (Farmer const &);
        virtual ~Farmer ();

        Farmer &operator=(Farmer const &);
        void getPolymorphed() const;
    private:
        Farmer();
};

#endif // ifndef FARMER_HPP
