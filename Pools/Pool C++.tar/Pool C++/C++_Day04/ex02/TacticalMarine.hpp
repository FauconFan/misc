/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   TacticalMarine.hpp                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/02 13:52:05 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/02 15:58:28 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef TACTICALMARINE_HPP
#define TACTICALMARINE_HPP

#include "ISpaceMarine.hpp"

class TacticalMarine : public ISpaceMarine {
    public:
        TacticalMarine ();
        TacticalMarine (TacticalMarine const &);
        virtual ~TacticalMarine ();

        TacticalMarine &operator=(TacticalMarine const &);

        ISpaceMarine * clone() const;
        void battleCry() const;
        void rangedAttack() const;
        void meleeAttack() const;
};

#endif // ifndef TACTICALMARINE_HPP
