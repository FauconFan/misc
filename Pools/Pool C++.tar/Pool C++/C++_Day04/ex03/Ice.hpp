/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Ice.hpp                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/03 17:04:13 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/08 08:15:18 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ICE_HPP
#define ICE_HPP

#include "AMateria.hpp"
#include "ICharacter.hpp"

class Ice : public AMateria {
    public:
        Ice ();
        virtual ~Ice ();

        AMateria * clone() const;
        void use(ICharacter &target);

    private:
        Ice(Ice const &);

        Ice &operator=(const Ice &);
};

#endif // ifndef ICE_HPP
