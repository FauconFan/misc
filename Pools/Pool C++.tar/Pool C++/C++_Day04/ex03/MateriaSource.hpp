/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   MateriaSource.hpp                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/03 17:40:22 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/07 12:06:04 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MATERIALSOURCE_HPP
#define MATERIALSOURCE_HPP

#include "IMateriaSource.hpp"

#define MATE_SOURCE_MAX 4

class MateriaSource : public IMateriaSource {
    public:
        MateriaSource ();
        MateriaSource (MateriaSource const &);
        virtual ~MateriaSource ();

        MateriaSource &operator=(MateriaSource const &);

        void learnMateria(AMateria *);
        AMateria * createMateria(std::string const & type);

    private:
        AMateria ** _templates;
        unsigned int _size;

        void    free_materials();
};

#endif // ifndef MATERIALSOURCE_HPP
