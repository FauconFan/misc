/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Cure.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/03 17:09:24 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/08 08:15:07 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#ifndef CURE_HPP
#define CURE_HPP

#include "AMateria.hpp"
#include "ICharacter.hpp"

class Cure : public AMateria {
    public:
        Cure ();
        virtual ~Cure ();

        AMateria * clone() const;
        void use(ICharacter &target);

    private:
        Cure(Cure const &);

        Cure &operator=(const Cure &);
};

#endif // ifndef CURE_HPP
