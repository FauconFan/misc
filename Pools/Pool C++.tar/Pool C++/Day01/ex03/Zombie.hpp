/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Zombie.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/24 18:07:33 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/24 19:20:51 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ZOMBIE_HPP
#define ZOMBIE_HPP

#include <iostream>
#include <string>

class Zombie {
private:
    std::string _name;
    std::string _type;

public:
    Zombie ();
    Zombie (std::string name, std::string type);
    virtual ~Zombie ();

    std::string getName() const;
    std::string getType() const;
    void setName(std::string name);
    void setType(std::string type);

    void announce () const;
};

#endif
