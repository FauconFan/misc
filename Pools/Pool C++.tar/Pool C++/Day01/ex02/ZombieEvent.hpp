/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ZombieEvent.hpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/24 18:19:31 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/24 18:25:25 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ZOMBIE_EVENT_HPP
#define ZOMBIE_EVENT_HPP

#include <string>
#include "Zombie.hpp"

class ZombieEvent {
private:
    std::string _type;

public:
    ZombieEvent ();
    virtual ~ZombieEvent ();

    void setZombieType(std::string type);
    Zombie *newZombie(std::string name) const;
};

#endif
