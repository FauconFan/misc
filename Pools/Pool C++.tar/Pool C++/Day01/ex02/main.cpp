/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/24 18:26:17 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/24 19:23:08 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <cstdlib>
#include <ctime>
#include "Zombie.hpp"
#include "ZombieEvent.hpp"

void randomChump() {
    const std::string data[10] = {
        "David", "Charlotte", "Zidane",
        "Frank", "Jean", "Ernest",
        "Raphaëlle", "Cindy", "Constance",
        "Marion"
    };

    Zombie zom = Zombie(data[rand() % 10], "randomed");
    zom.announce();
}

int main(void) {
    srand(time(NULL));
    ZombieEvent ze;
    Zombie bobbie = Zombie("bobbie", "crawler");

    bobbie.announce();
    ze.setZombieType("climber");
    Zombie *a = ze.newZombie("Karl");
    a->announce();
    delete a;

    randomChump();
    randomChump();
    randomChump();

    return 0;
}
