/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/24 17:25:06 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/24 17:55:29 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Pony.hpp"

int main(void) {
    Pony p0 = Pony::ponyOnTheHeap();
    Pony p1 = Pony::ponyOnTheHeap();
    Pony *p2 = Pony::ponyOnTheStack();
    Pony *p3 = Pony::ponyOnTheStack();

    delete p2;

    Pony p5 = Pony::ponyOnTheHeap();
    Pony p6 = Pony::ponyOnTheHeap();
    Pony *p7 = Pony::ponyOnTheStack();
    Pony *p8 = Pony::ponyOnTheStack();

    delete p7;
    delete p3;

    Pony p9 = Pony::ponyOnTheHeap();
    Pony p10 = Pony::ponyOnTheHeap();

    delete p8;
    return 0;
}
