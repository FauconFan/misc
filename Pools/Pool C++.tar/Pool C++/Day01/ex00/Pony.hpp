/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Pony.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/24 17:26:14 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/24 17:56:22 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PONY_HPP
#define PONY_HPP

#include <string>

class Pony {
    private:
        std::string _name;

        static int idActu;

    public:
        Pony ();
        virtual ~Pony ();
        static Pony ponyOnTheHeap();
        static Pony * ponyOnTheStack();
};

#endif // ifndef PONY_HPP
