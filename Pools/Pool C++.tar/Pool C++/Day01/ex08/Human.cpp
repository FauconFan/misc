/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Human.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/25 09:32:51 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/25 10:13:55 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string>
#include <iostream>
#include "Human.hpp"

Human::Human()
    : _map(std::map<std::string, HumanAttackFnc> {
        {"ma", &Human::meleeAttack},
        {"ra", &Human::rangedAttack},
        {"is", &Human::intimidatingShoot},
        {"meleeAttack", &Human::meleeAttack},
        {"rangedAttack", &Human::rangedAttack},
        {"intimidatingShoot", &Human::intimidatingShoot}
    }) {}
Human::~Human() {}

void Human::meleeAttack(std::string const &target) {
    std::cout << "Melee Attack on " << target << " !!\n";
}

void Human::rangedAttack(std::string const &target) {
    std::cout << "Ranged Attack on " << target << " !!\n";
}

void Human::intimidatingShoot(std::string const &target) {
    std::cout << "Ouaaaaaaaah, shooting on you; heeeeeum, BOOM ("
        << target << ")" << '\n';
}

void Human::action(std::string const & action_name, std::string const &target) {
    HumanAttackFnc ptrMember;

    ptrMember = this->_map[action_name];
    if (ptrMember == NULL)
        return ;
    (this->*ptrMember)(target);
}
