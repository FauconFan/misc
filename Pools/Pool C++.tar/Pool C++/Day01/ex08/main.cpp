/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/25 09:42:28 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/25 10:13:46 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Human.hpp"

int main() {
    Human hu;

    hu.action("ma", "Jim");
    hu.action("ra", "Bob");
    hu.action("is", "Alice");
    hu.action("meleeAttack", "Charlie");
    hu.action("rangedAttack", "Zaz");
    hu.action("intimidatingShoot", "Thor");

    // Handle not existing attack
    hu.action("bazooka", "nobody");
    hu.action("kamehameha", "nobody");
    return 0;
}
