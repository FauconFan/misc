/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Logger.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/25 23:25:48 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/26 00:14:07 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string>
#include <map>
#include <iostream>
#include <fstream>
#include <ctime>
#include "Logger.hpp"

Logger::Logger()
    : _map(std::map<std::string, LoggerFnc> {
    {"console", &Logger::logToConsole},
    {"file", &Logger::logToFile}
}), _output_file(std::ofstream("output.log", std::ios::app)) {
    if (this->_output_file.bad() || this->_output_file.is_open() == false) {
        std::cout << "file not opened correctly" << '\n';
        exit(1);
    }
}

Logger::~Logger() {
    this->_output_file.close();
}

void Logger::logToConsole(std::string const & message) {
    std::cout << message << '\n';
}

void Logger::logToFile(std::string const & message) {
    this->_output_file << message << '\n';
}

std::string Logger::makeLogEntry(std::string const & message) {
    time_t cnow     = time(NULL);
    std::tm * now   = NULL;
    std::string res = "";

    now = localtime(&cnow);
    res = "[" + std::to_string(1900 + now->tm_year) + "_";
    if (now->tm_mon < 10)
        res += "0";
    res += std::to_string(now->tm_mon) + "_";
    if (now->tm_mday < 10)
        res += "0";
    res += std::to_string(now->tm_mday) + ":";
    if (now->tm_hour < 10)
        res += "0";
    res += std::to_string(now->tm_hour) + "h";
    if (now->tm_min < 10)
        res += "0";
    res += std::to_string(now->tm_min) + "m";
    if (now->tm_sec < 10)
        res += "0";
    res += std::to_string(now->tm_sec) + "s] ";
    return res + message;
}

void Logger::log(std::string const & dest, std::string const & message) {
    LoggerFnc logPtr;

    logPtr = this->_map[dest];
    if (logPtr == NULL)
        return;

    (this->*logPtr)(this->makeLogEntry(message));
}
