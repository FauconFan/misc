/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Human.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/24 20:15:06 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/24 20:32:08 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string>
#include "Human.hpp"
#include "Brain.hpp"

Human::Human() {}

Human::~Human() {}

std::string Human::identify() const {
    return this->brain.identify();
}

Brain &Human::getBrain() {
    return this->brain;
}
