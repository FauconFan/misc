/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   HumanB.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/24 22:39:45 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/24 22:52:38 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "HumanB.hpp"

HumanB::HumanB(std::string name)
    : _name(name), _weapon(NULL) {}

HumanB::~HumanB() {}

void HumanB::setWeapon(Weapon &club) {
    this->_weapon = &club;
}

void HumanB::attack() const {
    std::cout
        << this->_name
        << " attacks with his "
        << this->_weapon->getType()
        << ".\n";
}
