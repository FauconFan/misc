/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Weapon.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/24 22:33:01 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/24 22:35:12 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef WEAPON_HPP
#define WEAPON_HPP

#include <string>

class Weapon {
    private:
        std::string _type;

    public:
        Weapon (std::string type);
        virtual ~Weapon ();

        std::string getType() const;
        void setType(std::string type);
};

#endif // ifndef WEAPON_HPP
