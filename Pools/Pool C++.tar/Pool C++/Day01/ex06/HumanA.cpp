/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   HumanA.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/24 22:39:45 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/24 22:46:37 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "HumanA.hpp"

HumanA::HumanA(std::string name, Weapon &weapon)
        : _name(name), _weapon(weapon) {}

HumanA::~HumanA() {}

void HumanA::attack() const {
    std::cout
        << this->_name
        << " attacks with his "
        << this->_weapon.getType()
        << ".\n";
}
