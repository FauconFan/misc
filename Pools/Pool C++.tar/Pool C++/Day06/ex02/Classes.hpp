/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Classes.hpp                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/11 20:39:11 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/11 20:40:16 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CLASSES_HPP
#define CLASSES_HPP

class Base {
    public:
        virtual ~Base ();
};

class A : public Base {};
class B : public Base {};
class C : public Base {};

#endif // ifndef CLASSES_HPP
