/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/11 20:41:49 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/11 20:52:00 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <time.h>
#include <stdlib.h>
#include "Classes.hpp"

Base *generate(void) {
    int cand = rand() % 3;

    std::cout << "Generate " << static_cast<char>(cand + 'A') << " class \n";
    if (cand == 0)
        return static_cast<Base *>(new A());
    else if (cand == 1)
        return static_cast<Base *>(new B());
    else if (cand == 2)
        return static_cast<Base *>(new C());
    exit(1);
}

void identify_from_pointer(Base *p) {
    std::cout << "Identified from pointer : ";
    if (dynamic_cast<A *>(p))
		std::cout << "A" << "\n";
	else if (dynamic_cast<B *>(p))
		std::cout << "B" << "\n";
	else if (dynamic_cast<C *>(p))
        std::cout << "C" << "\n";
}

void identify_from_reference(Base &p) {
    std::cout << "Identified from reference : ";

    try {
        (void)dynamic_cast<A &>(p);
        std::cout << "A";
    } catch (std::bad_cast &e) {}
    try {
        (void)dynamic_cast<B &>(p);
        std::cout << "B";
    } catch (std::bad_cast &e) {}
    try {
        (void)dynamic_cast<C &>(p);
        std::cout << "C";
    } catch (std::bad_cast &e) {}

    std::cout << '\n';
}

int main(void) {
    srand(time(NULL));

    for (size_t i = 0; i < 4; i++) {
        Base *b = generate();

        identify_from_pointer(b);
        identify_from_reference(*b);
        delete b;
    }
    return 0;
}
