/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Data.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/11 20:21:46 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/11 20:34:02 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <string>
#include <stdlib.h>
#include "Data.hpp"

static char generate_random_char() {
    int n = rand() % 62;

    if (n < 10)
        return n + '0';
    n -= 10;
    if (n < 26)
        return n + 'a';
    n -= 26;
    return n + 'A';
}

void *serialize(void) {
    char *ret = new char[20];

    for (size_t i = 0; i < 8; i++) {
        ret[i] = generate_random_char();
    }
    *(reinterpret_cast<int *>(ret + 8)) = rand();
    for (size_t i = 12; i < 20; i++) {
        ret[i] = generate_random_char();
    }
    return (reinterpret_cast<void *>(ret));
}

Data *deserialize(void *raw) {
    Data *ret = new Data();

    ret->s1.assign(reinterpret_cast<char *>(raw), 8);
	ret->n = *reinterpret_cast<int *>(reinterpret_cast<char *>(raw) + 8);
    ret->s2.assign(reinterpret_cast<char *>(raw) + 12, 8);

    return (ret);
}

void pretty_print(Data *raw) {
    std::cout	<< "raw : "
                << raw->s1
                << raw->n
                << raw->s2
                << "\n\n"
                << "s1 : " << raw->s1 << '\n'
                << "n  : " << raw->n << '\n'
                << "s2 : " << raw->s2 << '\n' << '\n';
}
