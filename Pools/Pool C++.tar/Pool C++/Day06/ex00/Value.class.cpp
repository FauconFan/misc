/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Value.class.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/11 19:23:12 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/11 20:14:41 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <iomanip>
#include "NoConversionException.class.hpp"
#include "Value.class.hpp"
#include "errno.h"

Value::Value (char * entry) {
    this->_entry = entry;
}

Value::Value (Value const & copy) {
    *this = copy;
}

Value::~Value () {}

Value &Value::operator=(Value const & copy) {
    this->_entry = copy._entry;
    return *this;
}

Value::operator char(void) const {
    char c = static_cast<char>(std::atoi(this->_entry));

    if (errno)
        throw NoConversionException();
    return c;
}

Value::operator int(void) const {
    int n = std::atoi(this->_entry);

    if (errno)
        throw NoConversionException();
    return n;
}

Value::operator float(void) const {
    float f = std::atof(this->_entry);

    if (errno)
        throw NoConversionException();
    return f;
}

Value::operator double(void) const {
    double d = std::strtod(this->_entry, NULL);

    if (errno)
        throw NoConversionException();
    return d;
}

void Value::displayCharRep() const {
    std::cout << "char : ";

    try {
        char c = static_cast<char>(*this);
        if (c >= 32 && c < 127) {
            std::cout << "\'" << c << "\'";
        }
        else {
            std::cout << "Non displayable";
        }
    } catch (std::exception &e) {
        std::cout << e.what();
    }
    std::cout << '\n';
}

void Value::displayIntRep() const {
    std::cout << "int: ";

    try {
        std::cout << static_cast<int>(*this);
    } catch (std::exception &e) {
        std::cout << e.what();
    }
    std::cout << '\n';
}

void Value::displayFloatRep() const {
    std::cout << "float: ";

    try {
        std::cout << std::setprecision(20) << static_cast<float>(*this) << 'f';
    } catch (std::exception &e) {
        std::cout << e.what();
    }
    std::cout << '\n';
}

void Value::displayDoubleRep() const {
    std::cout << "double: ";

    try {
        std::cout << std::setprecision(20) << static_cast<double>(*this);
    } catch (std::exception &e) {
        std::cout << e.what();
    }
    std::cout << '\n';
}
