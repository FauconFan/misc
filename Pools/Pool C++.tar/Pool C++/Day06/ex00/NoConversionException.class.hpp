/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   NoConversionException.class.hpp                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/11 19:18:34 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/11 19:21:49 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef NO_CONVERSION_CLASS_HPP
#define NO_CONVERSION_CLASS_HPP

#include <stdexcept>

#define NO_CONV_EXC "No Conversion"

class NoConversionException : public std::exception {
    public:
        NoConversionException ();
        NoConversionException (NoConversionException const &);
        virtual ~NoConversionException ();

        NoConversionException &operator=(NoConversionException const &);

        const char * what() const throw();
};

#endif // ifndef NO_CONVERSION_CLASS_HPP
