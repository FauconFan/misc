/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/11 19:39:21 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/11 20:05:03 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "Value.class.hpp"

int main(int argc, char **argv) {
    if (argc < 2)
        return 0;
    for (int i = 1; i < argc; i++) {
        Value v(argv[i]);

        v.displayCharRep();
        v.displayIntRep();
        v.displayFloatRep();
        v.displayDoubleRep();

        if (i != argc - 1)
            std::cout << '\n';
    }
}
