/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/24 22:55:18 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/24 23:39:54 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <fstream>
#include <iostream>
#include <string>

int do_main(std::string path_file,
  std::string           str_search,
  std::string           str_replace) {
    std::string output_filename = path_file + ".replace";
    std::ifstream input         = std::ifstream(path_file);
    std::ofstream output        = std::ofstream(output_filename);
    std::string all_content     = "";
    std::string buffer_line     = "";
    size_t index_found = 0;

    if (input.fail()) {
        std::cout << "Unable to open : " << path_file << '\n';
        return 1;
    }
    else if (output.fail()) {
        std::cout << "Unable to open : " << output_filename << '\n';
        return 1;
    }

    while (std::getline(input, buffer_line)) {
        all_content = all_content + buffer_line + '\n';
    }

    while ((index_found = all_content.find(str_search, index_found)) != std::string::npos) {
        all_content.replace(index_found, str_search.length(), str_replace);
        index_found += str_replace.length();
    }
    output << all_content;
    input.close();
    output.close();
    return 0;
}

void usage() {
    std::cout << "Usage:" << '\n'
              << "replace PATH_FILE STR_SEARCH STR_REPLACE" << "\n";
}

int main(int argc, char const * argv[]) {
    int ret = 0;
    bool displayUsage = true;
    std::string path_file;
    std::string str_search;
    std::string str_replace;

    if (argc == 4) {
        path_file   = std::string(argv[1]);
        str_search  = std::string(argv[2]);
        str_replace = std::string(argv[3]);

        displayUsage = false;
        ret = do_main(path_file, str_search, str_replace);
    }

    if (displayUsage)
        usage();

    return ret;
}
