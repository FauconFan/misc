/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/26 00:07:02 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/29 22:03:32 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <fstream>
#include <string>

void read_std_input() {
    std::string line;

    while (getline(std::cin, line)) {
        std::cout << line << '\n';
    }
}

void read_file(std::string file_path) {
    std::ifstream file_input(file_path, std::ios::in);

    if (file_input.is_open()) {
        std::string line;
        while (std::getline(file_input, line)) {
            std::cout << line << '\n';
        }
        file_input.close();
    }
    else {
        std::cerr << "cato9tails: "
                  << file_path << ": No such file or directory\n";
    }
}

int main(int argc, char const * argv[]) {
    if (argc == 1)
        read_std_input();
    for (int i = 1; i < argc; i++) {
        read_file(std::string(argv[i]));
    }
    return 0;
}
