/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Brain.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/24 20:09:43 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/24 20:28:53 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <string>
#include "Brain.hpp"

Brain::Brain() {}

Brain::~Brain() {}

std::string Brain::identify() const {
    unsigned long long addr;
    std::string res;
    char actu;
    int rem;

    addr = (unsigned long long) this;
    res  = "";
    for (size_t i = 0; i < 8; i++) {
        rem = addr % 16;
        if (rem < 10) {
            actu = '0' + rem;
        }
        else {
            actu = 'A' + rem - 10;
        }
        res   = actu + res;
        addr /= 16;
    }
    res = "0x" + res;
    return res;
}
