/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Logger.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/25 23:17:51 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/25 23:56:21 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LOGGER_HPP
#define LOGGER_HPP

#include <string>
#include <map>
#include <fstream>

class Logger {
    private:
        void logToConsole(std::string const & message);
        void logToFile(std::string const & message);

        std::string makeLogEntry(std::string const & message);

        std::map<std::string, void (Logger::*)(std::string const &)> _map;
        std::ofstream _output_file;
    public:
        Logger ();
        virtual ~Logger ();

        void log(std::string const & dest, std::string const & message);
};

typedef void (Logger::* LoggerFnc)(std::string const &);

#endif // ifndef LOGGER_HPP
