/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ZombieHorde.hpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/24 19:24:26 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/24 19:41:19 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ZOMBIE_HORDE_HPP
#define ZOMBIE_HORDE_HPP

#include <string>
#include "Zombie.hpp"

class ZombieHorde {
    private:
        Zombie * _content;
        std::string _genRandomName() const;

    public:
        ZombieHorde (size_t N);
        virtual ~ZombieHorde ();
};

#endif // ifndef ZOMBIE_HORDE_HPP
