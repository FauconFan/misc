/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ZombieHorde.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/24 19:26:17 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/24 19:41:35 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ZombieHorde.hpp"

std::string ZombieHorde::_genRandomName() const {
    const std::string data[10] = {
        "David",     "Charlotte", "Zidane",
        "Frank",     "Jean",      "Ernest",
        "Raphaëlle", "Cindy",     "Constance",
        "Marion"
    };

    return data[rand() % 10];
}

ZombieHorde::ZombieHorde(size_t N)
    : _content(new Zombie[N]) {
    for (size_t i = 0; i < N; i++) {
        this->_content[i].setName(this->_genRandomName());
        this->_content[i].setType("horde");
        this->_content[i].announce();
    }
}

ZombieHorde::~ZombieHorde() {
    delete [] this->_content;
}
