/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Human.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/25 09:30:17 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/25 10:09:35 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HUMAN_HPP
#define HUMAN_HPP

#include <map>
#include <string>

class Human {
    private:
        void meleeAttack(std::string const &target);
        void rangedAttack(std::string const &target);
        void intimidatingShoot(std::string const &target);

        std::map<std::string, void (Human::*)(std::string const &)> _map;
    public:
        Human ();
        virtual ~Human ();

        void action(std::string const & action_name, std::string const & target);
};

typedef void (Human::* HumanAttackFnc)(std::string const &);

#endif // ifndef HUMAN_HPP
