/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   HumanB.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/24 22:37:25 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/24 22:52:56 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HUMAN_B_HPP
#define HUMAN_B_HPP

#include <iostream>
#include <string>
#include "Weapon.hpp"

class HumanB {
    private:
        std::string _name;
        Weapon * _weapon;

    public:
        HumanB (std::string name);
        virtual ~HumanB ();

        void setWeapon(Weapon &club);
        void attack() const;
};

#endif // ifndef HUMAN_B_HPP
