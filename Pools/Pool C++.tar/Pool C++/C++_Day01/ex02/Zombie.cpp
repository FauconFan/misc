/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Zombie.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/24 18:08:54 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/24 19:42:08 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string>
#include "Zombie.hpp"

Zombie::Zombie() : _name(""), _type("") {
    std::cout << "Zombie constructor called" << '\n';
}

Zombie::Zombie(std::string name, std::string type)
    : _name(name), _type(type) {
    std::cout << "Zombie constructor called : " << this->_name << '\n';
}

Zombie::~Zombie() {
    std::cout << "Zombie destructor called : " << this->_name << '\n';
}

std::string Zombie::getName() const {
    return this->_name;
}

std::string Zombie::getType() const {
    return this->_type;
}

void Zombie::setName(std::string name) {
    this->_name = name;
}

void Zombie::setType(std::string type) {
    this->_type = type;
}

void Zombie::announce() const {
    std::cout << "<" << this->_name << " (" << this->_type << ")> "
              << "Braiiiiiiinnnnnsss..."
              << '\n';
}
