/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ZombieEvent.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/24 18:21:54 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/24 19:20:33 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <string>
#include "ZombieEvent.hpp"
#include "Zombie.hpp"

ZombieEvent::ZombieEvent() : _type("noType") {
    std::cout << "ZombieEvent Created" << '\n';
}

ZombieEvent::~ZombieEvent() {
    std::cout << "ZombieEvent Deleted" << '\n';
}

void ZombieEvent::setZombieType(std::string type) {
    this->_type = type;
}

Zombie * ZombieEvent::newZombie(std::string name) const {
    return new Zombie(name, this->_type);
}
