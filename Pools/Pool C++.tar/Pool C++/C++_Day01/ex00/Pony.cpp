/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Pony.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/24 17:26:11 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/24 17:56:59 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "Pony.hpp"

Pony::Pony() {
    this->_name = "Pony" + std::to_string(Pony::idActu);
    std::cout << "Pony Born : " << this->_name << '\n';
    Pony::idActu++;
}

Pony::~Pony() {
    std::cout << "The Pony " << this->_name << " died" << '\n';
}

Pony Pony::ponyOnTheHeap() {
    Pony res;

    return res;
}

Pony * Pony::ponyOnTheStack() {
    Pony * res = new Pony();

    return res;
}

int Pony::idActu = 0;
