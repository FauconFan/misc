/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/03 19:02:37 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/04 00:54:44 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "Bureaucrat.hpp"
#include "Form.hpp"

static void testInitBureaucrat() {
    std::cout << "Test Init Bureaucrat" << "\n\n";
    try
    {
        Bureaucrat b("b", -2);
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }
    try
    {
        Bureaucrat b("b", 200);
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }
    std::cout << '\n';
}

static void testHighBureaucrat(Bureaucrat &lewis) {
    std::cout << "Test High Bureaucrat" << "\n\n";
    try
    {
        while (true)
            lewis.inc();
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }

    std::cout << lewis;
    std::cout << '\n';
}

static void testLowBureaucrat(Bureaucrat &bob) {
    std::cout << "Test Low Bureaucrat" << "\n\n";
    try
    {
        while (true)
            bob.dec();
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }

    std::cout << bob;
    std::cout << '\n';
}

static void testInitForm() {
    std::cout << "Test Init Form" << "\n\n";
    try
    {
        Form b("f", -2, -50);
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }
    try
    {
        Form b("f", -2, 50);
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }
    try
    {
        Form b("f", -2, 200);
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }
    try
    {
        Form b("f", 10, -50);
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }
    try
    {
        Form b("f", 10, 50);
        std::cout << "It is normal" << '\n';
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }
    try
    {
        Form b("f", 10, 200);
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }
    try
    {
        Form b("f", 300, -50);
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }
    try
    {
        Form b("f", 300, 50);
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }
    try
    {
        Form b("f", 300, 200);
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }
    std::cout << '\n';
}

static void testSignForm() {
    std::cout << "Test Sign Form" << "\n\n";

    Bureaucrat gus("gus", 53);
    Bureaucrat hubert("hubert", 28);
    Form fo("HJ-42", 70, 90);
    Form oui("HJ-43", 28, 150);
    Form oui2("HJ-44", 27, 150);

    gus.signForm(fo);
    gus.signForm(fo);
    hubert.signForm(oui);
    hubert.signForm(oui2);

    std::cout << '\n';
}

int main() {
    Bureaucrat bob("bob", 42);
    Bureaucrat lewis("lewis", 10);

    if (false) {
        std::cout << bob << lewis << '\n';

        testInitBureaucrat();
        testHighBureaucrat(lewis);
        testLowBureaucrat(bob);
    }

    Form fo("BC34", 4, 2);

    std::cout << fo;

    testInitForm();
    testSignForm();

    return 0;
}
