/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Form.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/03 19:42:14 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/04 00:51:36 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FORM_HPP
#define FORM_HPP

#include <stdexcept>
#include <string>
#include <iostream>
#include "Bureaucrat.hpp"

#define FORM_OOB_EXC "OutOfBounds Exception"
#define FORM_TLOW_SIGN_EXC "The grade is too low to sign"
#define FORM_ALSIGNED_EXC "The form is already signed"

class Bureaucrat;

class Form {
    public:
        class GradeTooHighException : public std::exception {
            public:
                GradeTooHighException ();
                virtual ~GradeTooHighException ();

                const char* what() const throw();
        };

        class GradeTooLowException : public std::exception {
            public:
                GradeTooLowException (const char *);
                GradeTooLowException (GradeTooLowException const &);
                virtual ~GradeTooLowException ();

                GradeTooLowException &operator=(GradeTooLowException const &);

                const char* what() const throw();
            private:
                const char* _msg;
        };

        class AlreadySignedException : public std::exception {
            public:
                AlreadySignedException ();
                virtual ~AlreadySignedException ();

                const char* what() const throw();
        };

        Form (std::string const &name, int minGradeSign, int minGradeExec);
        Form (Form const &);
        virtual ~Form ();

        Form &operator=(Form const &);

        std::string const getName() const;
        bool isSigned() const;
        int getMinGradeSign() const;
        int getMinGradeExec() const;

        void beSigned(Bureaucrat const &);
    private:
        std::string _name;
        bool _isSigned;
        int _minGradeSign;
        int _minGradeExec;
};

std::ostream &operator<<(std::ostream &, Form const &);

#endif
