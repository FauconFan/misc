/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Bureaucrat.cpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/03 18:53:33 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/04 00:55:28 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdexcept>
#include <string>
#include <iostream>
#include "Bureaucrat.hpp"

Bureaucrat::GradeTooHighException::GradeTooHighException() {}
Bureaucrat::GradeTooHighException::~GradeTooHighException() {}

const char *Bureaucrat::GradeTooHighException::what() const throw() {
    return "The grade is becoming too high !";
}

Bureaucrat::GradeTooLowException::GradeTooLowException() {}
Bureaucrat::GradeTooLowException::~GradeTooLowException() {}

const char *Bureaucrat::GradeTooLowException::what() const throw() {
    return "The grade can't be that low...";
}

Bureaucrat::Bureaucrat(std::string const &name, int grade)
        throw(GradeTooHighException, GradeTooLowException)
    : _name(name) {
    if (grade < 1)
        throw GradeTooHighException();
    else if (grade > 150)
        throw GradeTooLowException();
    this->_grade = grade;
}

Bureaucrat::Bureaucrat(Bureaucrat const & copy) throw() {
    *this = copy;
}

Bureaucrat::~Bureaucrat() throw() {}

Bureaucrat &Bureaucrat::operator=(Bureaucrat const & copy) throw() {
    this->_name = copy._name;
    this->_grade = copy._grade;
    return *this;
}

std::string const Bureaucrat::getName() const throw() {
    return this->_name;
}

int Bureaucrat::getGrade() const throw() {
    return this->_grade;
}

void Bureaucrat::inc() throw(GradeTooHighException) {
    if (this->_grade == 1)
        throw GradeTooHighException();
    this->_grade--;
}

void Bureaucrat::dec() throw(GradeTooLowException) {
    if (this->_grade == 150)
        throw GradeTooLowException();
    this->_grade++;
}

void Bureaucrat::signForm(Form &fo) const {
    try
    {
        fo.beSigned(*this);
        std::cout << this->_name << " signs " << fo.getName() << '\n';
    }
    catch (std::exception const &e)
    {
        std::cout << this->_name << " cannot sign " << fo.getName()
            << " because \"" << e.what() << "\"\n";
    }
}

std::ostream &operator<<(std::ostream &os, Bureaucrat const &b) {
    return os << b.getName() << ", Bureaucrat grade " << b.getGrade() << ".\n";
}
