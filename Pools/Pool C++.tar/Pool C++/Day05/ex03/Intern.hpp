/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Intern.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/04 09:33:11 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/04 09:37:24 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef INTERN_HPP
#define INTERN_HPP

#include <string>
#include "Form.hpp"

class Intern {
    public:
        Intern ();
        Intern (Intern const &);
        virtual ~Intern ();

        Intern &operator=(Intern const &);

        Form * makeForm(std::string const &, std::string const &) const;
};

#endif // ifndef INTERN_HPP
