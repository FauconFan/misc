/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Intern.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/04 09:35:11 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/04 10:28:15 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string>
#include "Intern.hpp"
#include "Form.hpp"
#include "PresidentialPardonForm.hpp"
#include "RobotomyRequestForm.hpp"
#include "ShrubberyCreationForm.hpp"

Intern::Intern () {}

Intern::Intern (Intern const & copy) {
    *this = copy;
}

Intern::~Intern () {}

Intern &Intern::operator=(Intern const & copy) {
    (void)copy;
    return *this;
}

Form *Intern::makeForm(
        std::string const & type,
        std::string const & target) const {
    Form *res = NULL;

    if (type == "presidential pardon")
        res = new PresidentialPardonForm(target);
    else if (type == "robotomy request")
        res = new RobotomyRequestForm(target);
    else if (type == "shrubbery creation")
        res = new ShrubberyCreationForm(target);

    if (res != NULL)
        std::cout << "Intern creates " << res->getName() << '\n';
    else
        std::cout << type << " is a unknown type..." << '\n';
    return res;
}
