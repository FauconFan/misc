/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   PresidentialPardonForm.cpp                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/04 08:40:51 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/04 08:52:00 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "PresidentialPardonForm.hpp"

PresidentialPardonForm::PresidentialPardonForm(std::string const &target)
    : Form("PP-" + target, 25, 5), _target(target) {}


PresidentialPardonForm::PresidentialPardonForm
                (PresidentialPardonForm const &copy)
                : Form(copy.getName() + "-copy", 25, 5) {
    *this = copy;
}

PresidentialPardonForm::~PresidentialPardonForm() {}

PresidentialPardonForm &PresidentialPardonForm::operator=(
        PresidentialPardonForm const & copy) {
    this->_target = copy.getTarget();
    return *this;
}

std::string const PresidentialPardonForm::getTarget() const {
    return this->_target;
}

void PresidentialPardonForm::beExecuted() const {
    std::cout << this->_target <<
        " has been pardoned by Zafod Beeblebrox.\n";
}
