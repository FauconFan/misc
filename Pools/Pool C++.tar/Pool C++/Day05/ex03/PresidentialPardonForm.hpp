/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   PresidentialPardonForm.hpp                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/04 08:39:11 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/04 08:50:43 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PRESIDENTIALPARDONFORM_HPP
#define PRESIDENTIALPARDONFORM_HPP

#include <string>
#include "Form.hpp"

class PresidentialPardonForm : public Form {
    public:
        PresidentialPardonForm (std::string const &target);
        PresidentialPardonForm (PresidentialPardonForm const &);
        virtual ~PresidentialPardonForm ();

        PresidentialPardonForm &operator=(PresidentialPardonForm const &);

        std::string const getTarget() const;

        void beExecuted() const;
    private:
        std::string _target;
};

#endif // ifndef PRESIDENTIALPARDONFORM_HPP
