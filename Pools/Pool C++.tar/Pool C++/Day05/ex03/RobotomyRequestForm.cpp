/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   RobotomyRequestForm.cpp                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/04 09:10:37 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/04 10:34:42 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "RobotomyRequestForm.hpp"
#include <iostream>
#include <cstdlib>
#include <ctime>

bool RobotomyRequestForm::isRandomSet = false;

RobotomyRequestForm::RobotomyRequestForm(std::string const &target)
    : Form("RR-" + target, 72, 45), _target(target) {
    if (RobotomyRequestForm::isRandomSet == false)
    {
        RobotomyRequestForm::isRandomSet = true;
        srand(time(NULL));
    }
}


RobotomyRequestForm::RobotomyRequestForm
                (RobotomyRequestForm const &copy)
                : Form(copy.getName() + "-copy", 72, 45) {
    *this = copy;
}

RobotomyRequestForm::~RobotomyRequestForm() {}

RobotomyRequestForm &RobotomyRequestForm::operator=(
        RobotomyRequestForm const & copy) {
    this->_target = copy.getTarget();
    return *this;
}

std::string const RobotomyRequestForm::getTarget() const {
    return this->_target;
}

void RobotomyRequestForm::beExecuted() const {
    if (rand() % 2 == 0)
    {
        std::cout << this->_target
            << " has been robotized successfully !" << '\n';
    }
    else
    {
        std::cout << "Hmmm, sorry chief, subject transformation has failed..."
            << '\n';
    }
}
