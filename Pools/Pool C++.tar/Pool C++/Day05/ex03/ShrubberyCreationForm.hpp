/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ShrubberyCreationForm.hpp                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/04 09:18:55 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/04 09:19:24 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SHRUBBERYCREATIONFORM_HPP
#define SHRUBBERYCREATIONFORM_HPP

#include <string>
#include "Form.hpp"

class ShrubberyCreationForm : public Form {
    public:
        ShrubberyCreationForm (std::string const &target);
        ShrubberyCreationForm (ShrubberyCreationForm const &);
        virtual ~ShrubberyCreationForm ();

        ShrubberyCreationForm &operator=(ShrubberyCreationForm const &);

        std::string const getTarget() const;

        void beExecuted() const;
    private:
        std::string _target;
};

#endif // ifndef SHRUBBERYCREATIONFORM_HPP
