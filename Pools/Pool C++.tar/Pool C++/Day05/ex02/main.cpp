/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/03 19:02:37 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/04 09:22:22 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "Bureaucrat.hpp"
#include "Form.hpp"
#include "PresidentialPardonForm.hpp"
#include "RobotomyRequestForm.hpp"
#include "ShrubberyCreationForm.hpp"

static void testInitBureaucrat() {
    std::cout << "Test Init Bureaucrat" << "\n\n";

    try
    {
        Bureaucrat b("b", -2);
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }
    try
    {
        Bureaucrat b("b", 200);
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }
    std::cout << '\n';
}

static void testHighBureaucrat(Bureaucrat &lewis) {
    std::cout << "Test High Bureaucrat" << "\n\n";

    try
    {
        while (true)
            lewis.inc();
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }

    std::cout << lewis;
    std::cout << '\n';
}

static void testLowBureaucrat(Bureaucrat &bob) {
    std::cout << "Test Low Bureaucrat" << "\n\n";

    try
    {
        while (true)
            bob.dec();
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }

    std::cout << bob;
    std::cout << '\n';
}

// Remove testInitForm becuase Form Object is abstract now
// Remove testSignForm  because Form Onject is abstract now

static void testConcreteForms() {
    std::cout << "Test Concrete Forms" << "\n\n";
    Bureaucrat boss("boss", 1);
    Form * pp  = new PresidentialPardonForm("Berlin");
    Form * pp2 = new PresidentialPardonForm("Rio");
    Form * rr  = new RobotomyRequestForm("Bob-Lennon");
    Form * sc  = new ShrubberyCreationForm("tree");

    boss.signForm(*pp);
    boss.executeForm(*pp);

    std::cout << '\n';

    boss.executeForm(*pp2);
    boss.signForm(*pp2);
    boss.signForm(*pp2);
    boss.executeForm(*pp2);

    std::cout << '\n';

    boss.signForm(*rr);

    for (size_t i = 0; i < 10; i++) {
        boss.executeForm(*rr);
    }

    boss.signForm(*sc);
    boss.executeForm(*sc);

    delete pp;
    delete pp2;
    delete rr;
    delete sc;
    std::cout << '\n';
} // testConcreteForms

int main() {
    Bureaucrat bob("bob", 42);
    Bureaucrat lewis("lewis", 10);

    if (false) {
        std::cout << bob << lewis << '\n';

        testInitBureaucrat();
        testHighBureaucrat(lewis);
        testLowBureaucrat(bob);
    }

    testConcreteForms();

    return 0;
}
