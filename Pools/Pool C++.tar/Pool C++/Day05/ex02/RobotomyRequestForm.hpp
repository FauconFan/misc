/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   RobotomyRequestForm.hpp                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/04 09:09:44 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/04 10:33:31 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ROBOTOMYREQUESTFORM_HPP
#define ROBOTOMYREQUESTFORM_HPP

#include <string>
#include "Form.hpp"

class RobotomyRequestForm : public Form {
    public:
        RobotomyRequestForm (std::string const &target);
        RobotomyRequestForm (RobotomyRequestForm const &);
        virtual ~RobotomyRequestForm ();

        RobotomyRequestForm &operator=(RobotomyRequestForm const &);

        std::string const getTarget() const;

        void beExecuted() const;
    private:
        std::string _target;

        static bool isRandomSet;
};

#endif // ifndef ROBOTOMYREQUESTFORM_HPP
