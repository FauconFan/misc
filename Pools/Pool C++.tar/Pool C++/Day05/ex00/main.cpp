/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/03 19:02:37 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/03 19:20:04 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "Bureaucrat.hpp"

static void testHigh(Bureaucrat &lewis) {
    std::cout << "Test High" << "\n\n";

    try
    {
        while (true)
            lewis.inc();
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }

    std::cout << lewis;
    std::cout << '\n';
}

static void testLow(Bureaucrat &bob) {
    std::cout << "Test Low" << "\n\n";

    try
    {
        while (true)
            bob.dec();
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }

    std::cout << bob;
    std::cout << '\n';
}

static void testInit() {
    std::cout << "Test Init" << "\n\n";

    try
    {
        Bureaucrat b("b", -2);
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }
    try
    {
        Bureaucrat b("b", 200);
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }
    std::cout << '\n';
}

int main() {
    Bureaucrat bob("bob", 42);
    Bureaucrat lewis("lewis", 10);

    std::cout << bob << lewis << '\n';

    testHigh(lewis);
    testLow(bob);
    testInit();

    return 0;
}
