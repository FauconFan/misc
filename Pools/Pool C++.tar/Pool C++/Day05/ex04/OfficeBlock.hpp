/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   OfficeBlock.hpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/04 09:55:19 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/04 10:15:32 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef OFFICEBLOCK_HPP
#define OFFICEBLOCK_HPP

#include <string>
#include <stdexcept>
#include "Intern.hpp"
#include "Bureaucrat.hpp"

class OfficeBlock {
    public:
        class SomeAbsents : public std::exception {
            public:
                SomeAbsents (bool isInternPresent,
                    bool          isSignerPresent,
                    bool          isExecutorPresent);
                SomeAbsents (SomeAbsents const &);
                virtual ~SomeAbsents ();

                SomeAbsents &operator=(SomeAbsents const &);

                const char * what() const throw();
            private:
                bool _isIntPresent;
                bool _isSigPresent;
                bool _isExePresent;
        };

        OfficeBlock ();
        OfficeBlock (Intern *, Bureaucrat *, Bureaucrat *);
        virtual ~OfficeBlock ();

        void setIntern(Intern *);
        void setSigner(Bureaucrat *);
        void setExecutor(Bureaucrat *);

        void doBureaucracy(std::string const &nameForm,
            std::string const                &target);
    private:
        Intern * _intern;
        Bureaucrat * _signer;
        Bureaucrat * _executor;
};

#endif // ifndef OFFICEBLOCK_HPP
