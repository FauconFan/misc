/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/03 19:02:37 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/04 10:37:24 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "Bureaucrat.hpp"
#include "Form.hpp"
#include "PresidentialPardonForm.hpp"
#include "RobotomyRequestForm.hpp"
#include "ShrubberyCreationForm.hpp"
#include "Intern.hpp"
#include "OfficeBlock.hpp"

static void testInitBureaucrat() {
    std::cout << "Test Init Bureaucrat" << "\n\n";
    try
    {
        Bureaucrat b("b", -2);
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }
    try
    {
        Bureaucrat b("b", 200);
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }
    std::cout << '\n';
}

static void testHighBureaucrat(Bureaucrat &lewis) {
    std::cout << "Test High Bureaucrat" << "\n\n";
    try
    {
        while (true)
            lewis.inc();
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }

    std::cout << lewis;
    std::cout << '\n';
}

static void testLowBureaucrat(Bureaucrat &bob) {
    std::cout << "Test Low Bureaucrat" << "\n\n";
    try
    {
        while (true)
            bob.dec();
    }
    catch (std::exception &e)
    {
        std::cout << "Exception happens : " << e.what() << '\n';
    }

    std::cout << bob;
    std::cout << '\n';
}

// Remove testInitForm becuase Form Object is abstract now
// Remove testSignForm  because Form Onject is abstract now

static void testConcreteForms() {
    std::cout << "Test Concrete Forms" << "\n\n";
    Bureaucrat boss("boss", 1);
    Form *pp = new PresidentialPardonForm("Berlin");
    Form *pp2 = new PresidentialPardonForm("Rio");
    Form *rr = new RobotomyRequestForm("Bob-Lennon");
    Form *sc = new ShrubberyCreationForm("tree");

    boss.signForm(*pp);
    boss.executeForm(*pp);

    std::cout << '\n';

    boss.executeForm(*pp2);
    boss.signForm(*pp2);
    boss.signForm(*pp2);
    boss.executeForm(*pp2);

    std::cout << '\n';

    boss.signForm(*rr);

    for (size_t i = 0; i < 10; i++) {
        boss.executeForm(*rr);
    }

    boss.signForm(*sc);
    boss.executeForm(*sc);

    delete pp;
    delete pp2;
    delete rr;
    delete sc;
    std::cout << '\n';
}

static void testIntern() {
    std::cout << "Test Interns" << "\n\n";

    Intern corobizar;
    Form *fo = NULL;
    Bureaucrat boss("boss", 1);

    fo = corobizar.makeForm("presidential pardon", "sardoche");
    std::cout << *fo;
    boss.signForm(*fo);
    boss.executeForm(*fo);
    delete fo;
    std::cout << '\n';

    fo = corobizar.makeForm("shrubbery creation", "home");
    std::cout << *fo;
    boss.signForm(*fo);
    boss.executeForm(*fo);
    delete fo;
    std::cout << '\n';

    fo = corobizar.makeForm("robotomy request", "moon");
    std::cout << *fo;
    boss.signForm(*fo);
    boss.executeForm(*fo);
    delete fo;
    std::cout << '\n';

    corobizar.makeForm("oui", "oui");
    corobizar.makeForm("non", "oui");
    corobizar.makeForm("le", "oui");
    corobizar.makeForm("la", "oui");
    corobizar.makeForm("les", "oui");
    corobizar.makeForm("des", "oui");
    corobizar.makeForm("ceux", "oui");
    corobizar.makeForm("qui", "oui");
    corobizar.makeForm("lisent", "oui");
    corobizar.makeForm("sont", "oui");
    corobizar.makeForm("des", "oui");
    corobizar.makeForm("génies", "oui");
    corobizar.makeForm("!!", "oui");

    std::cout << '\n';
}

static void testOfficeBlock() {
    std::cout << "Test Office Block" << "\n\n";

    OfficeBlock ob;
    Intern redblob;
    Bureaucrat signer("signer", 25);
    Bureaucrat executor("executor", 5);

    ob.setIntern(&redblob);
    ob.setSigner(&signer);
    ob.setExecutor(&executor);

    ob.doBureaucracy("presidential pardon", "politics");
    std::cout << '\n';

    ob.doBureaucracy("presidential pardon", "economy");
    std::cout << '\n';

    ob.doBureaucracy("shrubbery creation", "park");
    std::cout << '\n';

    ob.doBureaucracy("robotomy request", "pool");
    std::cout << '\n';

    ob.doBureaucracy("robotomy request", "school");
    std::cout << '\n';

    ob.doBureaucracy("robotomy request", "market");
    std::cout << '\n';

    ob.doBureaucracy("robotomy request", "campain");
    std::cout << '\n';

    ob.setIntern(NULL);
    try
    {
        ob.doBureaucracy("robotomy request", "campain");
    }
    catch (std::exception &e)
    {
        std::cout << e.what() << '\n';
    }
    std::cout << '\n';

    ob.setSigner(NULL);
    ob.setExecutor(NULL);
    try
    {
        ob.doBureaucracy("robotomy request", "campain");
    }
    catch (std::exception &e)
    {
        std::cout << e.what() << '\n';
    }

    std::cout << '\n';
}

int main() {
    Bureaucrat bob("bob", 42);
    Bureaucrat lewis("lewis", 10);

    if (false) {
        std::cout << bob << lewis << '\n';

        testInitBureaucrat();
        testHighBureaucrat(lewis);
        testLowBureaucrat(bob);

        testConcreteForms();

        testIntern();
    }

    testOfficeBlock();

    return 0;
}
