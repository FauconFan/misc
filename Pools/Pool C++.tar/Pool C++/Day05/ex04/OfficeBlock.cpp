/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   OfficeBlock.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/04 09:58:39 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/04 10:24:11 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string>
#include "Intern.hpp"
#include "Bureaucrat.hpp"
#include "OfficeBlock.hpp"

OfficeBlock::SomeAbsents::SomeAbsents (
    bool isInternPresent,
    bool isSignerPresent,
    bool isExecutorPresent
) : _isIntPresent(isInternPresent),
    _isSigPresent(isSignerPresent),
    _isExePresent(isExecutorPresent) {}

OfficeBlock::SomeAbsents::SomeAbsents (SomeAbsents const & copy) {
    *this = copy;
}

OfficeBlock::SomeAbsents::~SomeAbsents () {}

OfficeBlock::SomeAbsents &OfficeBlock::SomeAbsents::operator=(
            SomeAbsents const & copy) {
    this->_isIntPresent = copy._isIntPresent;
    this->_isSigPresent = copy._isSigPresent;
    this->_isExePresent = copy._isExePresent;
    return *this;
}

const char *OfficeBlock::SomeAbsents::what() const throw() {
    if (this->_isIntPresent && this->_isSigPresent && this->_isExePresent)
        return "SNH : Everybody is here...";
    else if (!this->_isIntPresent && !this->_isSigPresent &&
                !this->_isExePresent)
        return "Everybody is missing";
    else if (!this->_isIntPresent)
        return "At least, Intern is missing";
    else if (!this->_isSigPresent)
        return "At least, Signer is missing";
    else if (!this->_isExePresent)
        return "At least, Executor is missing";
    return "SNH";
}


OfficeBlock::OfficeBlock() {
    this->_intern = NULL;
    this->_signer = NULL;
    this->_executor = NULL;
}

OfficeBlock::OfficeBlock(Intern *intern, Bureaucrat *signer, Bureaucrat *exec) {
    this->_intern = intern;
    this->_signer = signer;
    this->_executor = exec;
}

OfficeBlock::~OfficeBlock() {}

void OfficeBlock::setIntern(Intern *intern) {
    this->_intern = intern;
}

void OfficeBlock::setSigner(Bureaucrat *signer) {
    this->_signer = signer;
}

void OfficeBlock::setExecutor(Bureaucrat *exec) {
    this->_executor = exec;
}

void OfficeBlock::doBureaucracy(std::string const &nameForm,
        std::string const &target) {
    Form *fo;

    if (!(this->_intern && this->_signer && this->_executor))
    {
        throw SomeAbsents(this->_intern != NULL,
            this->_signer != NULL, this->_executor != NULL);
    }
    else
    {
        fo = this->_intern->makeForm(nameForm, target);
        if (fo != NULL)
        {
            this->_signer->signForm(*fo);
            if (fo->isSigned())
            {
                this->_executor->executeForm(*fo);
            }
        }
    }
}
