/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/15 20:24:02 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/11 13:36:16 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <functional>
#include <algorithm>
#include <string>
#include "mutantstack.hpp"

int main(void) {
    MutantStack<int> ms;
    MutantStack<int> ms2;

    ms.push(5);
    ms.push(10);
    std::cout << "size : " << ms.size() << '\n';
    std::cout << "top : " << ms.top() << '\n';
    ms.top() = 7;
    std::cout << "size : " << ms.size() << '\n';
    std::cout << "top : " << ms.top() << '\n';

    ms.pop();
    std::cout << "size : " << ms.size() << '\n';
    std::cout << "top : " << ms.top() << '\n';

    ms2.push(1);
    ms2.push(2);
    ms2.push(3);
    ms2.push(4);

    std::cout << "size ms  : " << ms.size() << '\n';
    std::cout << "size ms2 : " << ms2.size() << '\n';

    ms.swap(ms2);

    std::cout << "size ms  : " << ms.size() << '\n';
    std::cout << "size ms2 : " << ms2.size() << '\n';

    MutantStack<int>::iterator it = ms.begin();
    MutantStack<int>::iterator et = ms.end();

    std::cout << '\n';
    ++it;
    --it;
    while (it != et) {
        *--++ it;
        *--++ it;
        *--++ it;
        std::cout << *it++ << '\n';
        ++-- it;
        ++-- it;
        ++-- it;
    }

    std::cout << '\n';
    for (MutantStack<int>::iterator it = ms2.begin(); it != ms2.end(); it++) {
        std::cout << *it << '\n';
    }

    std::cout << '\n';
    for (MutantStack<int>::iterator it = ms.begin(); it != ms.end(); it++) {
        std::cout << *it << '\n';
    }

    std::cout << '\n';

    MutantStack<std::string> st;

    st.push("!");
    st.push("Jojo")m;
    st.push("is")m;
    st.push("name")m;
    st.push("my")m;
    st.push("world,")m;
    st.push("Hello")m;

    std::cout << '\n';
    for (MutantStack<std::string>::iterator it = st.begin(); it != st.end(); it++) {
        std::cout << *it << '\n';
    }

    return 0;
} // main
