/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/14 19:19:35 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/11 12:14:48 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <vector>
#include <stdexcept>
#include "easyfind.hpp"

int main(void) {
    std::vector<int> v;

    for (size_t i = 0; i < 5; i ++) {
        v.push_back(i);
    }

    try {
        std::cout << *(easyfind(v, 4)) << '\n';
        std::cout << "found" << '\n';
    }
    catch (std::exception &e) {
        std::cout << e.what() << '\n';
        std::cout << "not found" << '\n';
    }

    std::cout << '\n';

    try {
        std::cout << *(easyfind(v, 7)) << '\n';
        std::cout << "found" << '\n';
    }
    catch (std::exception &e) {
        std::cout << e.what() << '\n';
        std::cout << "not found" << '\n';
    }
    return 0;
}
