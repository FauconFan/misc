/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   easyfind.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/14 19:19:37 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/14 19:33:42 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef EASYFIND_HPP
#define EASYFIND_HPP

#include <algorithm>
#include <stdexcept>

template <typename T>
typename T::iterator easyfind(T &v, int i) {
    typename T::iterator t;

    t = std::find(v.begin(), v.end(), i);
    if (t != v.end())
        return t;

    throw std::exception();
}

#endif // ifndef EASYFIND_HPP
