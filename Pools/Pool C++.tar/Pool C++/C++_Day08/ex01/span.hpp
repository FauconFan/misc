/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   span.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/14 19:50:34 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/11 13:12:31 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SPAN_HPP
#define SPAN_HPP

#include <cstddef>
#include <vector>

class Span {
    public:
        Span (size_t n);
        Span (Span const &);
        virtual ~Span ();

        Span &operator=(Span const &);

        void addNumber(int);

        void show() const;
        void sort();

        int shortestSpan();
        int longestSpan();
    private:
        std::vector<int> data;
        size_t len_actu;
        bool is_sort;

        std::vector<int> generateSpans();
};

#endif // ifndef SPAN_HPP
