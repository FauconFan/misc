/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Bureaucrat.hpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/03 18:46:11 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/11 08:19:54 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef BUREAUCRATE_HPP
#define BUREAUCRATE_HPP

#include <stdexcept>
#include <string>
#include <iostream>
#include "Form.hpp"

// Reversed order, it's normal
#define MAX_RANK        1
#define MIN_RANK        150

class Form;

class Bureaucrat {
    public:
        Bureaucrat (std::string const &name, int grade)
            throw(GradeTooHighException, GradeTooLowException);
        Bureaucrat (Bureaucrat const &) throw();
        virtual ~Bureaucrat () throw();

        Bureaucrat &operator=(Bureaucrat const &) throw();

        std::string const getName() const throw();
        int getGrade() const throw();

        void inc() throw(GradeTooHighException);
        void dec() throw(GradeTooLowException);

        void signForm(Form &) const;

    private:
        const std::string _name;
        int _grade;

        Bureaucrat ();

        class GradeTooHighException : public std::exception {
            public:
                GradeTooHighException ();
                GradeTooHighException (const GradeTooHighException &);
                virtual ~GradeTooHighException () throw();

                const char * what() const throw();

            private:
                GradeTooHighException &operator=(GradeTooHighException const &);
        };

        class GradeTooLowException : public std::exception {
            public:
                GradeTooLowException ();
                GradeTooLowException (const GradeTooLowException &);
                virtual ~GradeTooLowException () throw();

                const char * what() const throw();

            private:
                GradeTooLowException &operator=(GradeTooLowException const &);
        };
};

std::ostream &operator<<(std::ostream &, Bureaucrat const &);

#endif // ifndef BUREAUCRAT_HPP
