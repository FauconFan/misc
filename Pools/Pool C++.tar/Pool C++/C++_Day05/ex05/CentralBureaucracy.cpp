/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   CentralBureaucracy.cpp                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/08 13:43:56 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/09 10:17:40 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <cstdlib>
#include <iostream>
#include <ctime>
#include "CentralBureaucracy.hpp"

CentralBureaucracy::CentralBureaucracy() {
	Intern		*intern_ptr;

	this->blocks = new OfficeBlock *[NB_BLOCKS];
	for (size_t i = 0; i < NB_BLOCKS; i++) {
		intern_ptr = new Intern();
		this->blocks[i] = new OfficeBlock(intern_ptr);
	}
	this->head = NULL;
	this->last = NULL;
}

CentralBureaucracy::~CentralBureaucracy() {
	for (size_t i = 0; i < NB_BLOCKS; i++) {
		delete this->blocks[i]->getIntern();
		delete this->blocks[i];
	}
	delete [] this->blocks;
	if (this->head != NULL)
		delete this->head;
}

bool CentralBureaucracy::feedBureaucrat(Bureaucrat * bur)
{
	OfficeBlock		*office_ptr;

	for (size_t i = 0; i < NB_BLOCKS; i++) {
		office_ptr = this->blocks[i];
		if (office_ptr->hasSigner() == false)
		{
			office_ptr->setSigner(bur);
			return true;
		}
		else if (office_ptr->hasExecutor() == false)
		{
			office_ptr->setExecutor(bur);
			return true;
		}
	}
	return false;
}

void CentralBureaucracy::queueUp(std::string const & str) {
	ListTask *elem;

	elem = new ListTask (str, NULL);
	if (this->last == NULL)
	{
		this->head = elem;
		this->last = this->head;
	}
	else
	{
		this->last->setNext(elem);
		this->last = this->last->getNext();
	}
}

void CentralBureaucracy::doBureaucracy() throw () {
	ListTask		*tmp;
	std::string		name;
	bool			isrunning;
	OfficeBlock		*office;
	int				id;

	while (this->head != NULL)
	{
		name = this->head->getName();
		tmp = this->head->getNext();
		this->head->setNext(NULL);
		delete this->head;
		this->head = tmp;

		isrunning = true;

		while (isrunning) {
			try
		    {
				id = rand() % NB_BLOCKS;
				std::cout << "Task \"" << name << "\" assigned to block id " << id << '\n';
				office = this->blocks[id];
				if (office->doBureaucracy("presidential pardon", name))
					isrunning = false;
		    }
		    catch (std::exception &e)
		    {
		        std::cout << "Exception happens : " << e.what() << '\n';
		    }
		}
	}
	this->last = NULL;
}

// C++11 feature
// using ListTask = CentralBureaucracy::ListTask;

CentralBureaucracy::ListTask::ListTask (std::string str, ListTask *next)
{
	this->name = std::string(str);
	this->next = next;
}

CentralBureaucracy::ListTask::~ListTask ()
{
	if (this->next != NULL)
		delete this->next;
}

std::string CentralBureaucracy::ListTask::getName() const {return this->name;}
CentralBureaucracy::ListTask *CentralBureaucracy::ListTask::getNext() const {return this->next;}

// The actual next pointer can be lost
// Use wisely
void CentralBureaucracy::ListTask::setNext(ListTask *next)
{
	this->next = next;
}
