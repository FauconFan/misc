/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   CentralBureaucracy.hpp                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/08 13:38:03 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/09 09:56:04 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CENTRALBUREAUCRACY_HPP
#define CENTRALBUREAUCRACY_HPP

#include "Bureaucrat.hpp"
#include "Form.hpp"
#include "Intern.hpp"
#include "OfficeBlock.hpp"

#define NB_BLOCKS		20

class CentralBureaucracy {
	public:
		CentralBureaucracy ();
		virtual ~CentralBureaucracy ();

		bool feedBureaucrat(Bureaucrat *);

		void queueUp(std::string const &);

		void doBureaucracy() throw ();
	private:
		class ListTask {
			public:
				ListTask (std::string, ListTask *next);
				virtual ~ListTask ();

				std::string getName() const;
				ListTask *getNext() const;

				void setNext(ListTask *next);
			private:
				std::string name;
				ListTask *next;

				ListTask ();
				ListTask (ListTask const &);
				ListTask &operator=(ListTask const &);
		};

		OfficeBlock		**blocks;
		ListTask		*head;
		ListTask		*last;

		CentralBureaucracy (const CentralBureaucracy &);

		CentralBureaucracy &operator=(CentralBureaucracy const &);
};

#endif
