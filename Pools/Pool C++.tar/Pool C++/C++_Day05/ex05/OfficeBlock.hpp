/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   OfficeBlock.hpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/04 09:55:19 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/09 10:09:14 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef OFFICEBLOCK_HPP
#define OFFICEBLOCK_HPP

#include <string>
#include <stdexcept>
#include "Intern.hpp"
#include "Bureaucrat.hpp"

class OfficeBlock {
    public:
        OfficeBlock ();
        OfficeBlock (Intern *);
        OfficeBlock (Intern *, Bureaucrat *, Bureaucrat *);
        virtual ~OfficeBlock ();

        Intern * getIntern() const;

        void setIntern(Intern *);
        void setSigner(Bureaucrat *);
        void setExecutor(Bureaucrat *);

        bool hasIntern() const;
        bool hasSigner() const;
        bool hasExecutor() const;

        bool doBureaucracy(std::string const &nameForm,
            std::string const                &target);
    private:
        Intern * _intern;
        Bureaucrat * _signer;
        Bureaucrat * _executor;

        OfficeBlock (OfficeBlock const &);
        OfficeBlock &operator=(OfficeBlock const &);

        class SomeAbsents : public std::exception {
            public:
                SomeAbsents (bool isInternPresent,
                    bool          isSignerPresent,
                    bool          isExecutorPresent);
                SomeAbsents (SomeAbsents const &);
                virtual ~SomeAbsents () throw ();

                SomeAbsents &operator=(SomeAbsents const &);

                const char * what() const throw();
            private:
                bool _isIntPresent;
                bool _isSigPresent;
                bool _isExePresent;

                SomeAbsents ();
        };
};

#endif // ifndef OFFICEBLOCK_HPP
