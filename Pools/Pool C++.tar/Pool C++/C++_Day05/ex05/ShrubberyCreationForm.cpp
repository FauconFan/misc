/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ShrubberyCreationForm.cpp                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/04 09:19:39 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/11 08:43:31 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string>
#include <fstream>
#include "ShrubberyCreationForm.hpp"

ShrubberyCreationForm::ShrubberyCreationForm(std::string const &target)
    : Form("SC-" + target, 145, 137), _target(target) {}


ShrubberyCreationForm::ShrubberyCreationForm(ShrubberyCreationForm const &copy)
    : Form(copy.getName() + "-copy", 145, 137) {
    *this = copy;
}

ShrubberyCreationForm::~ShrubberyCreationForm() {}

ShrubberyCreationForm &ShrubberyCreationForm::operator=(
  ShrubberyCreationForm const & copy) {
    this->_target = copy.getTarget();
    return *this;
}

std::string const ShrubberyCreationForm::getTarget() const {
    return this->_target;
}

void ShrubberyCreationForm::beExecuted() const {
    std::ofstream afile((this->_target + "_shruberry").c_str(), std::ios::out);

    if (afile.is_open()) {
        afile << "T\n";
        afile.close();
    }
}
