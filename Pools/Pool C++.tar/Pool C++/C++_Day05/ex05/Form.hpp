/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Form.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/03 19:42:14 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/11 08:29:28 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FORM_HPP
#define FORM_HPP

#include <stdexcept>
#include <string>
#include <iostream>
#include "Bureaucrat.hpp"

#define FORM_OOB_EXC       "OutOfBounds Exception"
#define FORM_TLOW_SIGN_EXC "The grade is too low to sign"
#define FORM_TLOW_EXEC_EXC "The grade is too low to execute"
#define FORM_ALSIGNED_EXC  "The form is already signed"
#define FORM_NOTSIGNED_EXC "The form cannot be executed, if it's not signed"

class Bureaucrat;

class Form {
    public:
        Form (std::string const &name, int minGradeSign, int minGradeExec);
        Form (Form const &);
        virtual ~Form ();

        Form &operator=(Form const &);

        std::string const getName() const;
        bool isSigned() const;
        int getMinGradeSign() const;
        int getMinGradeExec() const;

        void beSigned(Bureaucrat const &);
        virtual void beExecuted() const = 0;

        void execute(Bureaucrat const &) const;
    private:
        const std::string _name;
        bool _isSigned;
        int _minGradeSign;
        int _minGradeExec;

        Form ();
        std::string const copyName(std::string const);

        class GradeTooHighException : public std::exception {
            public:
                GradeTooHighException ();
                GradeTooHighException (GradeTooHighException const & gthe);
                virtual ~GradeTooHighException () throw ();

                const char * what() const throw();

            private:
                GradeTooHighException &operator=(GradeTooHighException const & gthe);
        };

        class GradeTooLowException : public std::exception {
            public:
                GradeTooLowException (const char * msg);
                GradeTooLowException (GradeTooLowException const &);
                virtual ~GradeTooLowException () throw ();

                const char * what() const throw();
            private:
                const char * _msg;

                GradeTooLowException &operator=(GradeTooLowException const &);
        };

        class AlreadySignedException : public std::exception {
            public:
                AlreadySignedException ();
                AlreadySignedException (AlreadySignedException const &);
                virtual ~AlreadySignedException () throw ();

                const char * what() const throw();

            private:
                AlreadySignedException &operator=(AlreadySignedException const &);
        };

        class NotSignedException : public std::exception {
            public:
                NotSignedException ();
                NotSignedException (const NotSignedException &);
                virtual ~NotSignedException () throw ();

                const char * what() const throw();

            private:
                NotSignedException &operator=(NotSignedException const &);
        };
};

std::ostream &operator<<(std::ostream &, Form const &);

#endif // ifndef FORM_HPP
