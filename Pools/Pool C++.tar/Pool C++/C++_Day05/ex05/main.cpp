/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/03 19:02:37 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/09 10:20:30 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <cstdlib>
#include <iostream>
#include <ctime>
#include "CentralBureaucracy.hpp"
#include "Bureaucrat.hpp"

#define NB_BUREAUCRAT       30
#define NB_PERSON           50

int main() {
    srand(time(NULL));

    CentralBureaucracy central;
    Bureaucrat  *list_bureaucrat[NB_BUREAUCRAT];
    int grade;

    for (size_t i = 0; i < NB_PERSON; i++) {
        central.queueUp("Robert");
    }
    list_bureaucrat[0] = new Bureaucrat ("Boss", 1);
    list_bureaucrat[1] = new Bureaucrat ("Vice Boss", 2);
    for (size_t i = 2; i < NB_BUREAUCRAT; i++) {
        if (rand() % 3 == 0)
            grade = MAX_RANK + (rand() % 30);
        else
            grade = MAX_RANK + (rand() % (10));
        list_bureaucrat[i] = new Bureaucrat ("Bureaucrat", grade);
    }

    for (size_t i = 0; i < NB_BUREAUCRAT; i++) {
        central.feedBureaucrat(list_bureaucrat[i]);
    }

    central.doBureaucracy();


    for (size_t i = 0; i < NB_BUREAUCRAT; i++) {
        delete list_bureaucrat[i];
    }

    return 0;
}
