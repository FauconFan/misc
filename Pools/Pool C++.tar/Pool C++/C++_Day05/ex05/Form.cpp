/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Form.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/03 19:45:55 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/11 08:29:18 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Form.hpp"
#include "Bureaucrat.hpp"

/**
 * Declaration of Form
 */

Form::Form(std::string const &name, int minGradeSign, int minGradeExec)
    : _name(name), _isSigned(false) {
    if (minGradeSign < 1 || minGradeExec < 1)
        throw GradeTooHighException();
    else if (minGradeSign > 150 || minGradeExec > 150)
        throw GradeTooLowException(FORM_OOB_EXC);
    this->_minGradeSign = minGradeSign;
    this->_minGradeExec = minGradeExec;
}

std::string     const Form::copyName(std::string const str)
{
    std::string copy(str);
    return copy + ".copy";
}

Form::Form(Form const & copy) : _name(this->copyName(copy._name)) {
    *this = copy;
}

Form::~Form() {}

Form &Form::operator=(Form const & copy) {
    this->_isSigned     = false;
    this->_minGradeSign = copy.getMinGradeSign();
    this->_minGradeExec = copy.getMinGradeExec();
    return *this;
}

std::string const Form::getName() const {
    return this->_name;
}

bool Form::isSigned() const {
    return this->_isSigned;
}

int Form::getMinGradeSign() const {
    return this->_minGradeSign;
}

int Form::getMinGradeExec() const {
    return this->_minGradeExec;
}

void Form::beSigned(Bureaucrat const &bu) {
    if (this->_isSigned)
        throw AlreadySignedException();
    if (this->_minGradeSign < bu.getGrade())
        throw GradeTooLowException(FORM_TLOW_SIGN_EXC);
    this->_isSigned = true;
}

void Form::execute(Bureaucrat const & executor) const {
    if (this->_isSigned == false)
        throw NotSignedException();
    else if (this->_minGradeExec < executor.getGrade())
        throw GradeTooLowException(FORM_TLOW_EXEC_EXC);
    this->beExecuted();
}

std::ostream &operator<<(std::ostream &os, Form const &fo) {
    os << "Form " << fo.getName() << " ";
    if (fo.isSigned())
        os << "has been signed.";
    else
        os << "is not signed yet.";
    os << "\n";
    os << "Min Grade to Sign it : " << fo.getMinGradeSign() << "\n";
    os << "Min Grade to Exec it : " << fo.getMinGradeExec() << "\n";
    return os;
}

/**
 * Declaration of Form::GradeTooHighException
 */

Form::GradeTooHighException::GradeTooHighException() {}

Form::GradeTooHighException::GradeTooHighException(GradeTooHighException const & copy) {
    *this = copy;
}

Form::GradeTooHighException::~GradeTooHighException() throw () {}

Form::GradeTooHighException &Form::GradeTooHighException::operator=(GradeTooHighException const &copy) {
    (void)copy;
    return *this;
}

const char * Form::GradeTooHighException::what() const throw() {
    return FORM_OOB_EXC;
}

/**
 * Declaration of Form::GradeTooLowException
 */

Form::GradeTooLowException::GradeTooLowException(const char * msg)
    : _msg(msg) {}

Form::GradeTooLowException::GradeTooLowException(GradeTooLowException const & copy) {
    *this = copy;
}

Form::GradeTooLowException::~GradeTooLowException() throw () {}

Form::GradeTooLowException &Form::GradeTooLowException::operator=(
  GradeTooLowException const &copy) {
    this->_msg = copy._msg;
    return *this;
}

const char * Form::GradeTooLowException::what() const throw() {
    return this->_msg;
}

/**
 * Declaration of Form::AlreadySignedException
 */

Form::AlreadySignedException::AlreadySignedException() {}

Form::AlreadySignedException::AlreadySignedException(AlreadySignedException const & ase)
{
    *this = ase;
}

Form::AlreadySignedException::~AlreadySignedException() throw () {}

Form::AlreadySignedException &Form::AlreadySignedException::operator=(AlreadySignedException const & copy) {
    (void)copy;
    return *this;
}

const char * Form::AlreadySignedException::what() const throw () {
    return FORM_ALSIGNED_EXC;
}

/**
 * Declaration Form::NotSignedException
 */

Form::NotSignedException::NotSignedException() {}

Form::NotSignedException::~NotSignedException() throw () {}

Form::NotSignedException::NotSignedException(NotSignedException const & copy) {
    *this = copy;
}

Form::NotSignedException &Form::NotSignedException::operator=(NotSignedException const & copy) {
    (void)copy;
    return *this;
}

const char * Form::NotSignedException::what() const throw () {
    return FORM_NOTSIGNED_EXC;
}
