/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Bureaucrat.cpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/03 18:53:33 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/11 08:20:16 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Bureaucrat.hpp"

/**
 * Declaration of Bureaucrat
 */

Bureaucrat::Bureaucrat(std::string const &name, int grade)
throw(GradeTooHighException, GradeTooLowException)
    : _name(name) {
    if (grade < MAX_RANK)
        throw GradeTooHighException();
    else if (grade > MIN_RANK)
        throw GradeTooLowException();
    this->_grade = grade;
}

Bureaucrat::Bureaucrat(Bureaucrat const & copy) throw() {
    *this = copy;
}

Bureaucrat::~Bureaucrat() throw() {}

Bureaucrat &Bureaucrat::operator=(Bureaucrat const & copy) throw() {
    this->_grade = copy._grade;
    return *this;
}

std::string const Bureaucrat::getName() const throw() {
    return this->_name;
}

int Bureaucrat::getGrade() const throw() {
    return this->_grade;
}

void Bureaucrat::inc() throw(GradeTooHighException) {
    if (this->_grade == MAX_RANK)
        throw GradeTooHighException();
    this->_grade--;
}

void Bureaucrat::dec() throw(GradeTooLowException) {
    if (this->_grade == MIN_RANK)
        throw GradeTooLowException();
    this->_grade++;
}

void Bureaucrat::signForm(Form &fo) const {
    try
    {
        fo.beSigned(*this);
        std::cout << this->_name << " signs " << fo.getName() << '\n';
    }
    catch (std::exception const &e)
    {
        std::cout << this->_name << " cannot sign " << fo.getName()
                  << " because \"" << e.what() << "\"\n";
    }
}

void Bureaucrat::executeForm(Form const &fo) const {
    try
    {
        fo.execute(*this);
        std::cout << this->_name << " executes " << fo.getName() << '\n';
    }
    catch (std::exception const &e)
    {
        std::cout << this->_name << " cannot execute " << fo.getName()
                  << " because \"" << e.what() << "\"\n";
    }
}

std::ostream &operator<<(std::ostream &os, Bureaucrat const &b) {
    return os << b.getName() << ", Bureaucrat grade " << b.getGrade() << ".\n";
}

/**
 * Declaration of Bureaucrat::GradeTooHighException
 */

Bureaucrat::GradeTooHighException::GradeTooHighException() {}

Bureaucrat::GradeTooHighException::GradeTooHighException(const GradeTooHighException & gthe)
{
    *this = gthe;
}

Bureaucrat::GradeTooHighException::~GradeTooHighException() throw () {}

Bureaucrat::GradeTooHighException &Bureaucrat::GradeTooHighException::operator=(GradeTooHighException const & gthe)
{
    (void)gthe;
    return *this;
}

const char * Bureaucrat::GradeTooHighException::what() const throw() {
    return "The grade is becoming too high !";
}

/**
 * Declaration of Bureaucrat::GradeTooLowException
 */

Bureaucrat::GradeTooLowException::GradeTooLowException() {}

Bureaucrat::GradeTooLowException::GradeTooLowException(const GradeTooLowException & gtle)
{
    *this = gtle;
}

Bureaucrat::GradeTooLowException::~GradeTooLowException() throw () {}

Bureaucrat::GradeTooLowException &Bureaucrat::GradeTooLowException::operator=(GradeTooLowException const & gtle)
{
    (void)gtle;
    return *this;
}

const char * Bureaucrat::GradeTooLowException::what() const throw() {
    return "The grade can't be that low...";
}
