/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Data.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/11 20:19:39 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/11 20:31:40 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef DATA_HPP
#define DATA_HPP

#include <string>

struct Data {
    std::string s1;
    int         n;
    std::string s2;
};

void * serialize(void);
Data * deserialize(void *);

void pretty_print(Data *);

#endif // ifndef DATA_HPP
