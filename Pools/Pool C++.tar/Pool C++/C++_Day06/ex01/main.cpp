/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/11 20:16:22 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/11 20:34:54 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <string>
#include <time.h>
#include <stdlib.h>
#include "Data.hpp"

int         main(void) {
    srand(time(NULL));
    void * buff;
    Data * raw;

    for (size_t i = 0; i < 5; i++) {
        buff = serialize();
        raw  = deserialize(buff);

        pretty_print(raw);
        delete raw;
    }
    return 0;
}
