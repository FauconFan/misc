/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/11 19:39:21 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/09 18:54:09 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "Value.class.hpp"

static void     treat_argv(char *argv)
{
    try
    {
        Value v(argv);

        v.displayCharRep();
        v.displayIntRep();
        v.displayFloatRep();
        v.displayDoubleRep();
    }
    catch (const std::exception &e)
    {
        std::cout << e.what() << '\n';
    }
}

int             main(int argc, char ** argv) {
    if (argc < 2)
        return 0;

    for (int i = 1; i < argc; i++) {
        treat_argv(argv[i]);

        if (i != argc - 1)
            std::cout << '\n';
    }
}
