/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   NoConversionException.class.hpp                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/11 19:18:34 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/09 18:16:57 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef NO_CONVERSION_CLASS_HPP
#define NO_CONVERSION_CLASS_HPP

#include <stdexcept>

#define NO_CONV_EXC "Impossible"

class NoConversionException : public std::exception {
    public:
        NoConversionException ();
        NoConversionException (NoConversionException const &);
        virtual ~NoConversionException () throw ();

        NoConversionException &operator=(NoConversionException const &);

        const char * what() const throw();
};

#endif // ifndef NO_CONVERSION_CLASS_HPP
