/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   NoConversionException.class.cpp                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/11 19:19:34 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/09 17:18:57 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "NoConversionException.class.hpp"

NoConversionException::NoConversionException() {}

NoConversionException::NoConversionException(
  NoConversionException const & copy) {
    *this = copy;
}

NoConversionException::~NoConversionException() throw () {}

NoConversionException &NoConversionException::operator=(
  NoConversionException const &copy) {
    (void) copy;
    return *this;
}

const char * NoConversionException::what() const throw() {
    return NO_CONV_EXC;
}
