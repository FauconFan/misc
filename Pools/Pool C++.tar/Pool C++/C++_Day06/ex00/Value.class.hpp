/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Value.class.hpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/11 19:23:11 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/09 19:18:08 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef VALUE_CLASS_HPP
#define VALUE_CLASS_HPP

#include "NoConversionException.class.hpp"

class Value {
    public:
        Value (char *) throw (NoConversionException);
        Value (Value const &);
        virtual ~Value ();

        Value &operator=(Value const &);

        operator char(void) const;
        operator int(void) const;
        operator float(void) const;
        operator double(void) const;

        void displayCharRep() const;
        void displayIntRep() const;
        void displayFloatRep() const;
        void displayDoubleRep() const;
    private:
        char * _entry;

        Value ();
};

#endif // ifndef VALUE_CLASS_HPP
