/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Value.class.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/11 19:23:12 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/09 19:18:38 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <sstream>
#include <iostream>
#include <iomanip>
#include <limits>
#include "NoConversionException.class.hpp"
#include "Value.class.hpp"
#include "errno.h"

Value::Value (char * entry) throw (NoConversionException) {
    char                *tmp;
    std::string         str(entry);
    std::stringstream   ss;
    size_t              i;

    if (str.length() == 1 && std::isdigit(str[0]) == false)
    {
        int ascii = static_cast<int>(str[0]);
        ss << ascii;
        tmp = const_cast<char *>(ss.str().c_str());
        i = -1;
        while (tmp[++i])
            entry[i] = tmp[i];
        entry[i] = 0;
    }
    this->_entry = entry;
}

Value::Value (Value const & copy) {
    *this = copy;
}

Value::~Value () {}

Value &Value::operator=(Value const & copy) {
    this->_entry = copy._entry;
    return *this;
}

Value::operator char(void) const {
    char c = static_cast<char>(std::atoi(this->_entry));

    if (errno)
    {
        errno = 0;
        throw NoConversionException();
    }
    return c;
}

Value::operator int(void) const {
    int n = std::atoi(this->_entry);

    if (errno)
    {
        errno = 0;
        throw NoConversionException();
    }
    return n;
}

Value::operator float(void) const {
    float f = std::atof(this->_entry);
    char *cpy;

    if (errno == ERANGE)
    {
        f = std::numeric_limits<float>::infinity();
        cpy = this->_entry;
        while (std::isspace(*cpy))
            cpy++;
        if (*cpy == '-')
            f = -1 * f;
        errno = 0;
    }
    if (errno)
    {
        errno = 0;
        throw NoConversionException();
    }
    return f;
}

Value::operator double(void) const {
    double d = std::strtod(this->_entry, NULL);
    char *cpy;

    if (errno == ERANGE)
    {
        d = std::numeric_limits<double>::infinity();
        cpy = this->_entry;
        while (std::isspace(*cpy))
            cpy++;
        if (*cpy == '-')
            d = -1 * d;
        errno = 0;
    }
    if (errno)
    {
        errno = 0;
        throw NoConversionException();
    }
    return d;
}

void Value::displayCharRep() const {
    std::cout << "char : ";

    try {
        char c = static_cast<char>(*this);
        if (c >= 32 && c < 127) {
            std::cout << "\'" << c << "\'";
        }
        else {
            std::cout << "Non displayable";
        }
    } catch (std::exception &e) {
        std::cout << e.what();
    }
    std::cout << '\n';
}

void Value::displayIntRep() const {
    std::cout << "int: ";

    try {
        std::cout << static_cast<int>(*this);
    } catch (std::exception &e) {
        std::cout << e.what();
    }
    std::cout << '\n';
}

void Value::displayFloatRep() const {
    std::cout << "float: ";

    try {
        std::cout << std::setprecision(20) << static_cast<float>(*this) << 'f';
    } catch (std::exception &e) {
        std::cout << e.what();
    }
    std::cout << '\n';
}

void Value::displayDoubleRep() const {
    std::cout << "double: ";

    try {
        std::cout << std::setprecision(20) << static_cast<double>(*this);
    } catch (std::exception &e) {
        std::cout << e.what();
    }
    std::cout << '\n';
}
