/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   constants.hpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nterrier <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 16:42:28 by nterrier          #+#    #+#             */
/*   Updated: 2018/10/07 22:59:56 by nterrier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CONSTANTS_HPP
#define CONSTANTS_HPP

#define FPS           60.0
#define SHIPSPEED     3.0f
#define SHOOTCOOLDOWN 15.0
#define STAR_FREQ     10 // The lower, the more stars
#define ENEMY_FREQ    50 // The lower, the more enemys

#define COLOR_GRAY    COLOR_MAGENTA
#define WHITE_PAIR    1
#define GREEN_PAIR    2
#define RED_PAIR      3
#define GRAY_PAIR     4
#define MENU_BASIC    5
#define MENU_LIFES    6
#define MENU_SCORE    7

#endif // ifndef CONSTANTS_HPP
