/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   EntityPlayer.class.cpp                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nterrier <nterrier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 16:24:45 by nterrier          #+#    #+#             */
/*   Updated: 2018/10/07 21:23:28 by nterrier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "EntityPlayer.class.hpp"

EntityPlayer::EntityPlayer(float x, float y, char c)
    : GameEntity(x, y, c), _nextShoot(0), _dx(0), _dy(0) {
    this->_lives    = 5;
    this->_livesMax = 5;
}

EntityPlayer::EntityPlayer(const EntityPlayer & src) {*this = src;} // SNH

EntityPlayer & EntityPlayer::operator=(EntityPlayer const & rhs) {(void) rhs; return *this;} // SNH

EntityPlayer::~EntityPlayer(void) {}

void EntityPlayer::move(int dx, int dy) {
    this->_dx += dx;
    this->_dy += dy;
}

void EntityPlayer::tick(const int & max_width, const int & max_height) {
    if (this->_nextShoot > 0)
        this->_nextShoot--;
    this->_x += std::min(std::max(this->_dx, -SHIPSPEED), SHIPSPEED);
    this->_x  = std::min(std::max(this->_x, 2.0f), max_width / 2.0f);
    this->_dx = 0;
    this->_y += std::min(std::max(this->_dy, -SHIPSPEED), SHIPSPEED);
    this->_y  = std::min(std::max(this->_y, 1.0f), max_height - 2.0f);
    this->_dy = 0;
}

EntityBullet    * EntityPlayer::shoot(void) {
    if (this->_nextShoot == 0) {
        EntityBullet * bullet = new EntityBullet(this->_x + 1, this->_y, '-', 0.7, 0,
                this->is_enemy());
        this->_nextShoot = SHOOTCOOLDOWN;
        return bullet;
    }
    else {
        return NULL;
    }
}

bool EntityPlayer::is_enemy(void) {return true;}
