/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   EntityEnemy.class.hpp                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nterrier <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 15:56:33 by nterrier          #+#    #+#             */
/*   Updated: 2018/10/07 22:40:55 by nterrier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ENTITYENEMY_HPP
#define ENTITYENEMY_HPP

#include <iostream>
#include "GameEntity.class.hpp"
#include <cmath>

class EntityEnemy : public GameEntity {
    public:
        EntityEnemy(float x, float y, char c, int algo, int dest, GameEntity * target);
        virtual ~EntityEnemy(void);

        virtual void    tick(const int & max_width, const int & max_height);
        virtual bool    is_enemy(void);

    protected:
        int _algo;
        int _algo_time;
        int _algo_destination;
        GameEntity * _algo_target;

    private:
        EntityEnemy(void) {};
        EntityEnemy(const EntityEnemy & src);
        EntityEnemy & operator=(const EntityEnemy & rhs);
};

#endif // ifndef ENTITYENEMY_HPP
