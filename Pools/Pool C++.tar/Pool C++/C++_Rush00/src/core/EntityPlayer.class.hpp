/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   EntityPlayer.class.hpp                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nterrier <nterrier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 16:25:28 by nterrier          #+#    #+#             */
/*   Updated: 2018/10/07 21:23:06 by nterrier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ENTITYPLAYER_HPP
#define ENTITYPLAYER_HPP

#include <iostream>
#include "GameEntity.class.hpp"
#include "EntityBullet.class.hpp"
#include "constants.hpp"

class EntityPlayer : public GameEntity {
    public:
        EntityPlayer(float x, float y, char c);
        virtual ~EntityPlayer(void);

        virtual void    tick(const int & max_width, const int & max_height);
        virtual bool    is_enemy(void);

        void move(int dx, int dy);
        EntityBullet * shoot(void);

    protected:
        int _nextShoot;// cooldown between shoots
        float _dx;
        float _dy;

    private:
        EntityPlayer(void) {};
        EntityPlayer(const EntityPlayer & src);
        EntityPlayer & operator=(const EntityPlayer & rhs);
};

#endif // ifndef ENTITYPLAYER_HPP
