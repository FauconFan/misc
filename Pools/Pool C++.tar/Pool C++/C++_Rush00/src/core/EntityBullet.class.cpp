/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   EntityBullet.class.cpp                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nterrier <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 14:35:34 by nterrier          #+#    #+#             */
/*   Updated: 2018/10/07 21:21:21 by nterrier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "EntityBullet.class.hpp"

EntityBullet::EntityBullet(float x, float y, char c, float speedX, float speedY, bool is_enemy)
    : GameEntity(x, y, c), _speedX(speedX), _speedY(speedY), _is_enemy(is_enemy) {}

EntityBullet::~EntityBullet(void) {}

EntityBullet::EntityBullet(const EntityBullet & src) {*this = src;} // SNH

EntityBullet & EntityBullet::operator=(EntityBullet const & rhs) {(void) rhs; return *this;} // SNH


void EntityBullet::tick(const int & max_width, const int & max_height) {
    (void) max_width;
    (void) max_height;
    this->_x += this->_speedX;
    this->_y += this->_speedY;
}

bool EntityBullet::is_enemy(void) {return this->_is_enemy;}
