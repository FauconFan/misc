/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   EntityBullet.class.hpp                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nterrier <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 14:39:53 by nterrier          #+#    #+#             */
/*   Updated: 2018/10/07 21:21:36 by nterrier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ENTITYBULLET_CLASS_HPP
#define ENTITYBULLET_CLASS_HPP

#include <iostream>
#include "GameEntity.class.hpp"

class EntityBullet : public GameEntity {
    public:
        EntityBullet(float x, float y, char c, float speedX, float speedY, bool is_enemy);
        virtual ~EntityBullet(void);

        virtual void    tick(const int & max_width, const int & max_height);
        virtual bool    is_enemy(void);

    protected:
        float _speedX;
        float _speedY;
        bool _is_enemy;

    private:
        EntityBullet(void) {};
        EntityBullet(const EntityBullet & src);
        EntityBullet & operator=(const EntityBullet & rhs);
};

#endif // ifndef ENTITYBULLET_CLASS_HPP
