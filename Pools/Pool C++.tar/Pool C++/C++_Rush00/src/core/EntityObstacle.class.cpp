/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   EntityObstacle.class.cpp                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nterrier <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 14:35:34 by nterrier          #+#    #+#             */
/*   Updated: 2018/10/07 21:22:38 by nterrier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "EntityObstacle.class.hpp"

EntityObstacle::EntityObstacle(float x, float y, char c, float speedX, float speedY)
    : GameEntity(x, y, c), _speedX(speedX), _speedY(speedY) {}

EntityObstacle::~EntityObstacle(void) {}

EntityObstacle::EntityObstacle(const EntityObstacle & src) {*this = src;} // SNH

EntityObstacle & EntityObstacle::operator=(EntityObstacle const & rhs) {(void) rhs; return *this;} // SNH


void EntityObstacle::tick(const int & max_width, const int & max_height) {
    (void) max_width;
    (void) max_height;
    this->_x += this->_speedX;
    this->_y += this->_speedY;
}

bool EntityObstacle::is_enemy(void) {return true;}
