/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   EntityObstacle.class.hpp                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nterrier <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 14:39:53 by nterrier          #+#    #+#             */
/*   Updated: 2018/10/07 21:22:51 by nterrier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ENTITYOBSTACLE_HPP
#define ENTITYOBSTACLE_HPP

#include <iostream>
#include "GameEntity.class.hpp"

class EntityObstacle : public GameEntity {
    public:
        EntityObstacle(float x, float y, char c, float speedX, float speedY);
        virtual ~EntityObstacle(void);

        virtual void    tick(const int & max_width, const int & max_height);
        virtual bool    is_enemy(void);

    protected:
        float _speedX;
        float _speedY;

    private:
        EntityObstacle(void) {};
        EntityObstacle(const EntityObstacle & src);
        EntityObstacle & operator=(const EntityObstacle & rhs);
};

#endif // ifndef ENTITYOBSTACLE_HPP
