/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   EntityEnemy.class.cpp                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nterrier <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 15:52:37 by nterrier          #+#    #+#             */
/*   Updated: 2018/10/07 22:56:21 by nterrier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "EntityEnemy.class.hpp"

EntityEnemy::EntityEnemy(float x, float y, char c, int algo, int dest, GameEntity * target)
    : GameEntity(x, y, c), _algo(algo), _algo_time(0), _algo_destination(dest),
    _algo_target(target) {}

EntityEnemy::EntityEnemy(const EntityEnemy & src) {
    *this = src;
}

EntityEnemy::~EntityEnemy(void) {}

EntityEnemy & EntityEnemy::operator=(EntityEnemy const & rhs) {
    (void) rhs;
    return *this;
}

void EntityEnemy::tick(const int & max_width, const int & max_height) {
    this->_algo_time++;
    (void) max_width;
    (void) max_height;

    if (this->_algo == 0) {// Homing missile
        int dx   = this->_algo_target->get_x() - this->_x;
        int dy   = this->_algo_target->get_y() - this->_y;
        int dist = std::sqrt(dx * dx + dy * dy);

        if (dist > 0.25) {
            this->_x += dx * 0.25 / dist;
            this->_y += dy * 0.25 / dist;
        }
        else {
            this->_x = this->_algo_target->get_x();
            this->_y = this->_algo_target->get_y();
        }
    }
    if (this->_algo == 1) {// Flies randomly in a straight line
        int dx   = -3 - this->_x;
        int dy   = this->_algo_destination - this->_y;
        int dist = std::sqrt(dx * dx + dy * dy);

        this->_x += dx * 0.25 / dist;
        this->_y += dy * 0.25 / dist;
    }
    if (this->_algo == 2) {// fast
        this->_x--;
    }
}

bool EntityEnemy::is_enemy(void) {return true;}
