/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   EntityManager.class.hpp                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nterrier <nterrier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 17:33:38 by nterrier          #+#    #+#             */
/*   Updated: 2018/10/07 21:08:32 by nterrier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ENTITYMANAGER_CLASS_HPP
#define ENTITYMANAGER_CLASS_HPP

#include <iostream>
#include "EntityManagerList.class.hpp"
#include "WindowManager.class.hpp"
#include "EntityPlayer.class.hpp"
#include "EntityEnemy.class.hpp"
#include "EntityBullet.class.hpp"
#include "EntityObstacle.class.hpp"

class EntityManager {
    public:
        EntityManager(void);
        virtual ~EntityManager(void);

        void filter(const int & max_width, const int & max_height);
        void tick(const int & max_width, const int & max_height);
        void print(WindowManager * wm);
        void collisions(void);

        void addAlly(GameEntity * ge);
        void addEnemy(GameEntity * ge);
        void addObstacle(GameEntity * ge);
        void addStar(GameEntity * ge);

    private:
        EntityManager(const EntityManager & src);
        EntityManager & operator=(const EntityManager & rhs);

        EntityManagerList * _allies;
        EntityManagerList * _enemies;
        EntityManagerList * _obstacles;
        EntityManagerList * _stars;
};


#endif // ifndef ENTITYMANAGER_CLASS_HPP
