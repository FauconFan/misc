/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Game.class.hpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 09:45:36 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/07 20:14:24 by nterrier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GAME_CLASS_HPP
#define GAME_CLASS_HPP

#include "constants.hpp"
#include "WindowManager.class.hpp"
#include "GameEntity.class.hpp"
#include "EntityPlayer.class.hpp"
#include "EntityEnemy.class.hpp"
#include "EntityBullet.class.hpp"
#include "EntityObstacle.class.hpp"
#include "EntityManager.class.hpp"

class Game {
    public:
        Game(void);
        virtual ~Game(void);

        void start();

    private:
        Game(const Game & cpy);
        Game & operator=(const Game & rhs);

        void                do_action(int input, EntityPlayer * ep);
        void                new_stage(GameEntity * player);

        static bool is_instanciated;
        bool is_running;
        int _score;
        int _starting_time;
        int _time;
        std::string _stage_name;

        WindowManager * _window_manager;
        EntityManager * _entity_manager;
};

#endif // ifndef GAME_CLASS_HPP
