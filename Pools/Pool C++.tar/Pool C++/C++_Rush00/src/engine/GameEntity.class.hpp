/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   GameEntity.class.hpp                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 09:59:30 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/07 21:27:32 by nterrier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GAMEENTITY_CLASS_HPP
#define GAMEENTITY_CLASS_HPP

#include <iostream>

class GameEntity {
    public:
        virtual ~GameEntity(void);

        int             get_x(void) const;
        int             get_y(void) const;
        char            get_c(void) const;
        int             get_lives(void) const;
        int             get_livesMax(void) const;

        virtual void    damage(GameEntity * target);
        void            getDamaged(int amount);
        virtual bool    is_enemy(void) = 0;
        virtual void    tick(const int & max_width, const int & max_height) = 0;

    protected:
        GameEntity(void) {};
        GameEntity(float x, float y, char c);
        GameEntity(const GameEntity & src);
        GameEntity & operator=(const GameEntity & rhs);

        float _x;
        float _y;
        char _c;
        int _lives;
        int _livesMax;
        int _damage;
};

#endif // ifndef GAMEENTITY_CLASS_HPP
