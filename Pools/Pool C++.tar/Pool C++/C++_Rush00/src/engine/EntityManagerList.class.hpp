/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   EntityManagerList.class.hpp                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nterrier <nterrier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 17:38:44 by nterrier          #+#    #+#             */
/*   Updated: 2018/10/07 21:23:59 by nterrier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ENTITYMANAGERLIST_CLASS_HPP
#define ENTITYMANAGERLIST_CLASS_HPP

#include <iostream>
#include "GameEntity.class.hpp"
#include "WindowManager.class.hpp"

class EntityManagerList {
    public:
        EntityManagerList(GameEntity * elem);
        EntityManagerList(GameEntity * elem, EntityManagerList * next);
        virtual ~EntityManagerList(void);

        void tick(const int & max_width, const int & max_height);
        void print(WindowManager * wm);
        void collision(EntityManagerList * other);
        void collisions(EntityManagerList * other);

        static EntityManagerList * filter(EntityManagerList * eml, const int & max_width,
            const int & max_height);
    private:
        EntityManagerList(void) {};
        EntityManagerList & operator=(const EntityManagerList &);
        EntityManagerList(const EntityManagerList &);

        GameEntity * _elem;
        EntityManagerList * _next;
};

#endif // ifndef ENTITYMANAGERLIST_CLASS_HPP
