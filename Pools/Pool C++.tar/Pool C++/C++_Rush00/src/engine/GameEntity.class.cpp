/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   GameEntity.class.cpp                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 10:00:14 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/07 05:11:21 by nterrier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "GameEntity.class.hpp"

GameEntity::GameEntity(float x, float y, char c)
    : _x(x), _y(y), _c(c), _lives(1), _livesMax(1), _damage(1) {}

GameEntity::GameEntity(const GameEntity & src) {
    *this = src;
}

GameEntity::~GameEntity(void) {}

GameEntity & GameEntity::operator=(GameEntity const & rhs) {
    this->_x = rhs._x;
    this->_y = rhs._y;
    this->_c = rhs._c;
    return *this;
}

int GameEntity::get_x(void) const {
    return this->_x;
}

int GameEntity::get_y(void) const {
    return this->_y;
}

char GameEntity::get_c(void) const {
    return this->_c;
}

int GameEntity::get_lives(void) const {
    return this->_lives;
}

int GameEntity::get_livesMax(void) const {
    return this->_livesMax;
}

void GameEntity::damage(GameEntity * target) {
    target->getDamaged(this->_damage);
}

void GameEntity::getDamaged(int amount) {
    this->_lives -= amount;
    if (this->_lives > this->_livesMax)
        this->_lives = this->_livesMax;
}
