/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   EntityManager.class.cpp                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nterrier <nterrier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 17:32:38 by nterrier          #+#    #+#             */
/*   Updated: 2018/10/07 21:24:53 by nterrier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "EntityManager.class.hpp"

EntityManager::EntityManager(void) : _allies(NULL), _enemies(NULL), _obstacles(NULL),
    _stars(NULL) {}

EntityManager::EntityManager(const EntityManager & src) {*this = src;} // SNH

EntityManager & EntityManager::operator=(EntityManager const & rhs) {(void) rhs; return *this;} // SNH

EntityManager::~EntityManager(void) {
    if (this->_allies)
        delete this->_allies;
    if (this->_enemies)
        delete this->_enemies;
    if (this->_obstacles)
        delete this->_obstacles;
    if (this->_stars)
        delete this->_stars;
}

void EntityManager::filter(const int & max_width, const int & max_height) {
    this->_allies    = EntityManagerList::filter(this->_allies, max_width, max_height);
    this->_enemies   = EntityManagerList::filter(this->_enemies, max_width, max_height);
    this->_obstacles = EntityManagerList::filter(this->_obstacles, max_width, max_height);
    this->_stars     = EntityManagerList::filter(this->_stars, max_width, max_height);
}

void EntityManager::tick(const int & max_width, const int & max_height) {
    if (this->_allies)
        this->_allies->tick(max_width, max_height);
    if (this->_enemies)
        this->_enemies->tick(max_width, max_height);
    if (this->_obstacles)
        this->_obstacles->tick(max_width, max_height);
    if (this->_stars)
        this->_stars->tick(max_width, max_height);
}

void EntityManager::print(WindowManager * wm) {
    attron(COLOR_PAIR(GRAY_PAIR));
    if (this->_stars)
        this->_stars->print(wm);
    attroff(COLOR_PAIR(COLOR_GRAY));
    if (this->_obstacles)
        this->_obstacles->print(wm);
    if (this->_enemies)
        this->_enemies->print(wm);
    if (this->_allies)
        this->_allies->print(wm);
}

void EntityManager::addAlly(GameEntity * ge) {
    this->_allies = new EntityManagerList(ge, this->_allies);
}

void EntityManager::addEnemy(GameEntity * ge) {
    this->_enemies = new EntityManagerList(ge, this->_enemies);
}

void EntityManager::addObstacle(GameEntity * ge) {
    this->_obstacles = new EntityManagerList(ge, this->_obstacles);
}

void EntityManager::addStar(GameEntity * ge) {
    this->_stars = new EntityManagerList(ge, this->_stars);
}

void EntityManager::collisions(void) {
    if (this->_allies && this->_enemies)
        this->_allies->collisions(this->_enemies);
    if (this->_allies && this->_obstacles)
        this->_allies->collisions(this->_obstacles);
    if (this->_enemies && this->_obstacles)
        this->_enemies->collisions(this->_obstacles);
}
