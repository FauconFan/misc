/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   EntityManagerList.class.cpp                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nterrier <nterrier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 17:36:05 by nterrier          #+#    #+#             */
/*   Updated: 2018/10/07 21:24:20 by nterrier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "EntityManagerList.class.hpp"

EntityManagerList::EntityManagerList(GameEntity * elem) : _elem(elem), _next(NULL) {}

EntityManagerList::EntityManagerList(GameEntity * elem, EntityManagerList * next) : _elem(elem),
    _next(next) {}

EntityManagerList::EntityManagerList(const EntityManagerList & eml) {*this = eml;}// SNH

EntityManagerList & EntityManagerList::operator=(const EntityManagerList & elem) {
    (void) elem;
    return (*this);
}                                                                                                            // SNH

EntityManagerList::~EntityManagerList(void) {
    if (this->_next != NULL)
        delete this->_next;
    delete this->_elem;
}

EntityManagerList * EntityManagerList::filter(EntityManagerList * eml, const int & max_width,
  const int & max_height) {
    EntityManagerList * res;

    if (eml == NULL)
        return (NULL);

    if (eml->_elem->get_x() < 0 || eml->_elem->get_x() > max_width ||
      eml->_elem->get_y() < 0 || eml->_elem->get_y() > max_height ||
      eml->_elem->get_lives() <= 0)
    {
        res        = filter(eml->_next, max_width, max_height);
        eml->_next = NULL;
        delete eml;
        return res;
    }
    eml->_next = filter(eml->_next, max_width, max_height);
    return (eml);
}

void EntityManagerList::tick(const int & max_width, const int & max_height) {
    this->_elem->tick(max_width, max_height);
    if (this->_next)
        this->_next->tick(max_width, max_height);
}

void EntityManagerList::print(WindowManager * wm) {
    wm->put_game_entity(*(this->_elem));
    if (this->_next != NULL)
        this->_next->print(wm);
}

void EntityManagerList::collisions(EntityManagerList * other) {
    this->collision(other);
    if (this->_next != NULL)
        this->_next->collisions(other);
}

void EntityManagerList::collision(EntityManagerList * other) {
    if (this->_elem->get_x() == other->_elem->get_x() &&
      this->_elem->get_y() == other->_elem->get_y())
    {
        this->_elem->damage(other->_elem);
        other->_elem->damage(this->_elem);
    }
    if (other->_next != NULL)
        this->collision(other->_next);
}
