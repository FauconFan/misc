/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   WindowManager.class.cpp                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 10:11:27 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/12 20:30:17 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "WindowManager.class.hpp"

bool WindowManager::is_instanciated = false;

WindowManager::WindowManager(void) {
    if (is_instanciated)
        std::cerr << "This should never happened" << '\n';
    is_instanciated = true;
    initscr();             // Start ncurses mode
    noecho();              //  To disable the buffering of typed characters by the TTY driver and get a character-at-a-time input
    cbreak();              // To suppress the automatic echoing of typed characters
    nodelay(stdscr, TRUE); // To not interrupt program if no keys is pressed.
    curs_set(0);           // To hide the cursor
    keypad(stdscr, TRUE);  // In order to capture special keystrokes like Backspace, Delete and the four arrow keys by getch()
    start_color();
    init_pair(WHITE_PAIR, COLOR_WHITE, COLOR_BLACK);
    init_pair(GREEN_PAIR, COLOR_GREEN, COLOR_BLACK);
    init_pair(RED_PAIR, COLOR_RED, COLOR_BLACK);
    // if (can_change_color()) {
    init_color(COLOR_GRAY, 200, 200, 200);
    init_pair(GRAY_PAIR, COLOR_GRAY, COLOR_BLACK);
    init_pair(MENU_BASIC, COLOR_WHITE, COLOR_GRAY);
    init_pair(MENU_LIFES, COLOR_RED, COLOR_GRAY);
    init_pair(MENU_SCORE, COLOR_GREEN, COLOR_GRAY);
    // }
    getmaxyx(stdscr, this->height_win, this->width_win);
}

WindowManager::WindowManager(const WindowManager & cpy) {
    std::cerr << "This should never happened" << '\n';

    *this = cpy;
}

WindowManager::~WindowManager(void) {
    if (is_instanciated == false)
        std::cerr << "This should never happened" << '\n';
    is_instanciated = false;
    endwin(); // End curses mode
}

WindowManager & WindowManager::operator=(const WindowManager & cpy) {
    std::cerr << "This should never happened" << '\n';

    (void) cpy;
    return (*this);
}

int WindowManager::get_max_width() {
    return this->width_win - 2;
}

int WindowManager::get_max_height() {
    return this->height_win - 4;
}

void WindowManager::put_game_entity(const GameEntity & ent) {
    this->put_xychar(ent.get_x(), ent.get_y(), ent.get_c());
}

void WindowManager::put_xychar(int x, int y, char c) {
    if (x >= 0 && x < this->get_max_width() && y >= 0 && y < this->get_max_height()) {
        mvaddch(y + 3, x + 1, c);
    }
}

void WindowManager::begin(int lives, int lives_max, int score, int clocks) {
    clear();

    attron(COLOR_PAIR(MENU_BASIC));
    mvhline(0, 0, ' ', this->get_max_width() + 1);
    mvhline(1, 0, ' ', this->get_max_width() + 1);
    mvhline(2, 0, ' ', this->get_max_width() + 1);
    mvvline(0, 0, ' ', this->get_max_height() + 3);
    mvvline(0, this->get_max_width() + 1, ' ', this->get_max_height() + 4);
    mvhline(this->get_max_height() + 3, 0, ' ', this->get_max_width() + 2);
    mvprintw(1, 23, "Lives");
    mvprintw(1, this->get_max_width() - 12, "Time : %02d:%02d", clocks / CLOCKS_PER_SEC / 60,
      (clocks / CLOCKS_PER_SEC) % 60);

    int life = 0;
    mvaddch(1, 30 + life++, '[');
    attron(COLOR_PAIR(MENU_LIFES));
    while (life <= lives)
        mvaddch(1, 30 + life++, ACS_DIAMOND);
    attron(COLOR_PAIR(MENU_BASIC));
    while (life <= lives_max)
        mvaddch(1, 30 + life++, ACS_BULLET);
    mvaddch(1, 30 + life, ']');

    attron(COLOR_PAIR(MENU_SCORE));
    mvprintw(1, 5, "Score : %d", score);
    attroff(COLOR_PAIR(MENU_SCORE));
}

void WindowManager::end(void) {
    refresh();
}

int WindowManager::input(void) {
    return (getch());
}

void WindowManager::gameover(int score, int clocks) {
    clear();

    attron(COLOR_PAIR(MENU_BASIC));
    mvhline(4, 10, ' ', this->get_max_width() - 18);
    mvhline(5, 10, ' ', this->get_max_width() - 18);
    mvhline(6, 10, ' ', this->get_max_width() - 18);
    mvhline(7, 10, ' ', this->get_max_width() - 18);
    mvhline(8, 10, ' ', this->get_max_width() - 18);
    mvhline(9, 10, ' ', this->get_max_width() - 18);
    mvhline(10, 10, ' ', this->get_max_width() - 18);
    mvprintw(5, this->get_max_width() / 2.0 - 9, "The game is over !");
    attron(COLOR_PAIR(MENU_SCORE));
    mvprintw(6, this->get_max_width() / 2.0 - 16, "Well done, you scored %d points", score);
    attron(COLOR_PAIR(MENU_BASIC));
    mvprintw(7, this->get_max_width() / 2.0 - 4, "in %02d:%02d !", clocks / CLOCKS_PER_SEC / 60,
      (clocks / CLOCKS_PER_SEC) % 60);
    mvprintw(9, this->get_max_width() / 2.0 - 12, "Press any key to end ...");

    nodelay(stdscr, FALSE);
    getch();
}
