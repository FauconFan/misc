/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Game.class.cpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 09:45:37 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/07 23:21:51 by nterrier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <ctime>
#include "Game.class.hpp"

bool Game::is_instanciated = false;

Game::Game(void) : is_running(true), _score(0) {
    if (is_instanciated)
        std::cerr << "This should never happened" << '\n';
    is_instanciated       = true;
    this->_entity_manager = new EntityManager();
    this->_window_manager = new WindowManager();
}

Game::Game(const Game & cpy) {*this = cpy;} // SNH

Game & Game::operator=(const Game & cpy) {(void) cpy; return (*this);} // SNH

/*
**	The player is freed in the entity manager
*/
Game::~Game(void) {
    if (is_instanciated == false)
        std::cerr << "This should never happened" << '\n';
    is_instanciated = false;
    delete this->_entity_manager;
    delete this->_window_manager;
}

void Game::start(void) {
    EntityPlayer * player;
    clock_t next_update;
    char stars_c[3]   = {'.', '*', ACS_BULLET};
    char enemies_c[5] = {'<', '@', '#', '!', '+'};
    int input;
    int enemy_frequency = ENEMY_FREQ;

    player = new EntityPlayer(5, this->_window_manager->get_max_height() / 2.0, '>');
    this->_entity_manager->addAlly(player);

    this->new_stage(player);
    while (this->is_running) {
        next_update = clock() + (CLOCKS_PER_SEC / FPS);
        while (clock() < next_update) {
            input = this->_window_manager->input();
            if (input != ERR)
                this->do_action(input, player);
        }
        if (!(rand() % STAR_FREQ)) {// creates a star
            this->_entity_manager->addStar(new EntityObstacle(this->_window_manager->get_max_width(),
                    rand() % this->_window_manager->get_max_height(), stars_c[rand() % 3],
                    (float) (rand() % 10) * (-0.1) - 0.5, 0));
        }
        if (!(rand() % enemy_frequency)) {// creates a Enemy
            this->_entity_manager->addEnemy(new EntityEnemy(this->_window_manager->get_max_width(),
                    rand() % this->_window_manager->get_max_height(), enemies_c[rand() % 5],
                    rand() % 3,
                    rand() % this->_window_manager->get_max_height(), player));
        }
        this->_time = clock();
        this->_score++;
        this->_window_manager->begin(player->get_lives(),
          player->get_livesMax(), this->_score, this->_time - this->_starting_time);
        this->_entity_manager->tick(
          this->_window_manager->get_max_width(), this->_window_manager->get_max_height());
        this->_entity_manager->collisions();
        if (player->get_lives() <= 0) {this->is_running = false; break;}
        this->_entity_manager->filter(
          this->_window_manager->get_max_width(), this->_window_manager->get_max_height());
        this->_entity_manager->print(this->_window_manager);

        this->_window_manager->end();
    }
    this->_window_manager->gameover(this->_score, this->_time - this->_starting_time);
} // Game::start

void Game::do_action(int input, EntityPlayer * ep) {
    GameEntity * ge;

    if (input == 27) {
        this->is_running = false;
    }
    else if (input == KEY_DOWN) {
        ep->move(0, 1);
    }
    else if (input == KEY_UP) {
        ep->move(0, -1);
    }
    else if (input == KEY_LEFT) {
        ep->move(-1, 0);
    }
    else if (input == KEY_RIGHT) {
        ep->move(1, 0);
    }
    else if (input == ' ') { // Shooting
        ge = ep->shoot();
        if (ge != NULL)
            this->_entity_manager->addAlly(ge);
    }
}

void Game::new_stage(GameEntity * player) {
    int max_x = this->_window_manager->get_max_width() - 4;
    int max_y = this->_window_manager->get_max_height() - 4;

    (void) player;
    (void) max_x;
    (void) max_y;
    this->_starting_time = clock();
    this->_entity_manager->addStar(new EntityObstacle(1, max_y / 2.0 - 1, '\\', -0.01, 0));
    this->_entity_manager->addStar(new EntityObstacle(2, max_y / 2.0 + 0, '\\', -0.01, 0));
    this->_entity_manager->addStar(new EntityObstacle(3, max_y / 2.0 + 1, '|', -0.01, 0));
    this->_entity_manager->addStar(new EntityObstacle(3, max_y / 2.0 + 2, '|', -0.01, 0));
    this->_entity_manager->addStar(new EntityObstacle(3, max_y / 2.0 + 3, '|', -0.01, 0));
    this->_entity_manager->addStar(new EntityObstacle(2, max_y / 2.0 + 4, '/', -0.01, 0));
    this->_entity_manager->addStar(new EntityObstacle(1, max_y / 2.0 + 5, '/', -0.01, 0));
    // this->_entity_manager->addEnemy(new EntityEnemy(max_x,max_y/2.0,'~',2, max_y/2.0, player));
    // this->_entity_manager->addObstacle(new EntityObstacle(max_x,max_y,'*',-0.5, 0.2));//meteor
}
