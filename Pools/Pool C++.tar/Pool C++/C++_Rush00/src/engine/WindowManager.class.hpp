/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   WindowManager.class.hpp                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 10:08:49 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/07 20:37:49 by nterrier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef WINDOWMANAGER_CLASS_HPP
#define WINDOWMANAGER_CLASS_HPP

#include <ncurses.h>
#include "GameEntity.class.hpp"
#include "EntityPlayer.class.hpp"

class WindowManager {
    public:
        WindowManager(void);
        virtual ~WindowManager(void);

        int get_max_width();
        int get_max_height();

        void put_game_entity(const GameEntity & ent);
        void put_xychar(int x, int y, char c);
        void begin(int lives, int lives_max, int score, int clocks);
        void end();
        void gameover(int score, int clocks);
        int input();

    private:
        WindowManager(const WindowManager & cpy);
        WindowManager & operator=(const WindowManager & rhs);

        static bool is_instanciated;
        int height_win;
        int width_win;
};

#endif // ifndef WINDOWMANAGER_CLASS_HPP
