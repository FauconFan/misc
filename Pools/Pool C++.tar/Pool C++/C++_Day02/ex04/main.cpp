/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/28 23:21:03 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/29 09:45:28 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <string>
#include <sstream>
#include "utils.hpp"
#include "Fixed.class.hpp"
#include "Eval.class.hpp"

int main(int argc, char * argv[]) {
    if (argc <= 1) {
        std::cout << "You need to give one parameter" << std::endl;
    }
    else {
        for (int i = 1; i < argc; i++) {
            std::string actu(argv[i]);
            bool acceptFirstParse = true;

            try {
                actu = adapt_string(actu);
            } catch (std::string msg) {
                std::cout << msg << std::endl;
                acceptFirstParse = false;
            }

            if (acceptFirstParse) {
                std::istringstream iss(actu);
                Eval eval(iss);
                Fixed res;

                try {
                    res = eval.EvalExpr();
                    if (argc > 2) {
                        std::cout << argv[i] << " : ";
                    }
                    std::cout << res << std::endl;
                } catch (const char * msg) {
                    std::cout << msg << std::endl;
                }
            }
        }
    }
    return 0;
} // main
