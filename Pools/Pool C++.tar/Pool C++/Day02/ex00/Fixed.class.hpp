/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fixed.class.hpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/26 11:39:59 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/26 12:48:43 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FIXED_CLASS_HPP
#define FIXED_CLASS_HPP

#include <fstream>

class Fixed {
    public:
        Fixed ();
        Fixed (Fixed const &);
        virtual ~Fixed ();

        Fixed &operator=(Fixed const &);

        int getRawBits(void) const;
        void setRawBits(int const raw);
    private:
        int _rawBits;

        static int _nBits;
};

#endif // ifndef FIXED_CLASS_HPP
