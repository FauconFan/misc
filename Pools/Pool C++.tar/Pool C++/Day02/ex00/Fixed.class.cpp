/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fixed.class.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/26 12:09:04 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/26 12:57:54 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <fstream>
#include "Fixed.class.hpp"

Fixed::Fixed() : _rawBits(0) {
    std::cout << "Default constructor called" << '\n';
}

Fixed::Fixed (Fixed const & copy) {
    std::cout << "Copy constructor called" << '\n';
    *this = copy;
}

Fixed::~Fixed () {
    std::cout << "Destructor called" << '\n';
}

Fixed &Fixed::operator=(Fixed const & copy) {
    std::cout << "Assignation operator called" << '\n';
    this->_rawBits = copy.getRawBits();

    return *this;
}

int Fixed::getRawBits(void) const {
    std::cout << "getRawBits member function called" << '\n';
    return this->_rawBits;
}

void Fixed::setRawBits(int const raw) {
    std::cout << "setRawBits member function called" << '\n';
    this->_rawBits = raw;
}

int Fixed::_nBits = 8;
