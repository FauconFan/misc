/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/28 23:26:53 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/29 09:42:23 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <string>
#include "Fixed.class.hpp"

bool is_operand(char &c) {
    return (c == '+' || c == '-' || c == '*' || c == '/' ||
           c == '(' || c == ')' || c == '{' || c == '}');
}

bool is_number(char &c) {
    return (c >= '0' && c <= '9');
}

bool is_whitespace(char &c) {
    return (c == ' ' || c == '\n' || c == '\t' ||
           c == '\r' || c == '\v' || c == '\f');
}

std::string adapt_string(std::string entry) {
    std::string res;

    for (auto it = entry.begin(); it != entry.end(); ++it) {
        if (is_operand(*it)) {
            res += *it;
            res += " ";
        }
        else if (is_number(*it)) {
            while (is_number(*it) && it != entry.end()) {
                res += *it;
                ++it;
            }
            if (it == entry.end())
                break;
            if (*it == '.') {
                res += ".";
                ++it;
                if (it == entry.end())
                    break;
                while (is_number(*it) && it != entry.end()) {
                    res += *it;
                    ++it;
                }
            }
            --it;
            res += " ";
        }
        else if (is_whitespace(*it) == false) {
            throw "Unexpected character, in " + entry;
        }
    }
    return res;
} // adapt_string

Fixed toFixed(std::string entry) {
    float actu = 0;
    auto it    = entry.begin();

    if (entry == "")
        throw "Missing number";
    while (is_number(*it)) {
        actu = actu * 10 + *it - '0';
        ++it;
    }
    if (*it == '.') {
        ++it;
        float tenpower = 1;
        while (is_number(*it)) {
            tenpower /= 10.0f;
            actu      = actu + (*it - '0') * tenpower;
            ++it;
        }
    }
    if (it != entry.end()) {
        throw "Unexpected character, in " + entry;
    }
    return Fixed(actu);
}
