/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Eval.class.hpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/29 08:45:21 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/29 09:47:37 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef EVAL_CLASS_HPP
#define EVAL_CLASS_HPP

#include <sstream>
#include <string>
#include "Fixed.class.hpp"

#define NO_ERROR ""
#define PARENTHESIS "Parentheses don't match"
#define WRONG_CHAR "Invalid character"
#define DIVIDE_BY_ZERO "Cannot divide by zero"

#define MINUS "-"
#define PLUS "+"
#define MULT "*"
#define DIVI "/"
#define LPAR "("
#define RPAR ")"

class Eval {
    public:
        Eval (std::istringstream &iss);
        virtual ~Eval ();

        Fixed EvalExpr();
    private:
        std::istringstream &_iss;
        int _paren_count;
        std::string _actu;

        std::string getNext();

        bool eat(std::string food);
        void eatFail(std::string food, const char * errMsg);
        void forceFailIfEat(std::string food);

        Fixed ParseSummands();
        Fixed ParseFactors();
        Fixed ParseAtom();
};

#endif
