/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fixed.class.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/26 12:09:04 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/27 18:58:43 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <cmath>
#include <iostream>
#include <fstream>
#include "Fixed.class.hpp"

int Fixed::_nBits = 8;

Fixed::Fixed() : _rawBits(0) {}

Fixed::Fixed(int value) {
    this->_rawBits = value << Fixed::_nBits;
}

Fixed::Fixed(float value) {
    this->_rawBits = (int)roundf(value * (1 << Fixed::_nBits));
}

Fixed::Fixed (Fixed const & copy) {
    *this = copy;
}

Fixed::~Fixed () {}

Fixed &Fixed::operator=(Fixed const & copy) {
    this->_rawBits = copy.getRawBits();

    return *this;
}

bool Fixed::operator==(Fixed const &oth) {
    return this->_rawBits == oth.getRawBits();
}

bool Fixed::operator!=(Fixed const &oth) {
    return this->_rawBits != oth.getRawBits();
}

bool Fixed::operator<(Fixed const &oth) {
    return this->_rawBits < oth.getRawBits();
}

bool Fixed::operator<=(Fixed const &oth) {
    return this->_rawBits <= oth.getRawBits();
}

bool Fixed::operator>(Fixed const &oth) {
    return this->_rawBits > oth.getRawBits();
}

bool Fixed::operator>=(Fixed const &oth) {
    return this->_rawBits >= oth.getRawBits();
}

Fixed Fixed::operator+(Fixed const &oth) const {
    Fixed res;

    res.setRawBits(this->getRawBits() + oth.getRawBits());
    return (res);
}

Fixed Fixed::operator-(Fixed const &oth) const {
    Fixed res;

    res.setRawBits(this->getRawBits() - oth.getRawBits());
    return (res);
}

Fixed Fixed::operator*(Fixed const &oth) const {
    return Fixed(this->toFloat() * oth.toFloat());
}

Fixed Fixed::operator/(Fixed const &oth) const {
    return Fixed(this->toFloat() / oth.toFloat());
}

Fixed & Fixed::operator++() {
    this->_rawBits++;
    return *this;
}

Fixed Fixed::operator++(int) {
    Fixed res(*this);
    ++(*this);

    return res;
}

Fixed & Fixed::operator--() {
    this->_rawBits--;
    return *this;
}

Fixed Fixed::operator--(int) {
    Fixed res(*this);
    --(*this);

    return res;
}

int Fixed::getRawBits(void) const {
    return this->_rawBits;
}

void Fixed::setRawBits(int const raw) {
    this->_rawBits = raw;
}

float Fixed::toFloat(void) const {
    return (float)(this->_rawBits) / (1 << Fixed::_nBits);
}

int Fixed::toInt(void) const {
    return this->_rawBits >> Fixed::_nBits;
}

Fixed &Fixed::max(Fixed & a, Fixed & b) {
    return (a.getRawBits() < b.getRawBits()) ? b : a;
}

Fixed &Fixed::min(Fixed & a, Fixed & b) {
    return (a.getRawBits() < b.getRawBits()) ? a : b;
}

Fixed const &Fixed::max(Fixed const & a, Fixed const & b) {
    return (a.getRawBits() < b.getRawBits()) ? b : a;
}

Fixed const &Fixed::min(Fixed const & a, Fixed const & b) {
    return (a.getRawBits() < b.getRawBits()) ? a : b;
}

std::ostream &operator<<(std::ostream &os, Fixed const &f) {
    return os << f.toFloat();
}
