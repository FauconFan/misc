/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Eval.class.cpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/29 08:49:49 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/29 09:47:24 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <sstream>
#include <string>
#include <iostream>
#include "utils.hpp"
#include "Fixed.class.hpp"
#include "Eval.class.hpp"

Eval::Eval(std::istringstream &iss)
        : _iss(iss), _paren_count(0), _actu("") {}

Eval::~Eval() {}

std::string Eval::getNext() {
    if (this->_actu == "") {
        this->_iss >> this->_actu;
    }
    std::string res;

    res = this->_actu;
    this->_actu = "";
    return res;
}

bool Eval::eat(std::string food) {
    std::string next;

    next = this->getNext();
    if (next == food) {
        return true;
    }
    this->_actu = next;
    return false;
}

void Eval::eatFail(std::string food, const char * errMsg) {
    bool res;

    res = this->eat(food);
    if (res == false)
        throw errMsg;
}

void Eval::forceFailIfEat(std::string food) {
    bool res;

    res = this->eat(food);
    if (res)
        throw WRONG_CHAR;
}

Fixed Eval::EvalExpr() {
    Fixed res;
    std::string tmp;

    res = this->ParseSummands();
    if (this->_paren_count != 0)
        throw PARENTHESIS;
    // Check if end;
    this->_iss >> tmp;
    if (this->_iss.good())
        throw WRONG_CHAR;
    return res;
}

Fixed Eval::ParseSummands() {
    Fixed res;
    Fixed resTmp;
    bool plus_operation;

    res = this->ParseFactors();
    while (true) {
        plus_operation = this->eat(PLUS);
        if (plus_operation == false) {
            if (this->eat(MINUS) == false)
                return res;
        }
        resTmp = this->ParseFactors();
        if (plus_operation)
            res = res + resTmp;
        else
            res = res - resTmp;
    }
}

Fixed Eval::ParseFactors() {
    Fixed res;
    Fixed resTmp;
    bool mult_operation;

    res = this->ParseAtom();
    while (true) {
        mult_operation = this->eat(MULT);
        if (mult_operation == false) {
            if (this->eat(DIVI) == false)
                return res;
        }
        resTmp = this->ParseAtom();
        if (mult_operation)
            res = res * resTmp;
        else if (resTmp == Fixed(0))
            throw DIVIDE_BY_ZERO;
        else
            res = res / resTmp;
    }
}

Fixed Eval::ParseAtom() {
    Fixed res;
    Fixed inside;
    bool positive = true;

    while(this->eat(PLUS));
    while (this->eat(MINUS))
    {
        positive = !positive;
        while (this->eat(PLUS));
    }
    this->forceFailIfEat(MULT);
    this->forceFailIfEat(DIVI);
    this->forceFailIfEat(RPAR);

    if (this->eat(LPAR)) {
        this->_paren_count++;
        inside = this->ParseSummands();
        this->eatFail(RPAR, PARENTHESIS);
        this->_paren_count--;
        return positive ? inside : inside * (-1);
    }

    res = toFixed(this->getNext());
    return positive ? res : res * (-1);
}
