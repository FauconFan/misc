/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fixed.class.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/26 12:09:04 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/27 11:07:43 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <cmath>
#include <iostream>
#include <fstream>
#include "Fixed.class.hpp"

Fixed::Fixed() : _rawBits(0) {
    std::cout << "Default constructor called" << '\n';
}

Fixed::Fixed(int value) {
    std::cout << "int constructor called" << '\n';
    this->_rawBits = value << Fixed::_nBits;
}

Fixed::Fixed(float value) {
    std::cout << "float constructor called" << '\n';
    this->_rawBits = (int)roundf(value * (1 << Fixed::_nBits));
}

Fixed::Fixed (Fixed const & copy) {
    std::cout << "Copy constructor called" << '\n';
    *this = copy;
}

Fixed::~Fixed () {
    std::cout << "Destructor called" << '\n';
}

Fixed &Fixed::operator=(Fixed const & copy) {
    std::cout << "Assignation operator called" << '\n';
    this->_rawBits = copy.getRawBits();

    return *this;
}

int Fixed::getRawBits(void) const {
    return this->_rawBits;
}

void Fixed::setRawBits(int const raw) {
    this->_rawBits = raw;
}

float Fixed::toFloat(void) const {
    return (float)(this->_rawBits) / (1 << Fixed::_nBits);
}

int Fixed::toInt(void) const {
    return this->_rawBits >> Fixed::_nBits;
}

int Fixed::_nBits = 8;

std::ostream &operator<<(std::ostream &os, Fixed const &f) {
    return os << f.toFloat();
}
