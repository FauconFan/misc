/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fixed.class.hpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/26 11:39:59 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/27 10:52:54 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FIXED_CLASS_HPP
#define FIXED_CLASS_HPP

#include <fstream>

class Fixed {
    public:
        Fixed ();
        Fixed (int value);
        Fixed (float value);
        Fixed (Fixed const &);
        virtual ~Fixed ();

        Fixed &operator=(Fixed const &);

        int getRawBits(void) const;
        void setRawBits(int const raw);

        float toFloat(void) const;
        int toInt(void) const;
    private:
        int _rawBits;

        static int _nBits;
};

std::ostream &operator<<(std::ostream &os, Fixed const &f);

#endif
