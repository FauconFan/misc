/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/29 20:16:48 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/29 22:57:15 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "FlagTrap.hpp"
#include "ScavTrap.hpp"

int main() {
    FlagTrap ft("Flag");
    ScavTrap st("Scav");

    ft.vaulthunter_dot_exe("Noe");
    st.challengeNewcomer();

    return 0;
}
