/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ScavTrap.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/29 19:37:03 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/29 22:52:51 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SCAVTRAP_HPP
#define SCAVTRAP_HPP

#include <string>
#include "ClapTrap.hpp"

class ScavTrap : public ClapTrap {
    public:
        ScavTrap (std::string name);
        ScavTrap (ScavTrap const &);
        virtual ~ScavTrap ();

        ScavTrap &operator=(ScavTrap const &);
        void challengeNewcomer() const;
    private:
        static unsigned int _size_list;
        static std::string _list_challenges[];
};

#endif // ifndef SCAVTRAP_HPP
