/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   FlagTrap.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/29 19:37:03 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/30 10:08:47 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FLAGTRAP_HPP
#define FLAGTRAP_HPP

#include <string>
#include "ClapTrap.hpp"

class FlagTrap : public ClapTrap {
    public:
        FlagTrap (std::string name);
        FlagTrap (FlagTrap const &);
        virtual ~FlagTrap ();

        FlagTrap &operator=(FlagTrap const &);

        unsigned int vaulthunter_dot_exe(std::string const & target) const;

        unsigned int nullAttack(std::string const & target) const;
        unsigned int onePunch(std::string const & target) const;
        unsigned int kamehameha(std::string const & target) const;
        unsigned int infernoTornade(std::string const & target) const;
        unsigned int frozenIce(std::string const & target) const;

    private:
        static unsigned int _size_list;
        static unsigned int (FlagTrap::* _attacks[])(std::string const & target) const;
};

#endif // ifndef FLAGTRAP_HPP
