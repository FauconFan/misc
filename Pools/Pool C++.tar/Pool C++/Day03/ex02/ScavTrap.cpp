/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ScavTrap.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/29 19:43:08 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/29 22:55:19 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <string>
#include "ScavTrap.hpp"

ScavTrap::ScavTrap(std::string name)
        : ClapTrap(100, 100, 50, 50, 1, name, 20, 15, 3) {
    std::cout << "ScavTrap Contructor called : " << name << std::endl;
}

ScavTrap::ScavTrap(ScavTrap const & copy)
        : ClapTrap(copy) {
    std::cout << "ScavTrap Copy Constructor called." << std::endl;
    *this = copy;
}

ScavTrap::~ScavTrap() {
    std::cout << "ScavTrap Destructor called." << std::endl;
}

ScavTrap &ScavTrap::operator=(ScavTrap const & copy) {
    this->_hitPoints = copy._hitPoints;
    this->_maxHitPoints = copy._maxHitPoints;
    this->_energyPoints = copy._energyPoints;
    this->_maxEnergyPoints = copy._maxEnergyPoints;
    this->_level = copy._level;
    this->_name = copy._name;
    this->_meleeAttackDamage = copy._meleeAttackDamage;
    this->_rangedAttackDamage = copy._rangedAttackDamage;
    this->_armorDamageReduction = copy._armorDamageReduction;
    std::cout << "Assignment Function called." << std::endl;
    return *this;
}

void ScavTrap::challengeNewcomer() const {
    std::cout << this->_name << " challenge you to " << this->_list_challenges[rand() % _size_list] << '\n';
}

unsigned int ScavTrap::_size_list = 5;

std::string ScavTrap::_list_challenges[] = {
    "Go on the Moon",
    "Fly over the Eiffel Tower",
    "Go in America",
    "Get the courage to kiss your girl",
    "Keep her forever"
};
