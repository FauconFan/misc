/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/29 20:16:48 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/30 00:04:17 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "FlagTrap.hpp"
#include "ScavTrap.hpp"
#include "NinjaTrap.hpp"
#include "SuperTrap.hpp"

int main() {
    SuperTrap super("Super");
    FlagTrap ft("Flag");
    ScavTrap st("Scav");
    NinjaTrap nt("Ninja");

    super.meleeAttack("Bob");
    super.rangedAttack("Jim");

    super.vaulthunter_dot_exe("Noe");

    super.ninjaShoebox(ft);
    super.ninjaShoebox(st);
    super.ninjaShoebox(nt);

    return 0;
}
