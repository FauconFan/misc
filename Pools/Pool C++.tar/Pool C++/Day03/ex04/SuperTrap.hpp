/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   SuperTrap.hpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/29 23:41:47 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/30 00:01:08 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SUPERTRAP_HPP
#define SUPERTRAP_HPP

#include <string>
#include "NinjaTrap.hpp"
#include "FlagTrap.hpp"

class SuperTrap : public NinjaTrap, public FlagTrap {
    public:
        SuperTrap (std::string name);
        SuperTrap (SuperTrap const &);
        virtual ~SuperTrap ();

        SuperTrap &operator=(SuperTrap const &);

        void meleeAttack(std::string const & target) const;
        void rangedAttack(std::string const & target) const;
};

#endif
