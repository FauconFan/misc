/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   SuperTrap.cpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/29 23:43:27 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/30 10:19:38 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "SuperTrap.hpp"

SuperTrap::SuperTrap(std::string name)
    : NinjaTrap(name), FlagTrap(name) {
    this->_hitPoints = this->FlagTrap::_hitPoints;
    this->_maxHitPoints = this->FlagTrap::_maxHitPoints;
    this->_energyPoints = this->NinjaTrap::_energyPoints;
    this->_maxEnergyPoints = this->NinjaTrap::_maxEnergyPoints;
    this->_level = 1;
    this->_name = name;
    this->_meleeAttackDamage = this->NinjaTrap::_meleeAttackDamage;
    this->_rangedAttackDamage = this->FlagTrap::_rangedAttackDamage;
    this->_armorDamageReduction = this->FlagTrap::_armorDamageReduction;
    std::cout << "SuperTrap String Constructor called." << '\n';
}

SuperTrap::SuperTrap(SuperTrap const & copy)
        : ClapTrap(copy), NinjaTrap(copy), FlagTrap(copy) {
    std::cout << "SuperTrap Copy Constructor called." << std::endl;
    *this = copy;
}

SuperTrap::~SuperTrap() {
    std::cout << "SuperTrap Destructor called." << std::endl;
}

SuperTrap &SuperTrap::operator=(SuperTrap const & copy) {
    this->_hitPoints = copy._hitPoints;
    this->_maxHitPoints = copy._maxHitPoints;
    this->_energyPoints = copy._energyPoints;
    this->_maxEnergyPoints = copy._maxEnergyPoints;
    this->_level = copy._level;
    this->_name = copy._name;
    this->_meleeAttackDamage = copy._meleeAttackDamage;
    this->_rangedAttackDamage = copy._rangedAttackDamage;
    this->_armorDamageReduction = copy._armorDamageReduction;
    std::cout << "Assignment Function called." << std::endl;
    return *this;
}

void SuperTrap::meleeAttack(std::string const & target) const {
    this->NinjaTrap::meleeAttack(target);
}

void SuperTrap::rangedAttack(std::string const & target) const {
    this->FlagTrap::rangedAttack(target);
}
