/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   FlagTrap.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/29 19:43:08 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/30 10:14:24 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <string>
#include "FlagTrap.hpp"

FlagTrap::FlagTrap(std::string name) : ClapTrap() {
    this->_hitPoints = 100;
    this->_maxHitPoints = 100;
    this->_energyPoints = 100;
    this->_maxEnergyPoints = 100;
    this->_level = 1;
    this->_name = name;
    this->_meleeAttackDamage = 30;
    this->_rangedAttackDamage = 20;
    this->_armorDamageReduction = 5;
    std::cout << "FlagTrap String Contructor called : " << name << std::endl;
}

FlagTrap::FlagTrap(FlagTrap const & copy)
        : ClapTrap(copy) {
    std::cout << "FlagTrap Copy Constructor called." << std::endl;
    *this = copy;
}

FlagTrap::~FlagTrap() {
    std::cout << "FlagTrap Destructor called." << std::endl;
}

FlagTrap &FlagTrap::operator=(FlagTrap const & copy) {
    this->_hitPoints = copy._hitPoints;
    this->_maxHitPoints = copy._maxHitPoints;
    this->_energyPoints = copy._energyPoints;
    this->_maxEnergyPoints = copy._maxEnergyPoints;
    this->_level = copy._level;
    this->_name = copy._name;
    this->_meleeAttackDamage = copy._meleeAttackDamage;
    this->_rangedAttackDamage = copy._rangedAttackDamage;
    this->_armorDamageReduction = copy._armorDamageReduction;
    std::cout << "Assignment Function called." << std::endl;
    return *this;
}

unsigned int FlagTrap::vaulthunter_dot_exe(std::string const & target) const {
    unsigned int (FlagTrap::*ptr)(std::string const &) const;

    ptr = this->_attacks[rand() % this->_size_list];
    return (this->*ptr)(target);
}

unsigned int FlagTrap::_size_list = 5;

unsigned int (FlagTrap::*FlagTrap::_attacks[])(std::string const & target) const = {
    &FlagTrap::nullAttack,
    &FlagTrap::onePunch,
    &FlagTrap::kamehameha,
    &FlagTrap::infernoTornade,
    &FlagTrap::frozenIce
};

unsigned int FlagTrap::nullAttack(std::string const & target) const {
    std::cout << "Attack Failed on " << target << std::endl;
    return 0;
}

unsigned int FlagTrap::onePunch(std::string const & target) const {
    std::cout << "One punch on " << target << std::endl;
    return 1000;
}

unsigned int FlagTrap::kamehameha(std::string const & target) const {
    std::cout << "KAMEHAMEHAAAAAAAAAAAAAA (" << target << ")" << std::endl;
    return 20;
}

unsigned int FlagTrap::infernoTornade(std::string const & target) const {
    std::cout << "Care about the INFERNO TORNADE (" << target << ")" << std::endl;
    return 40;
}

unsigned int FlagTrap::frozenIce(std::string const & target) const {
    std::cout << "The power of Ice FROZE YOU (" << target << ")" << std::endl;
    return 40;
}
