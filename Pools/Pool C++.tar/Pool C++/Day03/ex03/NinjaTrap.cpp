/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   NinjaTrap.cpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/29 23:09:21 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/29 23:21:33 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "NinjaTrap.hpp"

NinjaTrap::NinjaTrap(std::string name)
    : ClapTrap(60, 60, 120, 120, 1, name, 60, 5, 0) {
    std::cout << "NinjaTrap Contructor called : " << name << std::endl;
}

NinjaTrap::NinjaTrap(NinjaTrap const & copy)
        : ClapTrap(copy) {
    std::cout << "NinjaTrap Copy Constructor called." << std::endl;
    *this = copy;
}

NinjaTrap::~NinjaTrap() {
    std::cout << "NinjaTrap Destructor called." << std::endl;
}

NinjaTrap &NinjaTrap::operator=(NinjaTrap const & copy) {
    this->_hitPoints = copy._hitPoints;
    this->_maxHitPoints = copy._maxHitPoints;
    this->_energyPoints = copy._energyPoints;
    this->_maxEnergyPoints = copy._maxEnergyPoints;
    this->_level = copy._level;
    this->_name = copy._name;
    this->_meleeAttackDamage = copy._meleeAttackDamage;
    this->_rangedAttackDamage = copy._rangedAttackDamage;
    this->_armorDamageReduction = copy._armorDamageReduction;
    std::cout << "Assignment Function called." << std::endl;
    return *this;
}


void NinjaTrap::ninjaShoebox(FlagTrap const &) const {
    std::cout << "ATTACK ON... Oh wait... BOOM (i don't like FlagTrap...)" << std::endl;
}

void NinjaTrap::ninjaShoebox(ScavTrap const &) const {
    std::cout << "ATTACK ON... Oh wait... A ScavTrap !! So cute" << std::endl;
}

void NinjaTrap::ninjaShoebox(NinjaTrap const &) const {
    std::cout << "ATTACK ON... Oh wait... I can't attack a friend ninja :)" << std::endl;
}
