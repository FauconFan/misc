/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   NinjaTrap.hpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/29 23:07:49 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/29 23:19:24 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef NINJATRAP_HPP
#define NINJATRAP_HPP

#include <string>
#include "ClapTrap.hpp"
#include "FlagTrap.hpp"
#include "ScavTrap.hpp"

class NinjaTrap : public ClapTrap {
    public:
        NinjaTrap (std::string name);
        NinjaTrap (NinjaTrap const &);
        virtual ~NinjaTrap ();

        NinjaTrap &operator=(NinjaTrap const &);

        void ninjaShoebox(FlagTrap const &) const;
        void ninjaShoebox(ScavTrap const &) const;
        void ninjaShoebox(NinjaTrap const &) const;
};

#endif // ifndef NINJATRAP_HPP
