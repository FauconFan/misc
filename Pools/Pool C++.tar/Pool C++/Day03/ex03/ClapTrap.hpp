/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ClapTrap.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/29 22:36:52 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/30 10:09:18 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CLAPTRAP_HPP
#define CLAPTRAP_HPP

#include <string>

class ClapTrap {
    public:
        virtual ~ClapTrap ();
        ClapTrap (ClapTrap const &);

        ClapTrap &operator=(ClapTrap const &);

        void meleeAttack(std::string const & target) const;
        void rangedAttack(std::string const & target) const;
        void takeDamage(unsigned int amount);
        void beRepaired(unsigned int amount);

        std::string getName() const;
        int getHitPoints() const;
        int getEnergyPoints() const;
    protected:
        ClapTrap (
                    unsigned int hitPoints,
                    unsigned int maxHitPoints,
                    unsigned int energyPoints,
                    unsigned int maxEnergyPoints,
                    unsigned int level,
                    std::string name,
                    unsigned int meleeAttackDamage,
                    unsigned int rangedAttackDamage,
                    unsigned int armorDamageReduction
                );
        ClapTrap ();
        unsigned int _hitPoints;
        unsigned int _maxHitPoints;
        unsigned int _energyPoints;
        unsigned int _maxEnergyPoints;
        unsigned int _level;
        std::string _name;
        unsigned int _meleeAttackDamage;
        unsigned int _rangedAttackDamage;
        unsigned int _armorDamageReduction;

        void setHitPoints(unsigned int newHitPoints);
        void setEnergyPoints(unsigned int newEnergyPoints);
};

#endif
