/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ClapTrap.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/29 22:43:37 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/30 10:09:35 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <cstdlib>
#include <ctime>
#include "ClapTrap.hpp"

ClapTrap::ClapTrap ()
    : _hitPoints(0),
    _maxHitPoints(0),
    _energyPoints(0),
    _maxEnergyPoints(0),
    _level(0), _name("Unknown"),
    _meleeAttackDamage(0),
    _rangedAttackDamage(0),
    _armorDamageReduction(0) {
    std::cout << "Abstract ClapTrap Default Constructor Called" << std::endl;

    srand(time(NULL));
}

ClapTrap::ClapTrap (
  unsigned int hitPoints,
  unsigned int maxHitPoints,
  unsigned int energyPoints,
  unsigned int maxEnergyPoints,
  unsigned int level,
  std::string  name,
  unsigned int meleeAttackDamage,
  unsigned int rangedAttackDamage,
  unsigned int armorDamageReduction)
    : _hitPoints(hitPoints),
    _maxHitPoints(maxHitPoints),
    _energyPoints(energyPoints),
    _maxEnergyPoints(maxEnergyPoints),
    _level(level), _name(name),
    _meleeAttackDamage(meleeAttackDamage),
    _rangedAttackDamage(rangedAttackDamage),
    _armorDamageReduction(armorDamageReduction) {
    std::cout << "Abstract ClapTrap Constructor Called" << std::endl;

    srand(time(NULL));
}

ClapTrap::ClapTrap(ClapTrap const & copy) {
    *this = copy;
    std::cout << "Abstract ClapTrap Copy Constructor Called" << '\n';
}

ClapTrap &ClapTrap::operator=(ClapTrap const & copy) {
    this->_hitPoints       = copy._hitPoints;
    this->_maxHitPoints    = copy._maxHitPoints;
    this->_energyPoints    = copy._energyPoints;
    this->_maxEnergyPoints = copy._maxEnergyPoints;
    this->_level = copy._level;
    this->_name  = copy._name;
    this->_meleeAttackDamage    = copy._meleeAttackDamage;
    this->_rangedAttackDamage   = copy._rangedAttackDamage;
    this->_armorDamageReduction = copy._armorDamageReduction;
    std::cout << "Assignment ClapTrap Function called." << std::endl;
    return *this;
}

ClapTrap::~ClapTrap() {
    std::cout << "Desctructor ClapTrap Function called" << std::endl;
}

std::string ClapTrap::getName() const {
    return this->_name;
}

int ClapTrap::getHitPoints() const {
    return this->_hitPoints;
}

int ClapTrap::getEnergyPoints() const {
    return this->_energyPoints;
}

void ClapTrap::setHitPoints(unsigned int newHitPoints) {
    if (newHitPoints > this->_maxHitPoints)
        newHitPoints = this->_maxHitPoints;
    else if (newHitPoints < 0)
        newHitPoints = 0;
    this->_hitPoints = newHitPoints;
}

void ClapTrap::setEnergyPoints(unsigned int newEnergyPoints) {
    if (newEnergyPoints > this->_maxEnergyPoints)
        newEnergyPoints = this->_maxEnergyPoints;
    else if (newEnergyPoints < 0)
        newEnergyPoints = 0;
    this->_energyPoints = newEnergyPoints;
}

void ClapTrap::meleeAttack(std::string const & target) const {
    std::cout
        << "FR4G-TP " << this->_name
        << " attacks " << target
        << " in melee, causing " << this->_meleeAttackDamage
        << " points of damage !" << std::endl;
}

void ClapTrap::rangedAttack(std::string const & target) const {
    std::cout
        << "FR4G-TP " << this->_name
        << " attacks " << target
        << " at range, causing " << this->_rangedAttackDamage
        << " points of damage !" << std::endl;
}

void ClapTrap::takeDamage(unsigned int amount) {
    unsigned int damageTaken;

    if (amount <= this->_armorDamageReduction) {
        std::cout << "Not enough damage to take some damage" << std::endl;
        return;
    }
    if (amount > this->_hitPoints)
        damageTaken = this->_hitPoints;
    else
        damageTaken = amount - this->_armorDamageReduction;
    this->setHitPoints(this->getHitPoints() - damageTaken);
    std::cout << "Damage taken : " << amount
              << ", armor Points : " << this->_armorDamageReduction
              << ", new HitPoints : " << this->getHitPoints() << std::endl;
}

void ClapTrap::beRepaired(unsigned int amount) {
    this->setHitPoints(this->getHitPoints() + amount);
    std::cout << "Amount repaired : " << amount
              << ", new HitPoints : " << this->getHitPoints() << std::endl;
}
