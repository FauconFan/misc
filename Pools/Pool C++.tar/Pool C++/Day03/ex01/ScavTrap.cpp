/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ScavTrap.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/29 19:43:08 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/30 10:07:05 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "ScavTrap.hpp"

ScavTrap::ScavTrap()
        : _hitPoints(100), _maxHitPoints(100),
        _energyPoints(50), _maxEnergyPoints(50),
        _level(1), _name("Unknown"),
        _meleeAttackDamage(20), _rangedAttackDamage(15),
        _armorDamageReduction(3) {
    std::cout << "ScavTrap Default Contructor called : " << std::endl;
    srand(time(NULL));
}

ScavTrap::ScavTrap(std::string name)
        : _hitPoints(100), _maxHitPoints(100),
        _energyPoints(50), _maxEnergyPoints(50),
        _level(1), _name(name),
        _meleeAttackDamage(20), _rangedAttackDamage(15),
        _armorDamageReduction(3) {
    std::cout << "ScavTrap Contructor called : " << name << std::endl;
    srand(time(NULL));
}

ScavTrap::ScavTrap(ScavTrap const & copy) {
    std::cout << "ScavTrap Copy Constructor called." << std::endl;
    *this = copy;
}

ScavTrap::~ScavTrap() {
    std::cout << "ScavTrap Destructor called." << std::endl;
}

ScavTrap &ScavTrap::operator=(ScavTrap const & copy) {
    this->_hitPoints = copy._hitPoints;
    this->_maxHitPoints = copy._maxHitPoints;
    this->_energyPoints = copy._energyPoints;
    this->_maxEnergyPoints = copy._maxEnergyPoints;
    this->_level = copy._level;
    this->_name = copy._name;
    this->_meleeAttackDamage = copy._meleeAttackDamage;
    this->_rangedAttackDamage = copy._rangedAttackDamage;
    this->_armorDamageReduction = copy._armorDamageReduction;
    std::cout << "Assignment Function called." << std::endl;
    return *this;
}

std::string ScavTrap::getName() const {
    return this->_name;
}

int ScavTrap::getHitPoints() const {
    return this->_hitPoints;
}

int ScavTrap::getEnergyPoints() const {
    return this->_energyPoints;
}

void ScavTrap::setHitPoints(unsigned int newHitPoints) {
    if (newHitPoints > this->_maxHitPoints)
        newHitPoints = this->_maxHitPoints;
    else if (newHitPoints < 0)
        newHitPoints = 0;
    this->_hitPoints = newHitPoints;
}

void ScavTrap::setEnergyPoints(unsigned int newEnergyPoints) {
    if (newEnergyPoints > this->_maxEnergyPoints)
        newEnergyPoints = this->_maxEnergyPoints;
    else if (newEnergyPoints < 0)
        newEnergyPoints = 0;
    this->_energyPoints = newEnergyPoints;
}

void ScavTrap::meleeAttack(std::string const & target) const {
    std::cout
        << "FR4G-TP " << this->_name
        << " attacks " << target
        << " in melee, causing " << this->_meleeAttackDamage
        << " points of damage !" << std::endl;
}

void ScavTrap::rangedAttack(std::string const & target) const {
    std::cout
        << "FR4G-TP " << this->_name
        << " attacks " << target
        << " at range, causing " << this->_rangedAttackDamage
        << " points of damage !" << std::endl;
}

void ScavTrap::takeDamage(unsigned int amount) {
    unsigned int damageTaken;

    if (amount <= this->_armorDamageReduction)
    {
        std::cout << "Not enough damage to take some damage" << std::endl;
        return ;
    }
    if (amount > this->_hitPoints)
        damageTaken = this->_hitPoints;
    else
        damageTaken = amount - this->_armorDamageReduction;
    this->setHitPoints(this->getHitPoints() - damageTaken);
    std::cout << "Damage taken : " << amount
        << ", armor Points : " << this->_armorDamageReduction
        << ", new HitPoints : " << this->getHitPoints() << std::endl;
}

void ScavTrap::beRepaired(unsigned int amount) {
    this->setHitPoints(this->getHitPoints() + amount);
    std::cout << "Amount repaired : " << amount
        << ", new HitPoints : " << this->getHitPoints() << std::endl;
}

void ScavTrap::challengeNewcomer() const {
    std::cout << this->_name << " challenge you to " << this->_list_challenges[rand() % _size_list] << '\n';
}

unsigned int ScavTrap::_size_list = 5;

std::string ScavTrap::_list_challenges[] = {
    "Go on the Moon",
    "Fly over the Eiffel Tower",
    "Go in America",
    "Get the courage to kiss your girl",
    "Keep her forever"
};
