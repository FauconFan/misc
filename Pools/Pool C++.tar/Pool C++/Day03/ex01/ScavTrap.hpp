/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ScavTrap.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/29 19:37:03 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/30 10:06:29 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SCAVTRAP_HPP
#define SCAVTRAP_HPP

#include <string>

class ScavTrap {
    public:
        ScavTrap ();
        ScavTrap (std::string name);
        ScavTrap (ScavTrap const &);
        virtual ~ScavTrap ();

        ScavTrap &operator=(ScavTrap const &);

        std::string getName() const;
        int getHitPoints() const;
        int getEnergyPoints() const;

        void meleeAttack(std::string const & target) const;
        void rangedAttack(std::string const & target) const;
        void takeDamage(unsigned int amount);
        void beRepaired(unsigned int amount);

        void challengeNewcomer() const;
    private:
        unsigned int _hitPoints;
        unsigned int _maxHitPoints;
        unsigned int _energyPoints;
        unsigned int _maxEnergyPoints;
        unsigned int _level;
        std::string _name;
        unsigned int _meleeAttackDamage;
        unsigned int _rangedAttackDamage;
        unsigned int _armorDamageReduction;

        void setHitPoints(unsigned int newHitPoints);
        void setEnergyPoints(unsigned int newEnergyPoints);

        static unsigned int _size_list;
        static std::string _list_challenges[];
};

#endif // ifndef SCAVTRAP_HPP
