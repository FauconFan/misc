/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   FlagTrap.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/29 19:43:08 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/30 10:05:42 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "FlagTrap.hpp"

FlagTrap::FlagTrap()
    : _hitPoints(100), _maxHitPoints(100),
    _energyPoints(100), _maxEnergyPoints(100),
    _level(1), _name("Unknown"),
    _meleeAttackDamage(30), _rangedAttackDamage(20),
    _armorDamageReduction(5) {
    std::cout << "Default Contructor called : " << std::endl;

    srand(time(NULL));
}

FlagTrap::FlagTrap(std::string name)
    : _hitPoints(100), _maxHitPoints(100),
    _energyPoints(100), _maxEnergyPoints(100),
    _level(1), _name(name),
    _meleeAttackDamage(30), _rangedAttackDamage(20),
    _armorDamageReduction(5) {
    std::cout << "String Contructor called : " << name << std::endl;

    srand(time(NULL));
}

FlagTrap::FlagTrap(FlagTrap const & copy) {
    std::cout << "Copy Constructor called." << std::endl;

    *this = copy;
}

FlagTrap::~FlagTrap() {
    std::cout << "Destructor called." << std::endl;
}

FlagTrap &FlagTrap::operator=(FlagTrap const & copy) {
    this->_hitPoints       = copy._hitPoints;
    this->_maxHitPoints    = copy._maxHitPoints;
    this->_energyPoints    = copy._energyPoints;
    this->_maxEnergyPoints = copy._maxEnergyPoints;
    this->_level = copy._level;
    this->_name  = copy._name;
    this->_meleeAttackDamage    = copy._meleeAttackDamage;
    this->_rangedAttackDamage   = copy._rangedAttackDamage;
    this->_armorDamageReduction = copy._armorDamageReduction;
    std::cout << "Assignment Function called." << std::endl;
    return *this;
}

std::string FlagTrap::getName() const {
    return this->_name;
}

int FlagTrap::getHitPoints() const {
    return this->_hitPoints;
}

int FlagTrap::getEnergyPoints() const {
    return this->_energyPoints;
}

void FlagTrap::setHitPoints(unsigned int newHitPoints) {
    if (newHitPoints > this->_maxHitPoints)
        newHitPoints = this->_maxHitPoints;
    else if (newHitPoints < 0)
        newHitPoints = 0;
    this->_hitPoints = newHitPoints;
}

void FlagTrap::setEnergyPoints(unsigned int newEnergyPoints) {
    if (newEnergyPoints > this->_maxEnergyPoints)
        newEnergyPoints = this->_maxEnergyPoints;
    else if (newEnergyPoints < 0)
        newEnergyPoints = 0;
    this->_energyPoints = newEnergyPoints;
}

void FlagTrap::meleeAttack(std::string const & target) const {
    std::cout
        << "FR4G-TP " << this->_name
        << " attacks " << target
        << " in melee, causing " << this->_meleeAttackDamage
        << " points of damage !" << std::endl;
}

void FlagTrap::rangedAttack(std::string const & target) const {
    std::cout
        << "FR4G-TP " << this->_name
        << " attacks " << target
        << " at range, causing " << this->_rangedAttackDamage
        << " points of damage !" << std::endl;
}

void FlagTrap::takeDamage(unsigned int amount) {
    unsigned int damageTaken;

    if (amount <= this->_armorDamageReduction) {
        std::cout << "Not enough damage to take some damage" << std::endl;
        return;
    }
    if (amount > this->_hitPoints)
        damageTaken = this->_hitPoints;
    else
        damageTaken = amount - this->_armorDamageReduction;
    this->setHitPoints(this->getHitPoints() - damageTaken);
    std::cout << "Damage taken : " << amount
              << ", armor Points : " << this->_armorDamageReduction
              << ", new HitPoints : " << this->getHitPoints() << std::endl;
}

void FlagTrap::beRepaired(unsigned int amount) {
    this->setHitPoints(this->getHitPoints() + amount);
    std::cout << "Amount repaired : " << amount
              << ", new HitPoints : " << this->getHitPoints() << std::endl;
}

unsigned int FlagTrap::vaulthunter_dot_exe(std::string const & target) const {
    unsigned int (FlagTrap::* ptr)(std::string const &) const;

    ptr = this->_attacks[rand() % this->_size_list];
    return (this->*ptr)(target);
}

unsigned int FlagTrap::_size_list = 5;

unsigned int(FlagTrap::* FlagTrap::_attacks[])(std::string const & target) const = {
    &FlagTrap::nullAttack,
    &FlagTrap::onePunch,
    &FlagTrap::kamehameha,
    &FlagTrap::infernoTornade,
    &FlagTrap::frozenIce
};

unsigned int FlagTrap::nullAttack(std::string const & target) const {
    std::cout << "Attack Failed on " << target << std::endl;

    return 0;
}

unsigned int FlagTrap::onePunch(std::string const & target) const {
    std::cout << "One punch on " << target << std::endl;

    return 1000;
}

unsigned int FlagTrap::kamehameha(std::string const & target) const {
    std::cout << "KAMEHAMEHAAAAAAAAAAAAAA (" << target << ")" << std::endl;

    return 20;
}

unsigned int FlagTrap::infernoTornade(std::string const & target) const {
    std::cout << "Care about the INFERNO TORNADE (" << target << ")" << std::endl;

    return 40;
}

unsigned int FlagTrap::frozenIce(std::string const & target) const {
    std::cout << "The power of Ice FROZE YOU (" << target << ")" << std::endl;

    return 40;
}
