/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/14 19:57:04 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/16 11:16:17 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <time.h>
#include <cstdlib>
#include "span.hpp"

int main() {
    srand(time(NULL));
    Span sp(5);

    sp.addNumber(5);
    sp.addNumber(3);
    sp.addNumber(17);
    sp.addNumber(9);
    sp.addNumber(11);
    sp.addNumber(20, 21, 22, 23);
    sp.show();
    std::cout << "shortestSpan : " << sp.shortestSpan() << '\n';
    std::cout << "longestSpan : " << sp.longestSpan() << '\n';

    Span sp2(10000);
    for (size_t i = 0; i < 4242; i++) {
        sp2.addNumber(rand());
    }
    //sp2.show();
    std::cout << "shortestSpan : " << sp2.shortestSpan() << '\n';
    std::cout << "longestSpan : " << sp2.longestSpan() << '\n';
    return 0;
}
