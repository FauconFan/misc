/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   span.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/14 19:50:34 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/16 11:18:03 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SPAN_HPP
#define SPAN_HPP

#include <cstddef>
#include <vector>

#define FUNC_COMP_INT [](int &a, int &b) -> bool {return a < b;}
#define FUNC_SHOW_INT [](int a) -> void {std::cout << a << ' ';}

class Span {
    public:
        Span (size_t n);
        Span (Span const &);
        virtual ~Span ();

        Span &operator=(Span const &);

        void addNumber(int);
        template<typename ... Arg>
        void addNumber(int fst, Arg... tail) {
            addNumber(fst);
            addNumber(tail...);
        }

        void show() const;
        void sort();

        int shortestSpan();
        int longestSpan();
    private:
        std::vector<int> data;
        size_t len_actu;
        bool is_sort;

        std::vector<int> generateSpans();
    };

#endif
