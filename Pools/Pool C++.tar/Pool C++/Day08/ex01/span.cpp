/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   span.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/14 19:50:35 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/16 11:18:08 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <algorithm>
#include <stdexcept>
#include "span.hpp"

Span::Span(size_t n) {
    this->len_actu = n;
    this->is_sort = false;
}

Span::Span(Span const &copy) {
    *this = copy;
}

Span::~Span() {}

Span &Span::operator=(Span const & copy) {
    this->len_actu = copy.len_actu;
    return *this;
}

void Span::addNumber(int cand) {
    if (this->data.size() >= this->len_actu)
        throw std::exception();
    this->data.push_back(cand);
    this->len_actu++;
    this->is_sort = false;
}

void Span::sort() {
    if (this->is_sort)
        return;
    std::sort(this->data.begin(), this->data.end(), FUNC_COMP_INT);
    this->is_sort = true;
}

void Span::show() const {
    std::for_each(this->data.begin(), this->data.end(), FUNC_SHOW_INT);
    std::cout << '\n';
}

int Span::shortestSpan() {
    std::vector<int> spans;

    spans = generateSpans();
    if (spans.size() == 0)
        throw std::exception();
    return *(std::min_element(spans.begin(), spans.end(), FUNC_COMP_INT));
}

int Span::longestSpan() {
    std::vector<int> spans;

    spans = generateSpans();
    if (spans.size() == 0)
        throw std::exception();
    return *(std::max_element(spans.begin(), spans.end(), FUNC_COMP_INT));
}

std::vector<int> Span::generateSpans() {
    std::vector<int> ret;
    std::vector<int>::iterator it;

    if (this->data.size() <= 1)
        return ret;
    this->sort();
    it = this->data.begin();
    for (it = this->data.begin(); it != this->data.end() - 1; ++it) {
        ret.push_back(*(it + 1) - *it);
    }
    return ret;
}
