/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mutantstack.hpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/15 20:54:42 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/16 00:34:43 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MUTANT_STACK_HPP
#define MUTANT_STACK_HPP

template <typename T>
class MutantStack {
    private:
        class _LinkedListStack {
            public:
                _LinkedListStack (T);
                _LinkedListStack (T, _LinkedListStack *);
                _LinkedListStack (_LinkedListStack const &);
                virtual ~_LinkedListStack ();

                _LinkedListStack &operator=(_LinkedListStack const &);

                T const &getContent() const;
                T &getContent();
                _LinkedListStack * getNext();
                void deleteNextPtr();
            private:
                T _content;
                _LinkedListStack * next;
        };

    public:
        class iterator {
            public:
                iterator ();
                iterator (_LinkedListStack *, _LinkedListStack *);
                iterator (iterator const &);
                virtual ~iterator ();

                iterator &operator=(iterator const &);

                T &operator*();
                T const &operator*() const;

                bool operator==(const typename MutantStack<T>::iterator & a);
                bool operator!=(const typename MutantStack<T>::iterator & a);

                typename MutantStack<T>::iterator & operator++();
                typename MutantStack<T>::iterator operator++(int);

                typename MutantStack<T>::iterator & operator--();
                typename MutantStack<T>::iterator operator--(int);
            private:
                MutantStack<T>::_LinkedListStack * ptr_head;
                MutantStack<T>::_LinkedListStack * ptr_actu;

                void verify_attributes() const;
        };

        MutantStack ();
        MutantStack (MutantStack const &);
        virtual ~MutantStack ();

        MutantStack &operator=(MutantStack const &);

        bool empty() const;
        size_t size() const;
        T &top();
        const T &top() const;
        void push(const T &);
        void pop();
        void swap(MutantStack &) noexcept;

        MutantStack<T>::iterator begin() const;
        MutantStack<T>::iterator end() const;

    private:

        _LinkedListStack * _head;
        size_t _len;
};

#include "mutantstack.tpp"

#endif // ifndef MUTANT_STACK_HPP
