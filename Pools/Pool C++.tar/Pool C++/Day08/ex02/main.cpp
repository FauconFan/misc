/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/15 20:24:02 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/16 00:52:21 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <functional>
#include <algorithm>
#include <string>
#include "mutantstack.hpp"

int main(void) {
    MutantStack<int> ms;
    MutantStack<int> ms2;

    ms.push(5);
    ms.push(10);
    std::cout << "size : " << ms.size() << '\n';
    std::cout << "top : " << ms.top() << '\n';
    ms.top() = 7;
    std::cout << "size : " << ms.size() << '\n';
    std::cout << "top : " << ms.top() << '\n';

    ms.pop();
    std::cout << "size : " << ms.size() << '\n';
    std::cout << "top : " << ms.top() << '\n';

    ms2.push(1);
    ms2.push(2);
    ms2.push(3);
    ms2.push(4);

    std::cout << "size ms  : " << ms.size() << '\n';
    std::cout << "size ms2 : " << ms2.size() << '\n';

    ms.swap(ms2);

    std::cout << "size ms  : " << ms.size() << '\n';
    std::cout << "size ms2 : " << ms2.size() << '\n';

    MutantStack<int>::iterator it = ms.begin();
    MutantStack<int>::iterator et = ms.end();

    std::cout << '\n';
    ++it;
    --it;
    while (it != et) {
        *--++ it;
        *--++ it;
        *--++ it;
        std::cout << *it++ << '\n';
        ++-- it;
        ++-- it;
        ++-- it;
    }

    std::cout << '\n';
    for (MutantStack<int>::iterator it2 = ms2.begin(); it2 != ms2.end(); it2++) {
        std::cout << *it2 << '\n';
    }

    std::cout << '\n';
    std::for_each(ms.begin(), ms.end(), [](int a) -> void {
        std::cout << a << "\n";
    });

    std::cout << '\n';

    MutantStack<std::string> st;

    st.push(std::string("!"));
    st.push(std::string("Jojo"));
    st.push(std::string("is"));
    st.push(std::string("name"));
    st.push(std::string("my"));
    st.push(std::string("world,"));
    st.push(std::string("Hello"));

    std::for_each(st.begin(), st.end(), [](std::string s) -> void {
        std::cout << s << ' ';
    });
    std::cout << '\n';

    return 0;
} // main
