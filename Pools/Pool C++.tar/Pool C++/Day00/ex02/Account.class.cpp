/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Account.class.cpp                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/23 20:24:42 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/23 22:03:16 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <ctime>
#include "Account.class.hpp"

int Account::getNbAccounts() {
    return Account::_nbAccounts;
}

int Account::getTotalAmount() {
    return Account::_totalAmount;
}

int Account::getNbDeposits() {
    return Account::_totalNbDeposits;
}

int Account::getNbWithdrawals() {
    return Account::_totalNbWithdrawals;
}

void Account::displayAccountsInfos() {
    Account::_displayTimestamp();
    std::cout
        << "accounts:" << Account::getNbAccounts() << ';'
        << "total:" << Account::getTotalAmount() << ';'
        << "deposits:" << Account::getNbDeposits() << ';'
        << "withdrawals:" << Account::getNbWithdrawals() << '\n';
}

Account::Account (int initial_deposit)
        : _accountIndex(Account::getNbAccounts()),
            _amount(initial_deposit),
            _nbDeposits(0),
            _nbWithdrawals(0) {
    Account::_displayTimestamp();
    std::cout
        << "index:" << this->_accountIndex << ';'
        << "amount:" << this->_amount << ';'
        << "created\n";
    Account::_nbAccounts = Account::_nbAccounts + 1;
    Account::_totalAmount = Account::_totalAmount + initial_deposit;
}

Account::~Account () {
    Account::_displayTimestamp();
    std::cout
        << "index:" << this->_accountIndex << ';'
        << "amount:" << this->_amount << ';'
        << "closed\n";
    Account::_nbAccounts = Account::_nbAccounts - 1;
    Account::_totalAmount = Account::_totalAmount - this->_amount;
}

void Account::makeDeposit(int deposit) {
    Account::_displayTimestamp();
    std::cout
        << "index:" << this->_accountIndex << ';'
        << "p_amount:" << this->_amount << ';'
        << "deposit:" << deposit << ';';
    this->_amount += deposit;
    this->_nbDeposits ++;
    Account::_totalAmount += deposit;
    Account::_totalNbDeposits ++;
    std::cout
        << "amount:" << this->_amount << ';'
        << "nb_deposits:" << this->_nbDeposits << '\n';
}

bool Account::makeWithdrawal(int withdrawal) {
    bool isAccept;

    Account::_displayTimestamp();
    std::cout
        << "index:" << this->_accountIndex << ';'
        << "p_amount:" << this->_amount << ';';
    isAccept = (this->_amount - withdrawal >= 0);
    if (isAccept) {
        this->_amount -= withdrawal;
        this->_nbWithdrawals ++;
        Account::_totalAmount -= withdrawal;
        Account::_totalNbWithdrawals ++;
        std::cout
            << "withdrawal:" << withdrawal << ';'
            << "amount:" << this->_amount << ';'
            << "nb_withdrawals:" << this->_nbWithdrawals << '\n';
    }
    else {
        std::cout << "withdrawal:refused\n";
    }
    return isAccept;
}

int Account::checkAmount() const {
    return 0;
}

void Account::displayStatus() const {
    Account::_displayTimestamp();
    std::cout
        << "index:" << this->_accountIndex << ';'
        << "amount:" << this->_amount << ';'
        << "deposits:" << this->_nbDeposits << ';'
        << "withdrawals:" << this->_nbWithdrawals << '\n';
}

int Account::_nbAccounts = 0;
int Account::_totalAmount = 0;
int Account::_totalNbDeposits = 0;
int Account::_totalNbWithdrawals = 0;

void Account::_displayTimestamp() {
    time_t cnow = time(NULL);
    std::tm *now = NULL;

    now = localtime(&cnow);
    std::cout << '[' << 1900 + now->tm_year;
    if (now->tm_mon < 10)
        std::cout << "0";
    std::cout << now->tm_mon;
    if (now->tm_mday < 10)
        std::cout << "0";
    std::cout << now->tm_mday << '_';
    if (now->tm_hour < 10)
        std::cout << "0";
    std::cout << now->tm_hour;
    if (now->tm_min < 10)
        std::cout << "0";
    std::cout << now->tm_min;
    if (now->tm_sec < 10)
        std::cout << "0";
    std::cout << now->tm_sec << "] ";
    // std::cout << "[20150406_153629] ";
}
