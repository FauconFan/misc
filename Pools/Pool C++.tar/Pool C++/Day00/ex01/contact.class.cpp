/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   contact.class.cpp                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/23 00:08:48 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/24 10:37:54 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "contact.class.hpp"

Contact::Contact (std::string first_name,
  std::string                 last_name,
  std::string                 nickname,
  std::string                 login,
  std::string                 postal_address,
  std::string                 phone_number,
  std::string                 birthday_date,
  std::string                 favorite_meal,
  std::string                 underwear_color,
  std::string                 darkest_secret) :
    first_name(first_name),
    last_name(last_name),
    nickname(nickname),
    login(login),
    postal_address(postal_address),
    phone_number(phone_number),
    birthday_date(birthday_date),
    favorite_meal(favorite_meal),
    underwear_color(underwear_color),
    darkest_secret(darkest_secret) {}

Contact::~Contact() {}

std::string Contact::getFirstName() const {
    return this->first_name;
}

std::string Contact::getLastName() const {
    return this->last_name;
}

std::string Contact::getNickName() const {
    return this->nickname;
}

void Contact::describeYourself() const {
    std::cout
        << "First name : " << this->first_name << '\n'
        << "Last name : " << this->last_name << '\n'
        << "Nickname : " << this->nickname << '\n'
        << "Login : " << this->login << '\n'
        << "Postal Address : " << this->postal_address << '\n'
        << "Phone number : " << this->phone_number << '\n'
        << "Birthday Date : " << this->birthday_date << '\n'
        << "Favorite Meal : " << this->favorite_meal << '\n'
        << "Underwear color : " << this->underwear_color << '\n'
        << "Darkest secret : " << this->darkest_secret << '\n';
}

std::string Contact::_askQuestion(std::string ques) {
    std::string res;

    std::cout << ques << " : ";

    std::getline(std::cin, res);
    return res;
}

Contact * Contact::askingContact() {
    return new Contact(
            _askQuestion("First name"),
            _askQuestion("Last name"),
            _askQuestion("Nickname"),
            _askQuestion("Login"),
            _askQuestion("Postal address"),
            _askQuestion("Phone number"),
            _askQuestion("Birthday date"),
            _askQuestion("Favorite meal"),
            _askQuestion("Underwear color"),
            _askQuestion("Darkest secret")
    );
}

Contact * Contact::buildContact(std::string sample) {
    return new Contact(sample, sample, sample, sample, sample, sample, sample, sample, sample,
            sample);
}
