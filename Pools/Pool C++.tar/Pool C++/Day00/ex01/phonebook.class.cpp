/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   phonebook.class.cpp                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/23 09:16:27 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/24 10:38:15 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "phonebook.class.hpp"

Phonebook::Phonebook() :
    size_actu(0) {
    for (size_t i = 0; i < SIZE_BOOK; i++) {
        this->book_content[i] = NULL;
    }
    std::cout << "Phonebook created" << '\n';
    std::cout << "Default size book : " << SIZE_BOOK << '\n';
}

Phonebook::~Phonebook() {
    for (size_t i = 0; i < this->size_actu; i++) {
        delete this->book_content[i];
    }
}

void Phonebook::addContact(Contact * new_contact) {
    if (this->size_actu == SIZE_BOOK) {
        for (size_t i = 0; i < SIZE_BOOK - 1; i++) {
            this->book_content[i] = this->book_content[i + 1];
        }
        std::cout
            << "You have erased the oldest contact you've added in the phonebook"
            << '\n';
        this->size_actu--;
    }
    this->book_content[this->size_actu] = new_contact;
    this->size_actu++;
}

std::string Phonebook::_adaptStr(
  std::string content,
  size_t      wideCol = 10)
const {
    if (content.length() <= wideCol) {
        std::string res;

        res = content;
        res.resize(wideCol, ' ');
        return res;
    }
    return content.substr(0, wideCol - 1) + '.';
}

void Phonebook::_displayPhonebook() const {
    for (size_t i = 0; i < 48; i++) {
        std::cout << '-';
    }
    std::cout << '\n'
              << "| index | first name | last name  | nickname   |"
              << '\n';
    for (size_t i = 0; i < 48; i++) {
        std::cout << '-';
    }
    std::cout << '\n';
    for (size_t i = 0; i < this->size_actu; i++) {
        std::string index;

        index = std::to_string(i + 1);
        std::cout
            << "| "
            << this->_adaptStr(index, 5)
            << " | "
            << this->_adaptStr(this->book_content[i]->getFirstName())
            << " | "
            << this->_adaptStr(this->book_content[i]->getLastName())
            << " | "
            << this->_adaptStr(this->book_content[i]->getNickName())
            << " |\n";
    }
    for (size_t i = 0; i < 48; i++) {
        std::cout << '-';
    }
    std::cout << '\n';
}

Contact * Phonebook::selectContact() const {
    size_t retry      = 0;
    int indexChoosen  = 0;
    std::string entry = "";

    this->_displayPhonebook();
    if (this->size_actu == 0) {
        std::cout << "No contacts in the phonebook\n";
        return NULL;
    }
    else if (this->size_actu == 1) {
        std::cout << "Only one contact in the phonebook" << '\n';
        return this->book_content[0];
    }
    while (retry < RETRY_SELECT_CONTACT) {
        std::cout << "Index : ";
        std::getline(std::cin, entry);
        try {/* message */
            indexChoosen = std::stof(entry);
        }
        catch (const std::exception& e) {
            indexChoosen = 0;
        }
        if (indexChoosen >= 1 && indexChoosen <= (int) this->size_actu)
            return this->book_content[indexChoosen - 1];

        std::cout << "The entry is not correct, choose a number between 1 and "
                  << (this->size_actu)
                  << '\n';
        retry++;
    }
    return NULL;
} // Phonebook::selectContact
