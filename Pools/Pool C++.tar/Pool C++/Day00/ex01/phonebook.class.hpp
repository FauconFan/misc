/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   phonebook.class.hpp                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/23 09:15:02 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/23 20:08:40 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PHONEBOOK_CLASS_HPP
#define PHONEBOOK_CLASS_HPP

#include <iostream>
#include <array>
#include <string>
#include "contact.class.hpp"

#define SIZE_BOOK 8
#define RETRY_SELECT_CONTACT 3

class Phonebook {
private:
    std::array<Contact *, SIZE_BOOK> book_content;
    size_t size_actu;

    std::string _adaptStr(std::string content, size_t wideCol) const;
    void _displayPhonebook() const;

public:
    Phonebook ();
    virtual ~Phonebook ();
    void addContact(Contact *new_contact);
    Contact *selectContact() const;
};

#endif
