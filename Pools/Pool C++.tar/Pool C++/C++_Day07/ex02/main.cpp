/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/12 10:43:35 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/11 12:09:54 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <functional>

#include "Array.template.hpp"

void displayString(std::string str)
{
    std::cout << str;
}

std::string addCommaNL(std::string str, int rank)
{
    if (rank < 1)
        return str + ",";
    return str;
}

int main() {

    Array<std::string> i1 = Array<std::string>(2);
	Array<std::string> i2;

    i1[0] = "Hello";
    i1[1] = " World";

    i1.iter(displayString);
    std::cout << '\n';

    i1.mapi(addCommaNL);

    i1.iter(displayString);
    std::cout << '\n';

	i2 = i1;
	i2[1] = " People";
	i2.iter(displayString);
    std::cout << '\n';
    return 0;
}
