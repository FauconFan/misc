/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/13 08:18:47 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/14 22:48:18 by ntoniolo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "Core.class.hpp"

int main(int argc, char ** argv) {
    if (argc < 3) {
        std::cerr << "usage: ./ft_gkrellm [ncurses|sdl] [file]" << std::endl;
        return (0);
    }

    Core core;

    try {
        if (!(core.createDisplay(argv[1]))) {
            std::cerr << "Display cannot be created" << std::endl;
            return (0);
        }
        if (!(core.createModule(argv[2]))) {
            std::cerr << "Modules cannot be created" << std::endl;
            return (0);
        }
        core.loop();
    } catch (std::exception const &e) {
        std::cerr << "Error: " << e.what() << std::endl;
    }
    return (0);
}
