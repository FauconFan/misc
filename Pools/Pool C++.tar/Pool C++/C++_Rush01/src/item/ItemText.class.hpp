/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ItemText.class.hpp                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 14:38:40 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 18:57:42 by ntoniolo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ITEMTEXT_HPP
#define ITEMTEXT_HPP

#include "Item.class.hpp"
#include <string>

class ItemText : public Item {
    public:

        ItemText(std::string const &str, Vector2D<int> ncursesPosition);
        ItemText(ItemText const &src);
        ItemText        &operator=(ItemText const &rhs);
        ~ItemText(void);


        std::string const   &getItemText(void) const;

    private:
        std::string _text;

        ItemText(void);
        static const bool _debug;
};

#endif // ifndef ITEMTEXT_HPP
