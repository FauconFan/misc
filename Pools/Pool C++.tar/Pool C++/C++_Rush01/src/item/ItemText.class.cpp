/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ItemText.class.cpp                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 14:38:32 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 18:57:56 by ntoniolo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "ItemText.class.hpp"

ItemText::ItemText(std::string const &str, Vector2D<int> position) :
    Item(position),
    _text(str) {
    if (ItemText::_debug)
        std::cout << "ItemText:: Default constructor called." << std::endl;
}

ItemText::ItemText(ItemText const &src) {
    if (ItemText::_debug)
        std::cout << "ItemText:: Copy constructor called." << std::endl;
    *this = src;
}

ItemText        &ItemText::operator=(ItemText const &rhs) {
    if (ItemText::_debug)
        std::cout << "ItemText:: Assignement called." << std::endl;
    if (this != &rhs) {
        this->_position = rhs._position;
    }
    return (*this);
}

ItemText::~ItemText(void) {
    if (ItemText::_debug)
        std::cout << "ItemText:: Destructor called." << std::endl;
}

std::string const   &ItemText::getItemText(void) const {
    return (this->_text);
}

const bool ItemText::_debug = 0;
