/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ItemProgressBar.class.hpp                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 16:02:36 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 18:56:50 by ntoniolo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ITEMPROGRESSBAR_HPP
#define ITEMPROGRESSBAR_HPP

#include "Item.class.hpp"
#include <string>

class ItemProgressBar : public Item {
    public:

        ItemProgressBar(float ratio, Vector2D<int> position);
        ItemProgressBar(ItemProgressBar const &src);
        ItemProgressBar     &operator=(ItemProgressBar const &rhs);
        ~ItemProgressBar(void);


        float           getRatio(void) const;

    private:

        /*
         * float		_min;
         * float		_max;
         * float		_value;
         */
        float _ratio;

        ItemProgressBar(void);
        static const bool _debug;
};

#endif // ifndef ITEMPROGRESSBAR_HPP
