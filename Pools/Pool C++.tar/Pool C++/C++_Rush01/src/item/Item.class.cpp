#include <iostream>
#include "Item.class.hpp"

Item::Item(Vector2D<int> position) :
    _position(position) {
    if (Item::_debug)
        std::cout << "Item:: Default constructor called." << std::endl;
}

Item::Item(void) :
    _position(Vector2D<int>(0)) {
    if (Item::_debug)
        std::cout << "Item:: Default constructor called." << std::endl;
}

Item::Item(Item const &src) {
    if (Item::_debug)
        std::cout << "Item:: Copy constructor called." << std::endl;
    *this = src;
}

Item::~Item(void) {
    if (Item::_debug)
        std::cout << "Item:: Destructor called." << std::endl;
}

Item        &Item::operator=(Item const &rhs) {
    if (Item::_debug)
        std::cout << "Item:: Assignement called." << std::endl;
    if (this != &rhs) {
        this->_position = rhs._position;
    }
    return (*this);
}

Vector2D<int> const &Item::getPosition(void) const {
    return (this->_position);
}

/*
 * Vector2D<int>			Item::getPosition(void) const
 * {
 *  return (Vector2D<int>(this->_ncursesPosition.getX() * TTF_FONT_SIZE / 2, this->_ncursesPosition.getY() * TTF_FONT_SIZE));
 * }*/

const bool Item::_debug = 0;
