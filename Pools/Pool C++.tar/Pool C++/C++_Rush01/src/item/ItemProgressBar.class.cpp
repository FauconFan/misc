#include <iostream>
#include "ItemProgressBar.class.hpp"

ItemProgressBar::ItemProgressBar(float ratio, Vector2D<int> position) :
    Item(position),
    _ratio(ratio) {
    if (ItemProgressBar::_debug)
        std::cout << "ItemProgressBar:: Default constructor called." << std::endl;
}

ItemProgressBar::ItemProgressBar(ItemProgressBar const &src) {
    if (ItemProgressBar::_debug)
        std::cout << "ItemProgressBar:: Copy constructor called." << std::endl;
    *this = src;
}

ItemProgressBar     &ItemProgressBar::operator=(ItemProgressBar const &rhs) {
    if (ItemProgressBar::_debug)
        std::cout << "ItemProgressBar:: Assignement called." << std::endl;
    if (this != &rhs) {
        this->_position = rhs._position;
    }
    return (*this);
}

ItemProgressBar::~ItemProgressBar(void) {
    if (ItemProgressBar::_debug)
        std::cout << "ItemProgressBar:: Destructor called." << std::endl;
}

float ItemProgressBar::getRatio(void) const {
    return (this->_ratio);
}

const bool ItemProgressBar::_debug = 0;
