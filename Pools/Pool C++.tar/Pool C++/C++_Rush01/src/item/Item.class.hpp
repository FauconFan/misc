#ifndef ITEM_HPP
#define ITEM_HPP

#include <Vector2D.interface.hpp>
#include "MonitorSdl.class.hpp"

class Item {
    public:

        Item(void);
        Item(Vector2D<int> position);
        Item(Item const &src);
        virtual ~Item(void);
        Item        &operator=(Item const &rhs);

        Vector2D<int> const &getPosition(void) const;

    protected:
        Vector2D<int> _position;

    private:

        static const bool _debug;
};

#endif // ifndef ITEM_HPP
