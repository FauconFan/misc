/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   IMonitorModule.interface.hpp                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/13 08:20:34 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/14 15:39:02 by ntoniolo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef IMONITORMODULE_HPP
#define IMONITORMODULE_HPP

/**
 * IMonitorModule describes the behavior of one or your monitor’s "modules"
 * IMonitorModule is an abstraction to the available modules. Implementing this
 * interface allows a class to behave like a module of the monitor, and allows the
 * monitor to handle every modules in an unified way.
 */

class SystemManager;
class Time;

class IMonitorModule {
    public:
        virtual ~IMonitorModule () {}

        virtual void update(SystemManager &sm, bool selected, Time const &) = 0;
    protected:
        virtual void _getModule(SystemManager &sm) = 0;
};

#endif // ifndef IMONITORMODULE_HPP
