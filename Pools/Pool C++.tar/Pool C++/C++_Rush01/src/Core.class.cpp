#include <iostream>
#include "Core.class.hpp"
#include <fstream>
#include <sstream>
#include "ModuleHostname.class.hpp"
#include "ModuleWhoAMi.class.hpp"
#include "ModuleDate.class.hpp"
#include "ModuleOsInfo.class.hpp"
#include "ModuleCpu.class.hpp"
#include "MonitorNcurses.class.hpp"
#include "MonitorSdl.class.hpp"
#include "ModuleProcesses.class.hpp"
#include "ModuleLoadAvg.class.hpp"
#include "ModuleNetwork.class.hpp"

Core::Core(void) :
    _lastTop(0) {
    if (Core::_debug)
        std::cout << "Core:: Default constructor called." << std::endl;
    this->_tm.update();
    this->updateTop();
}

Core::~Core(void) {
    if (Core::_debug)
        std::cout << "Core:: Destructor called." << std::endl;
    this->clearModule();
    if (this->_display)
        delete this->_display;
}

bool Core::createModule(std::string const &path) {
    std::string buffer;

    this->_path = path;
    std::ifstream ifile(path.c_str());
    if (!ifile.is_open())
        return (false);

    while (std::getline(ifile, buffer)) {
        if (!this->_createOneModule(buffer)) {
            ifile.close();
            return (false);
        }
    }
    ifile.close();
    if (!this->_module.size())
        return (false);

    return (true);
}

bool Core::_createOneModule(std::string const &buffer) {
    std::string moduleName;
    int x;
    int y;
    std::stringstream ss;

    if (buffer.empty())
        return (false);

    ss << buffer;
    ss >> moduleName;
    ss >> x;
    ss >> y;

    if (moduleName == "date")
        this->_module.push_back(new ModuleDate(this->_sm, Vector2D<int>(x, y)));
    else if (moduleName == "os")
        this->_module.push_back(new ModuleOsInfo(this->_sm, Vector2D<int>(x, y)));
    else if (moduleName == "hostname")
        this->_module.push_back(new ModuleHostname(this->_sm, Vector2D<int>(x, y)));
    else if (moduleName == "whoami")
        this->_module.push_back(new ModuleWhoAMi(this->_sm, Vector2D<int>(x, y)));
    else if (moduleName == "cpu")
        this->_module.push_back(new ModuleCpu(this->_sm, Vector2D<int>(x, y)));
    else if (moduleName == "processes")
        this->_module.push_back(new ModuleProcesses(this->_sm, Vector2D<int>(x, y)));
    else if (moduleName == "load")
        this->_module.push_back(new ModuleLoadAvg(this->_sm, Vector2D<int>(x, y)));
    else if (moduleName == "network")
        this->_module.push_back(new ModuleNetwork(this->_sm, Vector2D<int>(x, y)));
    else
        return (false);

    return (true);
} // Core::_createOneModule

bool Core::createDisplay(std::string const &argv) {
    if (argv == "ncurses")
        this->_display = (new MonitorNcurses(Vector2D<int>(0, 0), Vector2D<int>(100, 100)));
    else if (argv == "sdl")
        this->_display = (new MonitorSdl(780, 580, "ft_gkrellm"));
    if (!this->_display)
        return (false);

    return (true);
}

void Core::loop(void) {
    int i;

    while (!this->_display->exit()) {
        this->_tm.update();
        this->updateTop();
        this->_display->update(this->_module);
        i = 0;
        for (std::vector<AMonitorModule *>::iterator it = this->_module.begin();
          it != this->_module.end();
          it++)
        {
            (*it)->update(this->_sm,
              (this->_display->getIndexUpDown() % this->_module.size() == i), this->_tm);
            i++;
            this->_display->renderModule(**it);
        }
        this->_display->render();
        if (this->_display->save())
            this->saveConfig();
        napms(1000 / 30);
    }
}

bool Core::_writeModule(std::ofstream &of, AMonitorModule * module) {
    if (dynamic_cast<ModuleCpu *>(module))
        of << "cpu";
    else if (dynamic_cast<ModuleOsInfo *>(module))
        of << "os";
    else if (dynamic_cast<ModuleLoadAvg *>(module))
        of << "load";
    else if (dynamic_cast<ModuleProcesses *>(module))
        of << "processes";
    else if (dynamic_cast<ModuleHostname *>(module))
        of << "hostname";
    else if (dynamic_cast<ModuleDate *>(module))
        of << "date";
    else if (dynamic_cast<ModuleNetwork *>(module))
        of << "network";
    else if (dynamic_cast<ModuleWhoAMi *>(module))
        of << "whoami";
    else
        return (false);

    of << " " << module->getPosition().getX() << " " << module->getPosition().getY() << std::endl;
    return (true);
}

bool Core::saveConfig(void) {
    std::ofstream of(this->_path.c_str());

    if (!of.is_open()) {
        return (false);
    }

    for (std::vector<AMonitorModule *>::iterator it = this->_module.begin();
      it != this->_module.end();
      it++)
    {
        if (!this->_writeModule(of, *it)) {
            of.close();
            return (false);
        }
    }
    of.close();
    return (true);
}

bool Core::updateTop(void) {
    if (this->_lastTop + 1000 < this->_tm.getTimestamp()) {
        this->_sm.updateTop();
        this->_lastTop = this->_tm.getTimestamp();
    }
    return (true);
}

void Core::clearModule(void) {
    for (std::vector<AMonitorModule *>::iterator it = this->_module.begin();
      it != this->_module.end(); it++)
    {
        delete *it;
    }
    this->_module.clear();
}

const bool Core::_debug = 0;
