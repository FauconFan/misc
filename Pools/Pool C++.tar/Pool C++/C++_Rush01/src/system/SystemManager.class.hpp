/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   SystemManager.class.hpp                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/13 09:28:18 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/14 22:35:00 by ntoniolo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SYSTEMMANAGER_CLASS_HPP
#define SYSTEMMANAGER_CLASS_HPP

#include <string>
#include <stdexcept>
#include <vector>
#include <map>

#define HOSTNAME_CMD "hostname_cmd"
#define WHOAMI_CMD   "whoami"
#define DATE_CMD     "date"
#define OSINFO_CMD   "sw_vers"
#define TOP_HEAD     "top_cmd"

class SystemManager {
    private:
        class SystemManagerMeta {
            public:
                SystemManagerMeta ();
                SystemManagerMeta (std::vector<std::string>);
                SystemManagerMeta (const SystemManagerMeta &);
                SystemManagerMeta &operator=(SystemManagerMeta const &);
                virtual ~SystemManagerMeta ();

                std::vector<std::string> getArgv();
            private:

                std::vector<std::string> argv;
        };

        class SystemManagerException : public std::exception {
            public:
                SystemManagerException (char *);
                virtual ~SystemManagerException () throw ();
                SystemManagerException (const SystemManagerException &);

                const char * what() const throw();
            private:
                SystemManagerException ();
                SystemManagerException &operator=(SystemManagerException const &);

                char * msg;
        };

    public:
        SystemManager ();
        virtual ~SystemManager ();

        std::string     exec(std::string);
        void            updateTop(void);
    private:
        // FIXME map as attribute not const not static
        std::map<std::string, SystemManager::SystemManagerMeta> mapCmds;
        std::string _bufferTop;
        bool _canExecTop;

        void            real_exec(std::vector<std::string> argv);

        SystemManager (const SystemManager &);
        SystemManager &operator=(SystemManager const &);
};

#endif // ifndef SYSTEMMANAGER_CLASS_HPP
