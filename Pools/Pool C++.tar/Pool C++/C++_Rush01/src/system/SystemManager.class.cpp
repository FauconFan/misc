/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   SystemManager.class.cpp                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/13 09:28:18 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/14 22:43:27 by ntoniolo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <sstream>
#include <errno.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/wait.h>
#include "SystemManager.class.hpp"

SystemManager::SystemManager() : _canExecTop(false) {
    std::vector<std::string> argv;

    argv.push_back("/bin/hostname");
    this->mapCmds[HOSTNAME_CMD] = SystemManagerMeta(argv);
    argv.clear();
    argv.push_back("/usr/bin/whoami");
    this->mapCmds[WHOAMI_CMD] = SystemManagerMeta(argv);
    argv.clear();
    argv.push_back("/bin/date");
    this->mapCmds[DATE_CMD] = SystemManagerMeta(argv);
    argv.clear();
    argv.push_back("/usr/bin/sw_vers");
    this->mapCmds[OSINFO_CMD] = SystemManagerMeta(argv);
    argv.clear();
    argv.push_back("/usr/bin/top");
    argv.push_back("-n");
    argv.push_back("0");
    argv.push_back("-l");
    argv.push_back("1");
    this->mapCmds[TOP_HEAD] = SystemManagerMeta(argv);
}

SystemManager::~SystemManager() {}

SystemManager::SystemManager(const SystemManager & rhs) {
    *this = rhs;
}

SystemManager &SystemManager::operator=(SystemManager const & rhs) {
    (void) rhs;
    return *this;
}

/**
 * Resources
 * http://www.microhowto.info/howto/capture_the_output_of_a_child_process_in_c.html
 */

void SystemManager::updateTop(void) {
    this->_canExecTop = true;
    this->_bufferTop  = this->exec(TOP_HEAD);
    this->_canExecTop = false;
}

std::string SystemManager::exec(std::string id) {
    if (!this->_canExecTop && id == TOP_HEAD)
        return (std::string(this->_bufferTop));

    std::map<std::string, SystemManagerMeta>::iterator smmi = this->mapCmds.find(id);
    SystemManagerMeta smm;
    int filedes[2];
    pid_t pid;
    std::stringstream ss;
    char buffer[4096];

    if (smmi == this->mapCmds.end())
        throw SystemManagerException(strerror(errno));  // FIXME
    smm = smmi->second;
    if (pipe(filedes) == -1)
        throw SystemManagerException(strerror(errno));
    pid = fork();
    if (pid == -1) {
        throw SystemManagerException(strerror(errno));
    }
    else if (pid == 0) {
        // Child process
        while ((dup2(filedes[1], STDOUT_FILENO) == -1) && (errno == EINTR)) {}
        close(filedes[1]);
        close(filedes[0]);
        this->real_exec(smm.getArgv());
        throw SystemManagerException(strerror(errno));
    }
    close(filedes[1]);

    waitpid(pid, NULL, 0);
    // Parent process
    while (1) {
        ssize_t ret = read(filedes[0], buffer, sizeof(buffer));
        if (ret == -1) {
            if (errno == EINTR)
                continue;
            else
                throw SystemManagerException(strerror(errno));
        }
        else if (ret == 0) {
            break;
        }
        else {
            buffer[ret] = 0;
            ss << buffer;
        }
    }
    std::string str = ss.str();
    if (!str.empty() && str[str.length() - 1] == '\n')
        str.erase(str.length() - 1);
    return (str);
} // SystemManager::exec

void SystemManager::real_exec(std::vector<std::string> arr) {
    const char * argv[1024];
    size_t i = 0;

    if (arr.size() == 0)
        return;

    for (std::vector<std::string>::iterator it = arr.begin(); it != arr.end(); it++) {
        argv[i] = (*it).c_str();
        i++;
    }
    argv[i] = NULL;
    execv(argv[0], const_cast<char * const *>(argv));
}

/**
 * SystemManagerException declaration
 */

SystemManager::SystemManagerException::SystemManagerException(char * str)
    : msg(str)
{}

SystemManager::SystemManagerException::~SystemManagerException () throw () {}

SystemManager::SystemManagerException::SystemManagerException(const SystemManagerException & rhs) {
    *this = rhs;
}

SystemManager::SystemManagerException &SystemManager::SystemManagerException::operator=(
  SystemManagerException const &rhs) {
    // FIXME pretty poor
    this->msg = const_cast<char *>(std::string(rhs.msg).c_str());
    return *this;
}

const char * SystemManager::SystemManagerException::what() const throw () {
    return this->msg;
}

/**
 * SystemManagerMeta declaration
 */

SystemManager::SystemManagerMeta::SystemManagerMeta () {}

SystemManager::SystemManagerMeta::SystemManagerMeta (std::vector<std::string> argv)
    : argv(argv)
{}

SystemManager::SystemManagerMeta::SystemManagerMeta (SystemManagerMeta const & rhs) {
    *this = rhs;
}

SystemManager::SystemManagerMeta::~SystemManagerMeta () {}

SystemManager::SystemManagerMeta &SystemManager::SystemManagerMeta::operator=(
  SystemManagerMeta const & rhs) {
    this->argv = rhs.argv;
    return *this;
}

std::vector<std::string> SystemManager::SystemManagerMeta::getArgv() {
    return this->argv;
}
