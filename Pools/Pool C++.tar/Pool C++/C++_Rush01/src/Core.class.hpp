#ifndef CORE_HPP
#define CORE_HPP

#include <vector>
#include "AMonitorModule.class.hpp"
#include "SystemManager.class.hpp"
#include "Time.class.hpp"


class Core {
    public:

        Core(void);
        ~Core(void);


        void        loop(void);

        bool        createDisplay(std::string const &path);
        bool        createModule(std::string const &path);
        void        clearModule(void);
        bool        saveConfig(void);
        bool        updateTop(void);

    private:
        std::string _path;
        std::vector<AMonitorModule *> _module;
        IMonitorDisplay * _display;
        Time _tm;
        SystemManager _sm;
        std::string _bufferTop;
        unsigned long _lastTop;

        Core        &operator=(Core const &rhs);
        Core(Core const &src);
        bool        _writeModule(std::ofstream &of, AMonitorModule * module);
        bool        _createOneModule(std::string const &buffer);
        static const bool _debug;
};

#endif // ifndef CORE_HPP
