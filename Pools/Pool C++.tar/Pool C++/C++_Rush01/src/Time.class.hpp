#ifndef TIME_HPP
#define TIME_HPP

#include <sys/time.h>

class Time {
    public:

        Time(void);
        Time(Time const &src);
        ~Time(void);

        Time        &operator=(Time const &rhs);

        void                    update(void);

        float                   getTime(void) const;
        float                   getDeltaTime(void) const;
        float                   getCTime(void) const;
        float                   getCDeltaTime(void) const;
        float                   getCDeltaTime(int const) const;
        unsigned long           getTimestamp(void) const;
        static unsigned long    timestamp(struct timeval &tv);
    private:
        clock_t _c_clockLast;
        clock_t _c_clock;
        clock_t _c_ctime;

        struct timeval _step2;
        struct timeval _step;
        struct timeval _cur;

        unsigned long _frame;
        unsigned long _timestamp;
        float _deltaTime;
        float _cdeltaTime;
        float _ctime;
        float _time;
        unsigned int _fps;
        unsigned int _retFps; // Nb de FPS durant la dernière seconde

        void            _updateTimeFrameBased();
        void            _updateTimeClockBased();
        static const bool _debug;
};

#endif // ifndef TIME_HPP
