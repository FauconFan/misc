#include <iostream>
#include <string>
#include <sstream>
#include "MonitorNcurses.class.hpp"
#include "AMonitorModule.class.hpp"

MonitorNcurses::MonitorNcurses(Vector2D<int> const &position, Vector2D<int> const &percentSize) :
    _exit(false),
    _position(position),
    _indexUpDown(0) {
    if (MonitorNcurses::_debug)
        std::cout << "Ncurse:: Default constructor called." << std::endl;
    initscr();
    setlocale(LC_ALL, "");
    keypad(stdscr, TRUE);
    nodelay(stdscr, TRUE);
    cbreak();
    noecho();
    start_color();
    curs_set(0);
    init_pair(1, COLOR_RED, COLOR_BLACK);
    init_pair(2, COLOR_YELLOW, COLOR_BLACK);
    init_pair(3, COLOR_GREEN, COLOR_BLACK);
    init_pair(4, COLOR_CYAN, COLOR_BLACK);
    init_pair(5, COLOR_MAGENTA, COLOR_BLACK);
    init_pair(6, COLOR_MAGENTA, COLOR_GREEN);
    init_pair(7, COLOR_MAGENTA, COLOR_WHITE);

    this->_position = position;
    this->_winSize  = Vector2D<int>(COLS * percentSize.getX() / 100,
            LINES * percentSize.getY() / 100);
    this->_offset  = Vector2D<int>(1, 1);
    this->_mapSize = Vector2D<int>(this->_winSize.getX() - 2, this->_winSize.getY() - 2);

    this->_win = newwin(this->_winSize.getY(), this->_winSize.getX(), position.getY(),
            position.getX());
    box(this->_win, 0, 0);
}

MonitorNcurses::~MonitorNcurses(void) {
    if (MonitorNcurses::_debug)
        std::cout << "MonitorNcurses:: Destructor called." << std::endl;
    delwin(this->_win);
    endwin();
}

Vector2D<int>       MonitorNcurses::getMapSize(void) const {
    return (this->_mapSize);
}

Vector2D<int>       MonitorNcurses::getPosition(void) const {
    return (this->_position);
}

Vector2D<int>       MonitorNcurses::getWinSize(void) const {
    return (this->_winSize);
}

WINDOW              * MonitorNcurses::getWin(void) const {
    return (this->_win);
}

int MonitorNcurses::getIndexUpDown(void) const {
    return (this->_indexUpDown);
}

void MonitorNcurses::update(std::vector<AMonitorModule *> &module) {
    AMonitorModule * amodule;
    int key;
    Vector2D<int> savePosition;

    this->_save = false;
    try {
        amodule = module.at(this->_indexUpDown % module.size());
    } catch (std::exception const &e) {
        amodule = NULL;
    }
    werase(this->_win);
    if (amodule)
        savePosition = amodule->getPosition();
    key = getch();

    if (key == 27)
        this->_exit = true;
    if (key == KEY_UP)
        this->_indexUpDown++;
    if (key == KEY_DOWN && this->_indexUpDown > 0)
        this->_indexUpDown--;
    if (amodule && key == 'a')
        amodule->addPosition(Vector2D<int>(-1, 0));
    if (amodule && key == 'd')
        amodule->addPosition(Vector2D<int>(1, 0));
    if (amodule && key == 'w')
        amodule->addPosition(Vector2D<int>(0, -1));
    if (amodule && key == 's')
        amodule->addPosition(Vector2D<int>(0, 1));
    if (key == 'r')
        this->_save = true;
    if (amodule && !this->_inWin(amodule->getPosition(), amodule->getSize()))
        amodule->setPosition(savePosition);
} // MonitorNcurses::update

void MonitorNcurses::render(void) {
    box(this->_win, 0, 0);
    wrefresh(this->_win);
}

void MonitorNcurses::printString(Vector2D<int> position, std::string const &string) {
    mvwprintw(this->_win, position.getY() + this->_offset.getY(),
      position.getX() + this->_offset.getX(), string.c_str());
}

void MonitorNcurses::renderModule(AMonitorModule &module) {
    this->_renderBox(module.getSize(), module.getPosition(), module.isSelected());

    for (std::vector<Item *>::iterator it = module.getVectorItem().begin();
      it != module.getVectorItem().end(); it++)
    {
        if (dynamic_cast<ItemText *>(*it))
            this->_renderItem(module, dynamic_cast<ItemText *>(*it));
        if (dynamic_cast<ItemProgressBar *>(*it))
            this->_renderItem(module, dynamic_cast<ItemProgressBar *>(*it));
    }
}

void MonitorNcurses::_renderItem(AMonitorModule &module, ItemProgressBar * item) {
    Vector2D<int> renderPosition = module.getRelativePosition(item->getPosition()) + this->_offset;
    unsigned int length;

    length = (module.getSize().getX() + module.getPosition().getX() - renderPosition.getX() - 1);
    if (this->_inWin(renderPosition)) {
        wattron(this->_win, COLOR_PAIR(7));
        mvwprintw(this->_win,
          renderPosition.getY(),
          renderPosition.getX(),
          std::string(length, ' ').c_str());
        wattroff(this->_win, COLOR_PAIR(7));

        wattron(this->_win, COLOR_PAIR(6));
        mvwprintw(this->_win,
          renderPosition.getY(),
          renderPosition.getX(),
          std::string(length * item->getRatio(), ' ').c_str());
        wattroff(this->_win, COLOR_PAIR(6));
    }
}

void MonitorNcurses::_renderItem(AMonitorModule &module, ItemText * item) {
    Vector2D<int> renderPosition = module.getRelativePosition(item->getPosition()) + this->_offset;

    if (this->_inWin(renderPosition)) {
        mvwprintw(this->_win,
          renderPosition.getY(),
          renderPosition.getX(),
          item->getItemText().c_str());
    }
}

void MonitorNcurses::_renderBox(Vector2D<int> const &size, Vector2D<int> const &position,
  bool selected) {
    Vector2D<int> renderPosition;
    std::string border;

    renderPosition = Vector2D<int>(position.getX() + this->_offset.getX(),
            position.getY() + this->_offset.getY());
    border    = std::string(size.getX(), ' ');
    border[0] = '#';
    border[border.length() - 1] = '#';

    if (selected)
        wattron(this->_win, COLOR_PAIR(3));
    if (this->_inWin(renderPosition)) {
        for (int i = 0; i < size.getY() && renderPosition.getY() + i < this->_winSize.getY(); i++) {
            if (!i || i + 1 >= size.getY()) {
                mvwprintw(this->_win, renderPosition.getY() + i, renderPosition.getX(),
                  std::string(size.getX(), '#').c_str());
            }
            else {
                mvwprintw(this->_win, renderPosition.getY() + i, renderPosition.getX(),
                  border.c_str());
            }
        }
    }
    if (selected)
        wattroff(this->_win, COLOR_PAIR(3));
}

// BASIC CHECK
bool MonitorNcurses::_inWin(Vector2D<int> const &renderPosition) const {
    if (renderPosition.getY() > 0 &&
      renderPosition.getY() < this->_winSize.getY() &&
      renderPosition.getX() > 0 &&
      renderPosition.getX() < this->_winSize.getX())
    {
        return (true);
    }
    return (false);
}

bool MonitorNcurses::_inWin(Vector2D<int> const &renderPosition,
  Vector2D<int> const                           &renderSize) const {
    if (renderPosition.getY() >= 0 &&
      renderPosition.getY() + renderSize.getY() < this->_winSize.getY() - 1 &&
      renderPosition.getX() >= 0 &&
      renderPosition.getX() + renderSize.getX() < this->_winSize.getX() - 1)
    {
        return (true);
    }
    return (false);
}

bool MonitorNcurses::exit(void) const {
    return (this->_exit);
}

bool MonitorNcurses::save(void) const {
    return (this->_save);
}

const bool MonitorNcurses::_debug = 0;
