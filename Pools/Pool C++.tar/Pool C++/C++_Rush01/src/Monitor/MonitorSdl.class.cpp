/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   MonitorSdl.class.cpp                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 01:38:38 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 22:08:25 by ntoniolo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "MonitorSdl.class.hpp"
#include "AMonitorModule.class.hpp"

#define FONT_PATH "resources/OpenSans-Regular.ttf"

MonitorSdl::MonitorSdl(unsigned int width, unsigned int height, char const * windowName) :
    _indexUpDown(0),
    _exit(false),
    _winSize(Vector2D<int>(width, height)),
    _win(NULL),
    _renderSurface(NULL),
    _renderTexture(NULL),
    _render(NULL),
    _font(NULL) {
    if (MonitorSdl::_debug)
        std::cout << "Sdl:: Default constructor called." << std::endl;

    if (SDL_Init(SDL_INIT_VIDEO) < 0 || TTF_Init() < 0)
        this->_error();

    if (!(this->_win = SDL_CreateWindow(windowName, SDL_WINDOWPOS_CENTERED,
            SDL_WINDOWPOS_CENTERED, this->_winSize.getX(), this->_winSize.getY(),
            SDL_WINDOW_SHOWN)))
        this->_error();

    if (!(this->_render = SDL_CreateRenderer(this->_win, -1, SDL_RENDERER_ACCELERATED)))
        this->_error();

    if (!(this->_renderSurface =
      SDL_CreateRGBSurface(0, this->_winSize.getX(), this->_winSize.getY(), 32, 0xff000000,
              0x00ff0000, 0x0000ff00, 0x000000ff)))
        this->_error();
    this->setFont(FONT_PATH);
    this->setFontSize(TTF_FONT_SIZE);
    this->_themeBorder     = 0x808080FF;
    this->_themeBackground = 0x606060FF;
    this->_themeSelected   = 0xCCCCCCFF;
}

MonitorSdl::~MonitorSdl(void) {
    if (MonitorSdl::_debug)
        std::cout << "MonitorSdl:: Destructor called." << std::endl;
    this->_cleanSdlEnv();
}

void MonitorSdl::_error(void) {
    this->_cleanSdlEnv();
    throw(MonitorSdl::SdlConstructorException(SDL_GetError()));
}

int MonitorSdl::getIndexUpDown(void) const {
    return (this->_indexUpDown);
}

void MonitorSdl::_cleanSdlEnv(void) {
    if (this->_win) {
        SDL_DestroyWindow(this->_win);
        this->_win = NULL;
    }
    if (this->_renderSurface) {
        SDL_FreeSurface(this->_renderSurface);
        this->_renderSurface = NULL;
    }
    if (this->_renderTexture) {
        SDL_DestroyTexture(this->_renderTexture);
        this->_renderTexture = NULL;
    }
    if (this->_render) {
        SDL_DestroyRenderer(this->_render);
        this->_render = NULL;
    }
    if (this->_font)
        TTF_CloseFont(this->_font);

    TTF_Quit();
    SDL_Quit();
}

void MonitorSdl::render(void) {
    if (this->_renderTexture)
        SDL_DestroyTexture(this->_renderTexture);
    this->_renderTexture = SDL_CreateTextureFromSurface(this->_render, this->_renderSurface);
    SDL_RenderCopy(this->_render, this->_renderTexture, NULL, NULL);
    SDL_RenderPresent(this->_render);
    SDL_SetRenderDrawColor(this->_render, 0, 0, 0, 255);
    SDL_RenderClear(this->_render);
    SDL_FillRect(this->_renderSurface, NULL, 0x000000FF);
}

Vector2D<int>   MonitorSdl::toSdl(Vector2D<int> const &v) {
    return (Vector2D<int>(v.getX() * TTF_FONT_SIZE / 2, v.getY() * TTF_FONT_SIZE));
}

void MonitorSdl::update(std::vector<AMonitorModule *> &module) {
    Vector2D<int> savePosition;
    AMonitorModule * amodule;


    this->_save = false;
    try {
        amodule = module.at(this->_indexUpDown % module.size());
    } catch (std::exception const &e) {
        amodule = NULL;
    }
    if (amodule)
        savePosition = amodule->getPosition();
    while (SDL_PollEvent(&this->_ev)) {
        if (this->_ev.window.event == SDL_WINDOWEVENT_CLOSE)
            this->_exit = true;
        if (this->_ev.type == SDL_KEYDOWN) {
            if (this->_ev.key.keysym.scancode == SDL_SCANCODE_UP)
                this->_indexUpDown++;
            else if (this->_ev.key.keysym.scancode == SDL_SCANCODE_DOWN && this->_indexUpDown > 0)
                this->_indexUpDown--;
            else if (this->_ev.key.keysym.scancode == SDL_SCANCODE_Q)
                this->_exit = true;
            else if (this->_ev.key.keysym.scancode == SDL_SCANCODE_R)
                this->_save = true;
            else if (amodule && this->_ev.key.keysym.scancode == SDL_SCANCODE_A)
                amodule->addPosition(Vector2D<int>(-2, 0));
            else if (amodule && this->_ev.key.keysym.scancode == SDL_SCANCODE_D)
                amodule->addPosition(Vector2D<int>(2, 0));
            else if (amodule && this->_ev.key.keysym.scancode == SDL_SCANCODE_W)
                amodule->addPosition(Vector2D<int>(0, -2));
            else if (amodule && this->_ev.key.keysym.scancode == SDL_SCANCODE_S)
                amodule->addPosition(Vector2D<int>(0, 2));
        }

        if (amodule &&
          !this->_inWin(MonitorSdl::toSdl(amodule->getPosition()),
          MonitorSdl::toSdl(amodule->getSize())))
            amodule->setPosition(savePosition);
    }
} // MonitorSdl::update

void MonitorSdl::renderModule(AMonitorModule &module) {
    this->_renderBox(module);

    for (std::vector<Item *>::iterator it = module.getVectorItem().begin();
      it != module.getVectorItem().end(); it++)
    {
        if (dynamic_cast<ItemProgressBar *>(*it))
            this->_renderItem(module, dynamic_cast<ItemProgressBar *>(*it));
        if (dynamic_cast<ItemText *>(*it))
            this->_renderItem(module, dynamic_cast<ItemText *>(*it));
    }
}

void MonitorSdl::_renderItem(AMonitorModule &module, ItemProgressBar * item) {
    Vector2D<int> renderPosition =
      MonitorSdl::toSdl(module.getRelativePosition(item->getPosition()));
    SDL_Rect rect;

    rect.x = renderPosition.getX();
    rect.y = renderPosition.getY() - TTF_FONT_SIZE;
    rect.w = MonitorSdl::toSdl(module.getSize()).getX()
      - (renderPosition.getX() - MonitorSdl::toSdl(module.getPosition()).getX()) - TTF_PADDING;
    rect.h = TTF_FONT_SIZE;

    SDL_FillRect(this->_renderSurface, &rect, 0xFFFF00FF);
    rect.w *= item->getRatio();
    SDL_FillRect(this->_renderSurface, &rect, 0xFF00FFFF);
}

void MonitorSdl::_renderItem(AMonitorModule &module, ItemText * item) {
    Vector2D<int> renderPosition =
      MonitorSdl::toSdl(module.getRelativePosition(item->getPosition()));
    SDL_Surface * surface;
    SDL_Rect rect;

    if ((surface = TTF_RenderText_Blended(this->_font, item->getItemText().c_str(), SDL_Color()))) {
        rect.x = renderPosition.getX();
        rect.y = renderPosition.getY() - TTF_FONT_SIZE;
        SDL_BlitSurface(surface, NULL, this->_renderSurface, &rect);
        SDL_FreeSurface(surface);
    }
}

void MonitorSdl::_renderBox(AMonitorModule &module) {
    SDL_Rect rect = MonitorSdl::_moduleToRect(module);

    rect.x -= 2;
    rect.y -= 2;
    rect.w += 4;
    rect.h += 4;
    if (module.isSelected())
        SDL_FillRect(this->_renderSurface, &rect, this->_themeSelected);
    else
        SDL_FillRect(this->_renderSurface, &rect, this->_themeBorder);
    rect = MonitorSdl::_moduleToRect(module);
    SDL_FillRect(this->_renderSurface, &rect, this->_themeBackground);
}

SDL_Rect MonitorSdl::_moduleToRect(AMonitorModule &module) {
    SDL_Rect rect;

    rect.x = MonitorSdl::toSdl(module.getPosition()).getX();
    rect.y = MonitorSdl::toSdl(module.getPosition()).getY();
    rect.w = MonitorSdl::toSdl(module.getSize()).getX();
    rect.h = MonitorSdl::toSdl(module.getSize()).getY();
    return (rect);
}

SDL_Surface * MonitorSdl::SdlSurface(unsigned int widht, unsigned int height) {
    return (SDL_CreateRGBSurface(0, widht, height,
            32, 0xff000000, 0x00ff0000, 0x0000ff00, 0x000000ff));
}

bool MonitorSdl::exit(void) const {
    return (this->_exit);
}

bool MonitorSdl::save(void) const {
    return (this->_save);
}

void MonitorSdl::setFont(std::string font_file) {
    if (this->_font)
        TTF_CloseFont(this->_font);
    this->_fontPath = font_file;
    this->_font     = TTF_OpenFont(this->_fontPath.c_str(), this->_fontSize);
    if (this->_font == NULL)
        throw(std::invalid_argument("Cannot set the font"));
}

void MonitorSdl::setFontSize(int font_size) {
    if (this->_fontSize == font_size)
        return;

    this->_fontSize = font_size;
    if (this->_font)
        TTF_CloseFont(this->_font);
    this->_font = TTF_OpenFont(this->_fontPath.c_str(), font_size);
    if (this->_font == NULL)
        throw(std::invalid_argument("Cannot set the font"));
}

bool MonitorSdl::_inWin(Vector2D<int> const &renderPosition) const {
    if (renderPosition.getY() > 0 &&
      renderPosition.getY() < this->_winSize.getY() &&
      renderPosition.getX() > 0 &&
      renderPosition.getX() < this->_winSize.getX())
    {
        return (true);
    }
    return (false);
}

bool MonitorSdl::_inWin(Vector2D<int> const &renderPosition,
  Vector2D<int> const                       &renderSize) const {
    if (renderPosition.getY() >= 0 &&
      renderPosition.getY() + renderSize.getY() < this->_winSize.getY() - 1 &&
      renderPosition.getX() >= 0 &&
      renderPosition.getX() + renderSize.getX() < this->_winSize.getX() - 1)
    {
        return (true);
    }
    return (false);
}

MonitorSdl::SdlConstructorException::~SdlConstructorException(void) throw() {}

MonitorSdl::SdlConstructorException::SdlConstructorException(void) throw() :
    _error("Error on Sdl constructor") {}

MonitorSdl::SdlConstructorException::SdlConstructorException(std::string const &s) throw() :
    _error(s) {}

MonitorSdl::SdlConstructorException::SdlConstructorException(
  MonitorSdl::SdlConstructorException const &src) throw()
{this->_error = src._error;}

const char  * MonitorSdl::SdlConstructorException::what() const throw()
{return (this->_error.c_str());}

const bool MonitorSdl::_debug = 0;
