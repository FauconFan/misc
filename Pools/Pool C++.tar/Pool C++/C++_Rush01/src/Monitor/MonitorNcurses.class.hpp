#ifndef MonitorNcurses_HPP
#define MonitorNcurses_HPP

#include <curses.h>
#include <vector>
#include "Vector2D.interface.hpp"
#include "IMonitorDisplay.interface.hpp"

class AMonitorModule;
class ItemText;
class ItemProgressBar;

class MonitorNcurses : public IMonitorDisplay {
    public:

        MonitorNcurses(Vector2D<int> const &position, Vector2D<int> const &percentSize);
        MonitorNcurses(void);
        virtual ~MonitorNcurses(void);

        bool            save(void) const;
        bool            exit(void) const;
        Vector2D<int>   getMapSize(void) const;
        Vector2D<int>   getPosition(void) const;
        Vector2D<int>   getWinSize(void) const;
        WINDOW * getWin(void) const;
        int             getIndexUpDown(void) const;
        void        render(void);
        void        update(std::vector<AMonitorModule *> &module);

        void        renderModule(AMonitorModule &mt);
        void        printString(Vector2D<int> position, std::string const &string);

    private:
        bool _save;
        bool _exit;
        WINDOW * _win;
        Vector2D<int> _position;
        Vector2D<int> _winSize;
        Vector2D<int> _offset;
        Vector2D<int> _mapSize;

        Vector2D<int> _index;
        std::vector<Vector2D<int> > _box;
        int _indexUpDown;

        void        _renderBox(Vector2D<int> const &size, Vector2D<int> const &position,
            bool selected);
        void        _renderItem(AMonitorModule &module, ItemProgressBar * item);
        void        _renderItem(AMonitorModule &module, ItemText * item);
        bool        _inWin(Vector2D<int> const &renderPosition) const;
        bool        _inWin(Vector2D<int> const &renderPosition,
            Vector2D<int> const                &renderSize) const;

        MonitorNcurses(MonitorNcurses const &src);
        MonitorNcurses      &operator=(MonitorNcurses const &rhs);

        static const bool _debug;
};

#endif // ifndef MonitorNcurses_HPP
