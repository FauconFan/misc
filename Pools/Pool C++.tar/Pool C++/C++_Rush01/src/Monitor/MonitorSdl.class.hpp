/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   MonitorSdl.class.hpp                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 01:39:05 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 22:07:37 by ntoniolo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MONITORSDL_HPP
#define MONITORSDL_HPP

#include <exception>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include "IMonitorDisplay.interface.hpp"
#include "Vector2D.interface.hpp"

class AMonitorModule;
class ItemProgressBar;
class ItemText;

#define TTF_FONT_SIZE 16
#define TTF_PADDING   4

class MonitorSdl : public IMonitorDisplay {
    public:
        class SdlConstructorException : public std::exception {
            public:
                SdlConstructorException(void) throw();
                SdlConstructorException(std::string const &) throw();
                virtual const char * what() const throw();
                ~SdlConstructorException(void) throw();
                SdlConstructorException(SdlConstructorException const &src) throw();
            private:
                SdlConstructorException &operator=(SdlConstructorException const &rhs) throw();
                std::string _error;
        };

        MonitorSdl(unsigned int width, unsigned int height, char const * windowName);
        virtual ~MonitorSdl(void);

        void        setFont(std::string font_file);
        void        setFontSize(int font_size);


        bool        save(void) const;
        bool        exit(void) const;
        void        render(void);
        void        update(std::vector<AMonitorModule *> &module);
        void        renderModule(AMonitorModule &mt);
        int         getIndexUpDown(void) const;

        static SDL_Surface * SdlSurface(unsigned int widht, unsigned int height);
    private:
        int _indexUpDown;
        bool _save;
        bool _exit;
        Vector2D<int> const _winSize;

        SDL_Window * _win;
        SDL_Surface * _renderSurface;
        SDL_Texture * _renderTexture;
        SDL_Renderer * _render;
        SDL_Event _ev;
        int _themeBorder;
        int _themeBackground;
        int _themeSelected;

        TTF_Font * _font;
        std::string _fontPath;
        int _fontSize;

        void                _renderItem(AMonitorModule &module, ItemProgressBar * bar);
        void                _renderItem(AMonitorModule &module, ItemText * text);
        void                _renderBox(AMonitorModule &module);
        void                _error(void);
        void                _cleanSdlEnv(void);

        MonitorSdl          &operator=(MonitorSdl const &rhs);
        MonitorSdl(MonitorSdl const &src);
        MonitorSdl(void);

        bool                _inWin(Vector2D<int> const &renderPosition) const;
        bool                _inWin(Vector2D<int> const &renderPosition,
            Vector2D<int> const                        &renderSize) const;

        static Vector2D<int>    toSdl(Vector2D<int> const &v);
        static SDL_Rect         _moduleToRect(AMonitorModule &module);
        static const bool _debug;
};

#endif // ifndef MONITORSDL_HPP
