/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   IMonitorDisplay.interface.hpp                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/13 08:22:15 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/14 22:09:35 by ntoniolo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef IMONITORDISPLAY_HPP
#define IMONITORDISPLAY_HPP

#include <vector>

/**
 * IMonitorDisplay, which describes the behavior of a display mode. IMonitorDisplay
 * is an abstraction between the two available displays. Thus, at least two class should
 * implement this interface : the class that handles the shell UI and the one that handles
 * the graphical UI.
 */
class AMonitorModule;


class IMonitorDisplay {
    public:
        virtual ~IMonitorDisplay () {}

        virtual bool        exit(void) const = 0;
        virtual bool        save(void) const = 0;
        virtual void        render(void)     = 0;
        virtual void        update(std::vector<AMonitorModule *> &module) = 0;
        virtual void        renderModule(AMonitorModule &mt) = 0;
        virtual int         getIndexUpDown(void) const       = 0;
};

#endif // ifndef IMONITORDISPLAY_HPP
