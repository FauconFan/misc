/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ModuleHostname.class.cpp                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 01:38:41 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 23:17:27 by ntoniolo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "ModuleHostname.class.hpp"
#include "SystemManager.class.hpp"

ModuleHostname::ModuleHostname(SystemManager &sm, Vector2D<int> const &position) :
    AMonitorModule(Vector2D<int>(15, 5), position,
      false, 0) {
    if (ModuleHostname::_debug)
        std::cout << "ModuleHostname:: Default constructor called." << std::endl;
    this->_getModule(sm);
}

ModuleHostname::~ModuleHostname(void) {
    if (ModuleHostname::_debug)
        std::cout << "ModuleHostname:: Destructor called." << std::endl;
}

void ModuleHostname::_getModule(SystemManager &sm) {
    this->clearItem();
    std::string str = sm.exec(HOSTNAME_CMD).substr(0, 15 - 3);
    this->addItem(new ItemText("Hostname:", 1));
    this->addItem(new ItemText(str, Vector2D<int>(1, 3)));
}

const bool ModuleHostname::_debug = 0;
