/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ModuleDate.class.hpp                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 01:39:19 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 18:41:39 by ntoniolo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MODULEDATE_HPP
#define MODULEDATE_HPP

#include "AMonitorModule.class.hpp"

class SystemManager;

class ModuleDate : public AMonitorModule {
    public:

        ModuleDate(SystemManager &sm, Vector2D<int> const &position);
        ModuleDate(void);
        ~ModuleDate(void);
    private:
        void        _getModule(SystemManager &sm);

        ModuleDate(ModuleDate const &src);
        ModuleDate      &operator=(ModuleDate const &rhs);

        static const bool _debug;
};

#endif // ifndef MODULEDATE_HPP
