/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   AMonitorModule.class.cpp                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 01:38:54 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 22:47:02 by ntoniolo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "AMonitorModule.class.hpp"
#include <sstream>
#include "Time.class.hpp"

AMonitorModule::AMonitorModule(void) {
    if (AMonitorModule::_debug)
        std::cout << "AMonitorModule:: Default constructor called." << std::endl;
}

AMonitorModule::AMonitorModule(Vector2D<int> size, Vector2D<int> position,
  bool selected, unsigned int refresh) :
    _size(size),
    _position(position),
    _selected(selected),
    _refresh(refresh),
    _lastRefresh(0) {
    if (AMonitorModule::_debug)
        std::cout << "AMonitorModule:: All constructor called." << std::endl;
}

AMonitorModule::~AMonitorModule(void) {
    if (AMonitorModule::_debug)
        std::cout << "AMonitorModule:: Destructor called." << std::endl;
    this->clearItem();
}

void AMonitorModule::addItem(Item * t) {
    this->_item.push_back(t);
}

void AMonitorModule::clearItem(void) {
    for (std::vector<Item *>::iterator it = this->_item.begin();
      it != this->_item.end(); it++)
    {
        delete *it;
    }
    this->_item.clear();
}

std::vector<Item *>         &AMonitorModule::getVectorItem(void) {
    return (this->_item);
}

Vector2D<int> const         &AMonitorModule::getSize(void) const {
    return (this->_size);
}

Vector2D<int> const         &AMonitorModule::getPosition(void) const {
    return (this->_position);
}

/*
 * Vector2D<int>			AMonitorModule::getSdlSize(void) const
 * {
 *  return (Vector2D<int>(this->_ncursesSize.getX() * TTF_FONT_SIZE / 2, this->_ncursesSize.getY() * TTF_FONT_SIZE));
 *  //return (this->_sdlSize);
 * }
 * Vector2D<int>			AMonitorModule::getSdlPosition(void) const
 * {
 *  return (Vector2D<int>(this->_position.getX() * TTF_FONT_SIZE / 2, this->_position.getY() * TTF_FONT_SIZE));
 *  //return (this->_sdlPosition);
 * }*/
bool AMonitorModule::isSelected(void) const {
    return (this->_selected);
}

unsigned int AMonitorModule::getRefresh(void) const {
    return (this->_refresh);
}

void AMonitorModule::addPosition(Vector2D<int> const &add) {
    this->_position += add;
}

void AMonitorModule::setPosition(Vector2D<int> const &add) {
    this->_position = add;
}

Vector2D<int>  AMonitorModule::getRelativePosition(Vector2D<int> position) {
    return (this->_position + position);
}

void AMonitorModule::update(SystemManager &sm, bool selected, Time const &time) {
    this->_selected = selected;
    if (this->_refresh && time.getTimestamp() > this->_lastRefresh + this->_refresh) {
        this->_lastRefresh = time.getTimestamp();
        this->_getModule(sm);
    }
}

std::vector<std::string> AMonitorModule::_splitString(const std::string &str) {
    return _splitStringOnString(str, "\n");
}

std::vector<std::string> AMonitorModule::_splitStringOnString(const std::string &str,
  const std::string                                                             &delim) {
    std::vector<std::string> ret;
    std::string copy(str);
    size_t pos = 0;
    std::string token;

    while ((pos = copy.find(delim)) != std::string::npos) {
        token = copy.substr(0, pos);
        ret.push_back(token);
        copy.erase(0, pos + delim.length());
    }
    ret.push_back(copy);
    return ret;
}

std::string AMonitorModule::_trimString(const std::string &str) {
    std::string cpy(str);

    return cpy.erase(0, cpy.find_first_not_of(' '));
}

const bool AMonitorModule::_debug = 0;
