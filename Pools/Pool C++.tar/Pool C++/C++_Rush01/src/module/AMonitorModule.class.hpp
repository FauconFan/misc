/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   AMonitorModule.class.hpp                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 01:39:26 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 20:10:37 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef AMONITORMODULE_HPP
#define AMONITORMODULE_HPP

#include "IMonitorModule.interface.hpp"
#include "ItemText.class.hpp"
#include "ItemProgressBar.class.hpp"
#include <vector>

class AMonitorModule : public IMonitorModule {
    public:

        AMonitorModule(Vector2D<int> size, Vector2D<int> position,
            bool selected, unsigned int refresh);
        AMonitorModule(void);
        ~AMonitorModule(void);

        void                        addItem(Item *);
        void                        clearItem(void);

        std::vector<Item *>         &getVectorItem(void);
        Vector2D<int> const         &getSize(void) const;
        Vector2D<int> const         &getPosition(void) const;
        bool                        isSelected(void) const;
        unsigned int                getRefresh(void) const;

        void                        addPosition(Vector2D<int> const &add);
        void                        setPosition(Vector2D<int> const &add);

        Vector2D<int>               getRelativePosition(Vector2D<int> position);

        void                        update(SystemManager &sm, bool selected, Time const &time);
    protected:
        Vector2D<int> _size;
        Vector2D<int> _position;
        std::vector<Item *> _item;
        bool _selected;
        unsigned int _refresh;
        unsigned long _lastRefresh;

        static std::vector<std::string> _splitString(const std::string &str);
        static std::vector<std::string> _splitStringOnString(const std::string &str,
            const std::string                                                  &delim);
        static std::string              _trimString(const std::string &str);

    private:
        AMonitorModule(AMonitorModule const &src);
        AMonitorModule      &operator=(AMonitorModule const &rhs);

        static const bool _debug;
};

#endif // ifndef AMONITORMODULE_HPP
