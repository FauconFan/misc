/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ModuleLoadAvg.class.hpp                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 01:39:15 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 20:25:45 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MODULELOADAVG_HPP
#define MODULELOADAVG_HPP

#include "AMonitorModule.class.hpp"

class SystemManager;

class ModuleLoadAvg : public AMonitorModule {
    public:

        ModuleLoadAvg(SystemManager &sm, Vector2D<int> const &position);
        ModuleLoadAvg(void);
        ~ModuleLoadAvg(void);

    private:
        void        _getModule(SystemManager &sm);

        ModuleLoadAvg(ModuleLoadAvg const &src);
        ModuleLoadAvg       &operator=(ModuleLoadAvg const &rhs);

        static const bool _debug;
};

#endif // ifndef MODULELOADAVG_HPP
