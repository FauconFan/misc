/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ModuleWhoAMi.class.hpp                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 23:20:33 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 23:20:34 by ntoniolo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MODULEWHOAIMI_HPP
#define MODULEWHOAIMI_HPP

#include "AMonitorModule.class.hpp"

class SystemManager;

class ModuleWhoAMi : public AMonitorModule {
    public:

        ModuleWhoAMi(SystemManager &sm, Vector2D<int> const &position);
        ModuleWhoAMi(void);
        ~ModuleWhoAMi(void);

    private:
        void        _getModule(SystemManager &sm);

        ModuleWhoAMi(ModuleWhoAMi const &src);
        ModuleWhoAMi        &operator=(ModuleWhoAMi const &rhs);

        static const bool _debug;
};

#endif // ifndef MODULEWHOAIMI_HPP
