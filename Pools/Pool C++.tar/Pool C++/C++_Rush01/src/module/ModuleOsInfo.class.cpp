/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ModuleOsInfo.class.cpp                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 01:38:50 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 21:40:54 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "ModuleOsInfo.class.hpp"
#include "SystemManager.class.hpp"
#include "MonitorSdl.class.hpp"

ModuleOsInfo::ModuleOsInfo(SystemManager &sm, Vector2D<int> const &position) :
    AMonitorModule(Vector2D<int>(50, 7), position,
      false, 0) {
    if (ModuleOsInfo::_debug)
        std::cout << "ModuleOsInfo:: Default constructor called." << std::endl;
    this->_getModule(sm);
}

ModuleOsInfo::~ModuleOsInfo(void) {
    if (ModuleOsInfo::_debug)
        std::cout << "ModuleOsInfo:: Destructor called." << std::endl;
}

void ModuleOsInfo::_getModule(SystemManager &sm) {
    std::string str = sm.exec(OSINFO_CMD);

    std::vector<std::string> ret = AMonitorModule::_splitString(str);

    this->clearItem();

    this->addItem(new ItemText("OsInfo:", 1));
    this->addItem(new ItemText(ret[0].substr(0, 50 - 3), Vector2D<int>(2, 3)));
    this->addItem(new ItemText(ret[1].substr(0, 50 - 3), Vector2D<int>(2, 4)));
    this->addItem(new ItemText(ret[2].substr(0, 50 - 3), Vector2D<int>(2, 5)));
}

const bool ModuleOsInfo::_debug = 0;
