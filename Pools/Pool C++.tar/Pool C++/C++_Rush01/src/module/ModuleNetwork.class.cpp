/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ModuleNetwork.class.cpp                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 01:38:50 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 22:09:59 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "ModuleNetwork.class.hpp"
#include "SystemManager.class.hpp"

ModuleNetwork::ModuleNetwork(SystemManager &sm, Vector2D<int> const &position) :
    AMonitorModule(Vector2D<int>(30, 7), position,
      false, 1000) {
    if (ModuleNetwork::_debug)
        std::cout << "ModuleNetwork:: Default constructor called." << std::endl;
    this->_getModule(sm);
}

ModuleNetwork::~ModuleNetwork(void) {
    if (ModuleNetwork::_debug)
        std::cout << "ModuleNetwork:: Destructor called." << std::endl;
}

void ModuleNetwork::_getModule(SystemManager &sm) {
    std::string top = sm.exec(TOP_HEAD);

    std::vector<std::string> ret = AMonitorModule::_splitString(top);
    std::string str = ret[8];

    str.erase(0, 18);

    std::vector<std::string> elems = AMonitorModule::_splitStringOnString(str, ", ");

    elems[0] = AMonitorModule::_trimString(elems[0]);

    this->clearItem();

    this->addItem(new ItemText("Networks:", 1));
    this->addItem(new ItemText(elems[0].substr(0, 30 - 2), Vector2D<int>(2, 3)));
    this->addItem(new ItemText(elems[1].substr(0, 30 - 2), Vector2D<int>(2, 4)));
}

const bool ModuleNetwork::_debug = 0;
