/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ModuleNetwork.class.hpp                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 01:39:15 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 22:06:25 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MODULENETWORK_HPP
#define MODULENETWORK_HPP

#include "AMonitorModule.class.hpp"

class SystemManager;

class ModuleNetwork : public AMonitorModule {
    public:

        ModuleNetwork(SystemManager &sm, Vector2D<int> const &position);
        ModuleNetwork(void);
        ~ModuleNetwork(void);

    private:
        void        _getModule(SystemManager &sm);

        ModuleNetwork(ModuleNetwork const &src);
        ModuleNetwork       &operator=(ModuleNetwork const &rhs);

        static const bool _debug;
};

#endif // ifndef MODULENETWORK_HPP
