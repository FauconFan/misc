/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ModuleProcesses.class.hpp                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 01:39:15 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 19:37:56 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MODULEPROCESSES_HPP
#define MODULEPROCESSES_HPP

#include "AMonitorModule.class.hpp"

class SystemManager;

class ModuleProcesses : public AMonitorModule {
    public:

        ModuleProcesses(SystemManager &sm, Vector2D<int> const &position);
        ModuleProcesses(void);
        ~ModuleProcesses(void);

    private:
        void        _getModule(SystemManager &sm);

        ModuleProcesses(ModuleProcesses const &src);
        ModuleProcesses     &operator=(ModuleProcesses const &rhs);

        static const bool _debug;
};

#endif // ifndef MODULEPROCESSES_HPP
