/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ModuleDate.class.cpp                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 01:40:42 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 18:58:26 by ntoniolo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "ModuleDate.class.hpp"
#include "SystemManager.class.hpp"

ModuleDate::ModuleDate(SystemManager &sm, Vector2D<int> const &position) :
    AMonitorModule(Vector2D<int>(34, 5), position,
      false, 10) {
    if (ModuleDate::_debug)
        std::cout << "ModuleDate:: Default constructor called." << std::endl;
    this->_getModule(sm);
}

ModuleDate::~ModuleDate(void) {
    if (ModuleDate::_debug)
        std::cout << "ModuleDate:: Destructor called." << std::endl;
}

void ModuleDate::_getModule(SystemManager &sm) {
    this->clearItem();
    std::string str = sm.exec(DATE_CMD).substr(0, 32);
    this->addItem(new ItemText("Date:", 1));
    this->addItem(new ItemText(str, Vector2D<int>(2, 3)));
}

const bool ModuleDate::_debug = 0;
