/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ModuleHostname.class.hpp                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 01:39:08 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 18:42:05 by ntoniolo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MODULEHOSTNAME_HPP
#define MODULEHOSTNAME_HPP

#include "AMonitorModule.class.hpp"

class SystemManager;

class ModuleHostname : public AMonitorModule {
    public:

        ModuleHostname(SystemManager &sm, Vector2D<int> const &position);
        ModuleHostname(void);
        ~ModuleHostname(void);

    private:
        void        _getModule(SystemManager &sm);

        ModuleHostname(ModuleHostname const &src);
        ModuleHostname      &operator=(ModuleHostname const &rhs);

        static const bool _debug;
};

#endif // ifndef MODULEHOSTNAME_HPP
