/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ModuleCpu.class.cpp                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 16:06:00 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 23:12:41 by ntoniolo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <sstream>
#include "ModuleCpu.class.hpp"
#include "SystemManager.class.hpp"
#include "ItemProgressBar.class.hpp"

ModuleCpu::ModuleCpu(SystemManager &sm, Vector2D<int> const &position) :
    AMonitorModule(Vector2D<int>(34, 12), position,
      false, 200) {
    if (ModuleCpu::_debug)
        std::cout << "ModuleCpu:: Default constructor called." << std::endl;
    this->_getModule(sm);
}

ModuleCpu::~ModuleCpu(void) {
    if (ModuleCpu::_debug)
        std::cout << "ModuleCpu:: Destructor called." << std::endl;
}

void ModuleCpu::_getModule(SystemManager &sm) {
    std::string top = sm.exec(TOP_HEAD);

    std::vector<std::string> ret = AMonitorModule::_splitString(top);
    std::string str = ret[3];

    str.erase(0, 10);

    std::vector<std::string> elems = AMonitorModule::_splitStringOnString(str, ", ");

    this->clearItem();

    this->addItem(new ItemText("CPU usage", 1));
    size_t line = 2;
    for (std::vector<std::string>::iterator it = elems.begin(); it != elems.end(); it++) {
        float f;
        std::vector<std::string> delires = AMonitorModule::_splitStringOnString(*it, "% ");
        std::stringstream ss;

        ss << delires[0];
        ss >> f;

        this->addItem(new ItemText(delires[1], Vector2D<int>(2, line)));
        line += 2;
        this->addItem(new ItemProgressBar(f / 100.f, Vector2D<int>(1, line)));
        line++;
    }
}

const bool ModuleCpu::_debug = 0;
