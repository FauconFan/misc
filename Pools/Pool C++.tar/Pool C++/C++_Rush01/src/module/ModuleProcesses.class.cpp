/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ModuleProcesses.class.cpp                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 01:38:50 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 20:10:52 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "ModuleProcesses.class.hpp"
#include "SystemManager.class.hpp"

ModuleProcesses::ModuleProcesses(SystemManager &sm, Vector2D<int> const &position) :
    AMonitorModule(Vector2D<int>(50, 9), position,
      false, 1000) {
    if (ModuleProcesses::_debug)
        std::cout << "ModuleProcesses:: Default constructor called." << std::endl;
    this->_getModule(sm);
}

ModuleProcesses::~ModuleProcesses(void) {
    if (ModuleProcesses::_debug)
        std::cout << "ModuleProcesses:: Destructor called." << std::endl;
}

void ModuleProcesses::_getModule(SystemManager &sm) {
    std::string top = sm.exec(TOP_HEAD);

    std::vector<std::string> ret = AMonitorModule::_splitString(top);
    std::string str = ret[0];

    str.erase(0, 10);

    std::vector<std::string> elems = AMonitorModule::_splitStringOnString(str, ", ");
    this->clearItem();

    this->addItem(new ItemText("Processes:", 1));
    size_t line = 3;
    for (std::vector<std::string>::iterator it = elems.begin(); it != elems.end(); it++) {
        *it = AMonitorModule::_trimString(*it);
        this->addItem(new ItemText(" " + (*it).substr(0, 50 - 4), Vector2D<int>(2, line)));
        line++;
    }
}

const bool ModuleProcesses::_debug = 0;
