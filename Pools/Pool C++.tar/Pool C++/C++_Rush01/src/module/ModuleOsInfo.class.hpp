/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ModuleOsInfo.class.hpp                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 01:39:15 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 18:42:11 by ntoniolo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MODULEOSINFO_HPP
#define MODULEOSINFO_HPP

#include "AMonitorModule.class.hpp"

class SystemManager;

class ModuleOsInfo : public AMonitorModule {
    public:

        ModuleOsInfo(SystemManager &sm, Vector2D<int> const &position);
        ModuleOsInfo(void);
        ~ModuleOsInfo(void);

    private:
        void        _getModule(SystemManager &sm);

        ModuleOsInfo(ModuleOsInfo const &src);
        ModuleOsInfo        &operator=(ModuleOsInfo const &rhs);

        static const bool _debug;
};

#endif // ifndef MODULEOSINFO_HPP
