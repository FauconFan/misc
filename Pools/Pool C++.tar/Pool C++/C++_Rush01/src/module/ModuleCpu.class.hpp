/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ModuleCpu.class.hpp                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ntoniolo <ntoniolo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/14 16:06:15 by ntoniolo          #+#    #+#             */
/*   Updated: 2018/10/14 18:41:32 by ntoniolo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MODULECPU_HPP
#define MODULECPU_HPP

#include "AMonitorModule.class.hpp"

class SystemManager;

class ModuleCpu : public AMonitorModule {
    public:

        ModuleCpu(SystemManager &sm, Vector2D<int> const &position);
        ModuleCpu(void);
        ~ModuleCpu(void);
    private:
        void        _getModule(SystemManager &sm);

        ModuleCpu(ModuleCpu const &src);
        ModuleCpu       &operator=(ModuleCpu const &rhs);

        static const bool _debug;
};

#endif // ifndef MODULECPU_HPP
