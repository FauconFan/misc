#include <iostream>
#include "Time.class.hpp"

Time::Time(void) :
    _c_clockLast(clock()),
    _c_clock(clock()),
    _c_ctime(clock()),
    _frame(0),
    _deltaTime(0),
    _time(0),
    _fps(0),
    _retFps(0) {
    gettimeofday(&this->_step, NULL);
    gettimeofday(&this->_step, NULL);
    gettimeofday(&this->_cur, NULL);
    if (Time::_debug)
        std::cout << "Time:: Default constructor called." << std::endl;
}

Time::Time(Time const &src) :
    _c_clockLast(clock()),
    _c_clock(clock()),
    _c_ctime(clock()),
    _frame(0),
    _deltaTime(0),
    _time(0),
    _fps(0),
    _retFps(0) {
    gettimeofday(&this->_step, NULL);
    gettimeofday(&this->_step, NULL);
    gettimeofday(&this->_cur, NULL);
    if (Time::_debug)
        std::cout << "Time:: Copy constructor called." << std::endl;
    *this = src;
}

Time::~Time(void) {
    if (Time::_debug)
        std::cout << "Time:: Destructor called." << std::endl;
}

Time        &Time::operator=(Time const &rhs) {
    if (Time::_debug)
        std::cout << "Time:: Assignement called." << std::endl;
    if (this != &rhs) {}
    return (*this);
}

unsigned long Time::timestamp(struct timeval &tv) {
    return (tv.tv_sec * 1000 + tv.tv_usec / 1000);
}

void Time::update(void) {
    this->_updateTimeFrameBased();
    this->_updateTimeClockBased();
}

void Time::_updateTimeClockBased() {
    this->_c_clock = clock();

    this->_cdeltaTime = (float) (this->_c_clock - this->_c_clockLast) / CLOCKS_PER_SEC;

    this->_ctime       = (float) (clock()) / CLOCKS_PER_SEC;
    this->_c_clockLast = this->_c_clock;
}

void Time::_updateTimeFrameBased() {
    gettimeofday(&this->_step2, NULL);
    if (this->_fps) {
        this->_deltaTime = (float) (this->_step2.tv_usec - this->_cur.tv_usec)
          / 1000000.f;
        if (this->_deltaTime < 0.0005)
            this->_deltaTime = 0.0005;
        if (this->_cur.tv_sec != this->_step2.tv_sec) {
            this->_deltaTime = (float) (this->_step2.tv_usec
              + (1000000.f - this->_cur.tv_usec)) / 1000000.f;
        }
    }
    gettimeofday(&this->_cur, NULL);
    if (this->_cur.tv_sec - this->_step.tv_sec) {
        this->_retFps = this->_fps;
        this->_fps    = 0;
        gettimeofday(&this->_step, NULL);
    }
    this->_fps++;
    this->_time     += this->_deltaTime;
    this->_timestamp = this->_cur.tv_sec * 1000 + this->_cur.tv_usec / 1000;
    this->_frame++;
}

float Time::getCTime(void) const {
    return (this->_ctime);
}

float Time::getCDeltaTime(void) const {
    return (this->_cdeltaTime);
}

float Time::getCDeltaTime(int const mult) const {
    return (this->_cdeltaTime * mult);
}

unsigned long Time::getTimestamp(void) const {
    return (this->_timestamp);
}

float Time::getDeltaTime(void) const {
    return (this->_deltaTime);
}

float Time::getTime(void) const {
    return (this->_time);
}

const bool Time::_debug = 0;
