/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   TacticalMarine.cpp                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/02 13:53:07 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/02 15:59:38 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "ISpaceMarine.hpp"
#include "TacticalMarine.hpp"

TacticalMarine::TacticalMarine() {
    std::cout << "Tactical Marine ready for battle" << '\n';
}

TacticalMarine::TacticalMarine(TacticalMarine const & copy) {
    std::cout << "Tactical Marine (cloned) ready for battle" << '\n';
    *this = copy;
}

TacticalMarine::~TacticalMarine() {
    std::cout << "Aaargh ..." << '\n';
}

TacticalMarine &TacticalMarine::operator=(TacticalMarine const & copy) {
    (void)copy;
    return *this;
}

ISpaceMarine *TacticalMarine::clone() const {
    return new TacticalMarine(*this);
}

void TacticalMarine::battleCry() const {
    std::cout << "For the holy PLOT !" << '\n';
}

void TacticalMarine::rangedAttack() const {
    std::cout << "* attacks with bolter *" << '\n';
}

void TacticalMarine::meleeAttack() const {
    std::cout << "* attacks with chainsword *" << '\n';
}
