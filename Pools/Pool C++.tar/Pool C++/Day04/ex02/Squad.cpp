/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Squad.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/02 13:35:55 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/02 16:08:01 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Squad.hpp"

Squad::Squad() {
    this->_container      = new ISpaceMarine *[DEFAULT_SIZE];
    this->_size_container = DEFAULT_SIZE;
    this->_size_actu      = 0;
    for (size_t i = 0; i < DEFAULT_SIZE; i++) {
        this->_container[i] = NULL;
    }
}

Squad::Squad(Squad const & copy) {
    *this = copy;
}

Squad::~Squad() {
    this->free_container();
}

void Squad::free_container() {
    for (size_t i = 0; i < this->_size_actu; i++) {
        delete this->_container[i];
    }
    delete [] this->_container;
}

Squad &Squad::operator=(Squad const & copy) {
    this->free_container();
    this->_container      = new ISpaceMarine *[copy._size_container];
    this->_size_container = copy._size_container;
    this->_size_actu      = copy._size_actu;
    for (size_t i = 0; i < this->_size_actu; i++) {
        this->_container[i] = copy._container[i];
    }
    return *this;
}

int Squad::getCount() const {
    return (int) this->_size_actu;
}

ISpaceMarine * Squad::getUnit(int index) const {
    if (index < 0 || index >= (int) this->_size_actu)
        return NULL;

    return this->_container[index];
}

int Squad::push(ISpaceMarine * unit) {
    if (this->_size_actu >= this->_size_container) {
        ISpaceMarine ** container;
        size_t new_size;

        new_size  = 2 * this->_size_container;
        container = new ISpaceMarine *[new_size];
        for (size_t i = 0; i < this->_size_actu; i++) {
            container[i] = this->_container[i];
        }
        for (size_t i = this->_size_actu; i < new_size; i++) {
            container[i] = NULL;
        }
        this->_size_container = new_size;
        delete [] this->_container;
        this->_container = container;
    }
    this->_container[this->_size_actu++] = unit;
    return this->_size_actu;
}
