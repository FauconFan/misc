/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/02 13:30:50 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/02 16:09:20 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "ISquad.hpp"
#include "Squad.hpp"
#include "ISpaceMarine.hpp"
#include "AssaultTerminator.hpp"
#include "TacticalMarine.hpp"

static void describeSquad(ISquad * vlc) {
    std::cout << "Describing army" << '\n';
    for (int i = 0; i < vlc->getCount(); ++i)
    {
        std::cout << "Unit Army nb : " << i << '\n';
        ISpaceMarine* cur = vlc->getUnit(i);
        cur->battleCry();
        cur->rangedAttack();
        cur->meleeAttack();
    }
}

int main(void) {
    ISpaceMarine* bob = new TacticalMarine;
    ISpaceMarine* jim = new AssaultTerminator;

    ISquad* vlc = new Squad;
    vlc->push(bob);
    vlc->push(jim);

    describeSquad(vlc);

    std::cout << '\n';

    ISpaceMarine* kim = new AssaultTerminator;
    vlc->push(kim);
    describeSquad(vlc);

    // std::cout << '\n';
    //
    // for (size_t i = 0; i < 32; i++) {
    //     ISpaceMarine* james = new TacticalMarine;
    //     vlc->push(james);
    // }
    // describeSquad(vlc);

    std::cout << '\n';

    delete vlc;

    return 0;
}
