/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Squad.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/02 13:35:06 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/02 15:55:53 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SQUAD_HPP
#define SQUAD_HPP

#include <iostream>
#include "ISpaceMarine.hpp"
#include "ISquad.hpp"

#define DEFAULT_SIZE 16

class Squad : public ISquad {
    public:
        Squad ();
        Squad (Squad const &);
        virtual ~Squad ();

        Squad &operator=(Squad const &);

        int getCount() const;
        ISpaceMarine * getUnit(int) const;
        int push(ISpaceMarine *);
    private:
        ISpaceMarine ** _container;
        size_t _size_actu;
        size_t _size_container;

        void free_container();
};

#endif // ifndef SQUAD_HPP
