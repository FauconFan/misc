/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   MateriaSource.cpp                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/03 17:41:58 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/03 18:16:46 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "MateriaSource.hpp"

MateriaSource::MateriaSource() {
    this->_templates = new AMateria *[MATE_SOURCE_MAX];
    this->_size      = 0;
    for (size_t i = 0; i < MATE_SOURCE_MAX; i++) {
        this->_templates[i] = NULL;
    }
}

MateriaSource::MateriaSource(MateriaSource const &copy) {
    *this = copy;
}

MateriaSource::~MateriaSource() {
    for (size_t i = 0; i < MATE_SOURCE_MAX; i++) {
        if (this->_templates[i] != NULL)
            delete this->_templates[i];
    }
    delete [] this->_templates;
}

MateriaSource &MateriaSource::operator=(MateriaSource const &copy) {
    this->_templates = new AMateria *[MATE_SOURCE_MAX];
    this->_size      = copy._size;
    for (size_t i = 0; i < MATE_SOURCE_MAX; i++) {
        if (this->_templates[i] == NULL)
            return *this;

        this->_templates[i] = copy._templates[i]->clone();
    }
    return *this;
}

void MateriaSource::learnMateria(AMateria * m) {
    if (this->_size >= MATE_SOURCE_MAX)
        return;

    this->_templates[this->_size] = m;
    this->_size++;
}

AMateria * MateriaSource::createMateria(std::string const & type) {
    for (size_t i = 0; i < this->_size; i++) {
        AMateria * actu = this->_templates[i];

        if (actu->getType() == type)
            return actu->clone();
    }
    return NULL;
}
