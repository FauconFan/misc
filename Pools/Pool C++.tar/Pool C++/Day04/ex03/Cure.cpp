/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Cure.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/03 17:05:25 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/03 18:09:26 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "AMateria.hpp"
#include "ICharacter.hpp"
#include "Cure.hpp"

Cure::Cure() : AMateria("cure") {}

Cure::~Cure() {}

AMateria * Cure::clone() const {
    AMateria * cloned = new Cure(*this);

    cloned->setType("cure");
    return cloned;
}

void Cure::use(ICharacter &target) {
    AMateria::use(target);
    std::cout << "heals " << target.getName() << "’s wounds *" << '\n';
}
