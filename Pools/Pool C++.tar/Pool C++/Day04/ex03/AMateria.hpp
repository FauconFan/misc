/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   AMateria.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/03 16:49:46 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/03 18:10:55 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef AMATERIA_HPP
#define AMATERIA_HPP

#include <string>
#include "AMateria.hpp"
#include "ICharacter.hpp"

class ICharacter;

class AMateria
{
    private:
        std::string _type;
        unsigned int xp_;

    public:
        AMateria(std::string const & type);
        AMateria(AMateria const &);
        virtual ~AMateria();

        AMateria &operator=(AMateria const &);

        std::string const & getType() const;
        unsigned int getXP() const;

        void setType(std::string const &type);

        virtual AMateria* clone() const = 0;
        virtual void use(ICharacter &target);

};

#endif
