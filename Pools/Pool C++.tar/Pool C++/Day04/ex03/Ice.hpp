/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ICe.hpp                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/03 17:04:13 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/03 17:06:14 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ICE_HPP
#define ICE_HPP

#include "AMateria.hpp"
#include "ICharacter.hpp"

class Ice : public AMateria {
    public:
        Ice ();
        virtual ~Ice ();

        AMateria * clone() const;
        void use(ICharacter &target);
};

#endif // ifndef ICE_HPP
