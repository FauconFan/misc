/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Character.cpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/03 17:24:14 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/03 18:08:16 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string>
#include "Character.hpp"

Character::Character(std::string const &name) {
    this->_name = name;
    this->_mate = new AMateria*[MATE_MAX];
    for (size_t i = 0; i < MATE_MAX; i++) {
        this->_mate[i] = NULL;
    }
}

Character::Character(Character const & copy) {
    *this = copy;
}

Character::~Character() {
    for (size_t i = 0; i < MATE_MAX; i++) {
        if (this->_mate[i] != NULL)
            delete this->_mate[i];
    }
    delete [] this->_mate;
}

Character &Character::operator=(Character const & copy) {
    this->_name = copy.getName();
    this->_mate = new AMateria*[MATE_MAX];
    for (size_t i = 0; i < MATE_MAX; i++) {
        if (this->_mate[i] != NULL)
            this->_mate[i] = copy._mate[i]->clone();
        else
            this->_mate[i] = NULL;
    }
    return *this;
}

std::string const &Character::getName() const {
    return this->_name;
}

void Character::equip(AMateria *m) {
    for (size_t i = 0; i < MATE_MAX; i++) {
        if (this->_mate[i] == NULL) {
            this->_mate[i] = m;
            return ;
        }
    }
}

void Character::unequip(int idx) {
    if (idx < 0 || idx >= MATE_MAX)
        return;
    this->_mate[idx] = NULL;
}

void Character::use(int idx, ICharacter& target) {
    if (idx < 0 || idx >= MATE_MAX)
        return;
    AMateria *actu = this->_mate[idx];
    if (actu != NULL)
        actu->use(target);
}
