/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   AMateria.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/03 16:51:46 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/03 18:03:13 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string>
#include "ICharacter.hpp"
#include "AMateria.hpp"

AMateria::AMateria(std::string const & type)
    : _type(type) {
    this->xp_ = 0;
}

AMateria::AMateria(AMateria const & copy) {
    *this = copy;
}

AMateria::~AMateria() {}

AMateria &AMateria::operator=(AMateria const & copy) {
    // We d'ont change type in purpose
    this->xp_ = copy.getXP();
    return *this;
}

std::string const &AMateria::getType() const {
    return this->_type;
}

unsigned int AMateria::getXP() const {
    return this->xp_;
}

void AMateria::setType(std::string const &type) {
    this->_type = type;
}

void AMateria::use(ICharacter &target) {
    (void)target;
    this->xp_ += 10;
}
