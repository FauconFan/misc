/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/02 16:25:17 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/03 18:21:39 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "ICharacter.hpp"
#include "Character.hpp"
#include "IMateriaSource.hpp"
#include "MateriaSource.hpp"
#include "AMateria.hpp"
#include "Ice.hpp"
#include "Cure.hpp"

int main()
{
    IMateriaSource* src = new MateriaSource();
    src->learnMateria(new Ice());
    src->learnMateria(new Cure());

    ICharacter* zaz = new Character("zaz");

    AMateria* first;
    AMateria* second;
    AMateria* last;
    first = src->createMateria("ice");
    zaz->equip(first);
    second = src->createMateria("cure");
    zaz->equip(second);
    last = src->createMateria("cure");
    zaz->equip(last);

    ICharacter* bob = new Character("bob");

    zaz->use(0, *bob);
    zaz->unequip(0);
    zaz->use(0, *bob);

    std::cout << "XP 0 : " << first->getXP() << '\n';
    delete first;

    zaz->use(1, *bob);

    std::cout << "XP 1 : " << second->getXP() << '\n';

    zaz->use(2, *bob);
    zaz->use(2, *bob);
    zaz->use(2, *bob);
    zaz->use(2, *bob);

    std::cout << "XP 2 : " << last->getXP() << '\n';

    zaz->use(-1, *bob);

    delete bob;
    delete zaz;
    delete src;

    return 0;
}
