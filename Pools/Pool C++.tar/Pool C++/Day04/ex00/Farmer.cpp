/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Farmer.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/30 20:12:39 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/30 20:18:32 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string>
#include <iostream>
#include "Farmer.hpp"

Farmer::Farmer(std::string name) : Victim(name) {
    std::cout << "Farming..." << '\n';
}

Farmer::Farmer(Farmer const & copy) : Victim(copy) {
    std::cout << "Farming..." << '\n';
}

Farmer::~Farmer() {
    std::cout << "Sleeping..." << '\n';
}

void Farmer::getPolymorphed() const {
    std::cout << this->_name <<
        " has been turned into a farmer !" << std::endl;
}
