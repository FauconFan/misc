/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Sorcerer.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/30 19:42:44 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/30 20:08:18 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string>
#include <iostream>
#include "Sorcerer.hpp"
#include "Victim.hpp"

Sorcerer::Sorcerer(std::string name, std::string title)
    : _name(name), _title(title) {
    std::cout << name << ", " << title << " is born !" << '\n';
}

Sorcerer::Sorcerer(Sorcerer const & copy) {
    *this = copy;
    std::cout << copy._name << ", " << copy._title << " has been cloned..." << '\n';
}

Sorcerer::~Sorcerer() {
    std::cout << this->_name << ", " << this->_title
              << ", is dead. Consequences will never be the same !" << '\n';
}

Sorcerer &Sorcerer::operator=(Sorcerer const & copy) {
    this->_name  = copy._name;
    this->_title = copy._title;
    return *this;
}

std::string Sorcerer::getName() const {
    return this->_name;
}

std::string Sorcerer::getTitle() const {
    return this->_title;
}

void Sorcerer::polymorph(Victim const & v) const {
    v.getPolymorphed();
}

std::ostream &operator<<(std::ostream & os, Sorcerer const & s) {
    return os << "I am " << s.getName() << ", " << s.getTitle()
              << ", and I like ponies !" << std::endl;
}
