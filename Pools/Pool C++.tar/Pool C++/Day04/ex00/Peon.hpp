/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Peon.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/30 20:11:00 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/30 20:15:08 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PEON_HPP
#define PEON_HPP

#include <string>
#include "Victim.hpp"

class Peon : public Victim {
    public:
        Peon (std::string name);
        Peon (Peon const &);
        virtual ~Peon ();

        Peon &operator=(Peon const &);
        void getPolymorphed() const;
};

#endif
