/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Sorcerer.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/30 19:40:18 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/30 20:07:48 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SORCERER_HPP
#define SORCERER_HPP

#include <string>
#include <iostream>
#include "Victim.hpp"

class Sorcerer {
    public:
        Sorcerer (std::string name, std::string title);
        Sorcerer (Sorcerer const &);
        virtual ~Sorcerer ();

        Sorcerer &operator=(Sorcerer const &);

        std::string getName() const;
        std::string getTitle() const;
        void polymorph(Victim const &) const;
    private:
        std::string _name;
        std::string _title;
};

std::ostream  &operator<<(std::ostream &, Sorcerer const &);

#endif // ifndef SORCERER_HPP
