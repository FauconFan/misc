/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Victim.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/30 19:56:17 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/30 20:05:22 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef VICTIM_HPP
#define VICTIM_HPP

#include <string>
#include <iostream>

class Victim {
    public:
        Victim (std::string name);
        Victim (Victim const &);
        virtual ~Victim ();

        Victim &operator=(Victim const &);

        std::string getName() const;
        virtual void getPolymorphed() const;
    protected:
        std::string _name;
};

std::ostream &operator<<(std::ostream &, Victim const &);

#endif // ifndef VICTIM_HPP
