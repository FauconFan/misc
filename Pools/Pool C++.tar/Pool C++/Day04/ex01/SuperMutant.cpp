/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   SuperMutant.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/02 11:15:13 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/02 11:17:23 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "Enemy.hpp"
#include "SuperMutant.hpp"

SuperMutant::SuperMutant() : Enemy(170, "Super Mutant") {
    std::cout << "Gaaah. Me want smash heads !" << '\n';
}

SuperMutant::~SuperMutant() {
    std::cout << "Aaargh ..." << '\n';
}

void SuperMutant::takeDamage(int damage) {
    Enemy::takeDamage(damage - 3);
}
