/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Enemy.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/02 11:03:20 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/02 11:21:24 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string>
#include "Enemy.hpp"

Enemy::Enemy(int hp, std::string const & type) : _hp(hp), _type(type) {}

Enemy::Enemy(Enemy const & copy) {
    *this = copy;
}

Enemy::~Enemy() {}

Enemy &Enemy::operator=(Enemy const & copy) {
    this->_hp = copy._hp;
    this->_type = copy._type;
    return *this;
}

std::string const Enemy::getType() const {
    return this->_type;
}

int Enemy::getHP() const {
    return this->_hp;
}

void Enemy::takeDamage(int damage) {
    if (damage < 0)
        return;
    this->setHP(this->_hp - damage);
}

void Enemy::setHP(int newHp) {
    if (newHp < 0)
        newHp = 0;
    this->_hp = newHp;
}
