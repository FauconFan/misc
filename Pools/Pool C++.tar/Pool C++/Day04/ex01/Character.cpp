/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Character.cpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/02 11:38:45 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/02 13:15:13 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "Character.hpp"
#include "Enemy.hpp"
#include "AWeapon.hpp"

Character::Character(std::string const & name)
    : _name(name), _ap(MAX_AP), _weapon(NULL) {}

Character::Character(Character const & ch) {
    *this = ch;
}

Character::~Character() {}

Character &Character::operator=(Character const & ch) {
    this->_name   = ch._name;
    this->_ap     = ch._ap;
    this->_weapon = ch._weapon;
    return *this;
}

void Character::recoverAP() {
    this->_ap += RECOVER_AP;
    if (this->_ap > MAX_AP)
        this->_ap = MAX_AP;
}

void Character::equip(AWeapon * newWeapon) {
    this->_weapon = newWeapon;
}

void Character::attack(Enemy * en) {
    if (this->_weapon == NULL)
        return;
    else if (this->_ap < this->_weapon->getAPCost())
        return;

    std::cout << this->_name << " attacks "
              << en->getType() << " with a " << this->_weapon->getName() << '\n';
    this->_weapon->attack();
    this->_ap -= this->_weapon->getAPCost();
    en->takeDamage(this->_weapon->getDamage());
    if (en->getHP() == 0)
        delete en;
}

std::string const Character::getName() const {
    return this->_name;
}

int Character::getAP() const {
    return this->_ap;
}

AWeapon const * Character::getWeapon() const {
    return this->_weapon;
}

std::ostream &operator<<(std::ostream &os, Character const & ch) {
    AWeapon const * weapon;

    weapon = ch.getWeapon();
    os << ch.getName() << " has " << ch.getAP() << " AP and ";
    if (weapon == NULL) {
        os << "is unarmed";
    }
    else {
        os << "wields a " << weapon->getName();
    }
    os << '\n';
    return os;
}
