/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   SuperMutant.hpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/02 11:13:13 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/02 11:15:11 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SUPER_MUTANT_HPP
#define SUPER_MUTANT_HPP

#include "Enemy.hpp"

class SuperMutant : public Enemy {
    public:
        SuperMutant ();
        virtual ~SuperMutant ();

        void takeDamage(int);
};

#endif // ifndef SUPER_MUTANT_HPP
