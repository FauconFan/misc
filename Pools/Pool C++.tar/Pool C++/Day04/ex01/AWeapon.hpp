/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   AWeapon.hpp                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/01 12:19:31 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/01 12:47:57 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef AWEAPON_HPP
#define AWEAPON_HPP

#include <string>

class AWeapon {
    public:
        AWeapon (std::string const &, int, int);
        AWeapon (AWeapon const &);
        virtual ~AWeapon ();

        AWeapon &operator=(AWeapon const &);

        std::string getName() const;
        int getAPCost() const;
        int getDamage() const;

        virtual void attack() const = 0;
    private:
        std::string  _name;
        int _apcost;
        int _damage;
};

#endif
