/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   RadScorpion.hpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/02 11:17:57 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/02 11:22:36 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef RAD_SCORPION
#define RAD_SCORPION

#include "Enemy.hpp"

class RadScorpion : public Enemy {
    public:
        RadScorpion ();
        virtual ~RadScorpion ();
};

#endif
