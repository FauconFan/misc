/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   AWeapon.cpp                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/01 12:23:41 by jpriou            #+#    #+#             */
/*   Updated: 2018/06/01 12:44:15 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string>
#include "AWeapon.hpp"

AWeapon::AWeapon(std::string const & name, int apcost, int damage)
    : _name(name), _apcost(apcost), _damage(damage) {}

AWeapon::AWeapon(AWeapon const & copy) {
    *this = copy;
}

AWeapon::~AWeapon() {};

AWeapon &AWeapon::operator=(AWeapon const & copy) {
    if (this != &copy)
    {
        this->_name = copy.getName();
        this->_apcost = copy.getAPCost();
        this->_damage = copy.getDamage();
    }
    return *this;
}

std::string AWeapon::getName() const {
    return this->_name;
}

int AWeapon::getAPCost() const {
    return this->_apcost;
}

int AWeapon::getDamage() const {
    return this->_damage;
}
