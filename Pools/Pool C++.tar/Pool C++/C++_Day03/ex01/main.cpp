/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/29 20:16:48 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/29 22:31:16 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "FlagTrap.hpp"
#include "ScavTrap.hpp"

int main() {
    FlagTrap ft("Flag");
    FlagTrap b("Trap");
    FlagTrap c(ft);

    c = ft;
    ft.meleeAttack("Bob");
    ft.rangedAttack("Jim");

    ft.takeDamage(20);
    ft.takeDamage(10);
    ft.beRepaired(20);
    ft.beRepaired(20);
    ft.beRepaired(20);
    ft.takeDamage(142);
    ft.takeDamage(42);
    ft.beRepaired(50);
    ft.takeDamage(3);

    b.vaulthunter_dot_exe("Noe");
    b.vaulthunter_dot_exe("Noe");
    b.vaulthunter_dot_exe("Noe");
    b.vaulthunter_dot_exe("Noe");

    ScavTrap st("Flag");
    ScavTrap d("Trap");
    ScavTrap e(st);

    e = st;
    st.meleeAttack("Bob");
    st.rangedAttack("Jim");

    st.takeDamage(20);
    st.takeDamage(10);
    st.beRepaired(20);
    st.beRepaired(20);
    st.beRepaired(20);
    st.takeDamage(142);
    st.takeDamage(42);
    st.beRepaired(50);
    st.takeDamage(3);

    d.challengeNewcomer();
    d.challengeNewcomer();
    d.challengeNewcomer();
    d.challengeNewcomer();

    return 0;
} // main
