/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   FlagTrap.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/29 19:37:03 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/30 10:04:53 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FLAGTRAP_HPP
#define FLAGTRAP_HPP

#include <string>

class FlagTrap {
    public:
        FlagTrap ();
        FlagTrap (std::string name);
        FlagTrap (FlagTrap const &);
        virtual ~FlagTrap ();

        FlagTrap &operator=(FlagTrap const &);

        std::string getName() const;
        int getHitPoints() const;
        int getEnergyPoints() const;

        void meleeAttack(std::string const & target) const;
        void rangedAttack(std::string const & target) const;
        void takeDamage(unsigned int amount);
        void beRepaired(unsigned int amount);
        unsigned int vaulthunter_dot_exe(std::string const & target) const;

        unsigned int nullAttack(std::string const & target) const;
        unsigned int onePunch(std::string const & target) const;
        unsigned int kamehameha(std::string const & target) const;
        unsigned int infernoTornade(std::string const & target) const;
        unsigned int frozenIce(std::string const & target) const;
    private:
        unsigned int _hitPoints;
        unsigned int _maxHitPoints;
        unsigned int _energyPoints;
        unsigned int _maxEnergyPoints;
        unsigned int _level;
        std::string _name;
        unsigned int _meleeAttackDamage;
        unsigned int _rangedAttackDamage;
        unsigned int _armorDamageReduction;

        void setHitPoints(unsigned int newHitPoints);
        void setEnergyPoints(unsigned int newEnergyPoints);

        static unsigned int _size_list;
        static unsigned int (FlagTrap::* _attacks[])(std::string const & target) const;
};

#endif // ifndef FLAGTRAP_HPP
