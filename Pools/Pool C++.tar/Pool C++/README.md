# README for me later...

Be sure that the Coplien's form is respected !

Solve the diamond problem in the last exercise of day 3

The last exercise of day 4 is not done

Add ASCIIS-trees in ShrubberyCreationForm 05/02 and all newer files
Handles exceptions, opening files
