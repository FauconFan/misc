/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   contact.class.hpp                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/23 00:03:20 by jpriou            #+#    #+#             */
/*   Updated: 2018/05/23 15:05:01 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CONTACT_CLASS_HPP
#define CONTACT_CLASS_HPP

#include <string>

class Contact {
    private:
        const std::string first_name;
        const std::string last_name;
        const std::string nickname;
        const std::string login;
        const std::string postal_address;
        const std::string phone_number;
        const std::string birthday_date;
        const std::string favorite_meal;
        const std::string underwear_color;
        const std::string darkest_secret;

    public:
        Contact (std::string first_name,
            std::string      last_name,
            std::string      nickname,
            std::string      login,
            std::string      postal_address,
            std::string      phone_number,
            std::string      birthday_date,
            std::string      favorite_meal,
            std::string      underwear_color,
            std::string      darkest_secret);
        virtual ~Contact ();

        std::string getFirstName() const;
        std::string getLastName() const;
        std::string getNickName() const;

        void describeYourself() const;

        static std::string _askQuestion(std::string ques);
        static Contact * askingContact();
        static Contact * buildContact(std::string sample);
};

#endif // ifndef CONTACT_CLASS_HPP
