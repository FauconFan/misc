/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/22 23:59:01 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/03 11:36:10 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "main.hpp"
#include "contact.class.hpp"
#include "phonebook.class.hpp"

void usage(bool error = true) {
    if (error) {
        std::cout << "Command not recognised...\n\n";
    }
    std::cout << "List of available commands :" << '\n'
              << "\t" << ADD << "\n"
              << "\t" << SEARCH << "\n"
              << "\t" << EXIT << "\n\n";
    std::cout << "Description :\n"
              << "\t" << ADD << "\t: Adding a new contact to the phonebook\n"
              << "\t" << SEARCH << "\t: Asking for a contact, then display infos\n"
              << "\t" << EXIT << "\t: Quitting the program\n";
}

int main(void) {
    Phonebook phonebook;
    Contact * queryContact;
    bool running;
    std::string entry;

    queryContact = NULL;
    running      = true;
    entry        = "";
    while (running) {
        if (std::cin.good() == false)
            break ;
        std::cout << "$> ";
        std::getline(std::cin, entry);

        if (entry == EXIT) {
            running = false;
        }
        else if (entry == ADD) {
            phonebook.addContact(Contact::askingContact());
        }
        else if (entry == SEARCH) {
            queryContact = phonebook.selectContact();
            if (queryContact != NULL) {
                queryContact->describeYourself();
            }
        }
        else if (entry != "") {
            usage();
        }
    }

    // Catch End of file
    if (running)
        std::cout << "EOF" << '\n';

    return 0;
}
