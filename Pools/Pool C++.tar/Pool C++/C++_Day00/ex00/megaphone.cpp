/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   megaphone.cpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <jpriou@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/22 23:38:52 by jpriou            #+#    #+#             */
/*   Updated: 2018/10/03 11:33:09 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>

std::string upperCase(std::string str) {
    std::string res;

    for (std::string::iterator it = str.begin(); it != str.end(); it++) {
        res.push_back(std::toupper(*it));
    }
    return res;
}

int main(int argc, char const * argv[]) {
    if (argc <= 1) {
        std::cout << "* LOUD AND UNBEARABLE FEEDBACK NOISE *" << std::endl;
    }
    else {
        for (int i = 1; i < argc; i++) {
            std::cout << upperCase(argv[i]);
        }
        std::cout << std::endl;
    }
    return 0;
}
