ldapwhoami -Q | sed 's/dn://'
