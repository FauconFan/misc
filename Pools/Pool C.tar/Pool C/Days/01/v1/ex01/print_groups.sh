groups  | sed 's/$//g' | tr ' ' ','
