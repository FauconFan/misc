ls -l | sed 's/$/=/g' | tr '=' '
'
