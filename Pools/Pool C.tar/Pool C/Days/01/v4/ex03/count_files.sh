find . 2> /dev/null | wc -l | tr -d ' '
