cat $1 | grep bauer -i | grep nicolas -i | tr '	' '\n' | grep '-'
