/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operation.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpriou <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/08/14 13:06:32 by jpriou            #+#    #+#             */
/*   Updated: 2017/08/14 13:08:54 by jpriou           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		add(int a, int b)
{
	return (a + b);
}

int		substract(int a, int b)
{
	return (a - b);
}

int		times(int a, int b)
{
	return (a * b);
}

int		divide(int a, int b)
{
	return (a / b);
}

int		modulo(int a, int b)
{
	return (a % b);
}
